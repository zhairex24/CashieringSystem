-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: cashierdb
-- ------------------------------------------------------
-- Server version	5.5.58-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balances`
--

DROP TABLE IF EXISTS `balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balances` (
  `balance_id` int(50) NOT NULL AUTO_INCREMENT,
  `fee_balance` decimal(10,2) NOT NULL,
  `fee_id` int(50) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  PRIMARY KEY (`balance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balances`
--

LOCK TABLES `balances` WRITE;
/*!40000 ALTER TABLE `balances` DISABLE KEYS */;
INSERT INTO `balances` VALUES (3,1000.00,8,'16-00252'),(4,1000.00,8,'13-00367'),(5,0.00,12,'16-00252'),(6,0.00,12,'13-00367'),(7,3350.00,11,'15-00252'),(8,3350.00,11,'13-56410'),(9,1250.00,11,'13-56412');
/*!40000 ALTER TABLE `balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `birthday` varchar(50) NOT NULL,
  `recent_address` varchar(50) NOT NULL,
  `provincial_address` varchar(100) NOT NULL,
  `civil_status` enum('single','married','','') NOT NULL,
  `religion` varchar(50) NOT NULL,
  `baptism_date` varchar(50) NOT NULL,
  `position` int(11) NOT NULL,
  `deaprtment` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `education_id` int(11) NOT NULL,
  `application_id` int(11) NOT NULL,
  `attendance_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees`
--

DROP TABLE IF EXISTS `fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fees` (
  `fee_id` int(11) NOT NULL AUTO_INCREMENT,
  `fee_name` varchar(50) NOT NULL,
  `fee_amount` decimal(10,2) NOT NULL,
  `assign_to` varchar(50) NOT NULL,
  `date_of_entry` date NOT NULL,
  PRIMARY KEY (`fee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees`
--

LOCK TABLES `fees` WRITE;
/*!40000 ALTER TABLE `fees` DISABLE KEYS */;
INSERT INTO `fees` VALUES (6,'Misc Fee',14100.00,'Kindergarten','2018-02-20'),(7,'Misc Fee',7600.00,'Grade 1 - Grade 10','2018-02-20'),(8,'Misc Fee',10000.00,'Old Student (not ESC/not OVAP)','2018-02-20'),(10,'Misc Fee',17500.00,'New Student (not ESC/not OVAP)','2018-02-20'),(11,'Misc Fee',3350.00,'College','2018-02-20'),(12,'Registration Fee',350.00,'All Students','2018-02-20');
/*!40000 ALTER TABLE `fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_history`
--

DROP TABLE IF EXISTS `item_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_history` (
  `item_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(50) NOT NULL,
  `added` int(50) DEFAULT NULL,
  `deducted` int(50) DEFAULT NULL,
  `date_of_entry` date NOT NULL,
  PRIMARY KEY (`item_history_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_history`
--

LOCK TABLES `item_history` WRITE;
/*!40000 ALTER TABLE `item_history` DISABLE KEYS */;
INSERT INTO `item_history` VALUES (1,'001',50,NULL,'2018-02-21'),(2,'002',50,NULL,'2018-02-21'),(3,'003',60,NULL,'2018-02-21'),(4,'003',20,NULL,'2018-02-21'),(5,'002',100,NULL,'2018-02-21'),(6,'001',20,NULL,'2018-02-21'),(7,'001',NULL,2,'2018-02-21'),(8,'003',NULL,2,'2018-02-21'),(9,'',NULL,0,'2018-02-21'),(10,'002',NULL,3,'2018-02-21'),(11,'001',NULL,1,'2018-02-21'),(12,'003',NULL,1,'2018-02-21'),(13,'001',NULL,2,'2018-02-21'),(14,'003',NULL,2,'2018-02-21'),(15,'',NULL,0,'2018-02-21'),(16,'001',NULL,1,'2018-02-21'),(17,'',NULL,0,'2018-02-21'),(18,'',NULL,0,'2018-02-23'),(19,'001',NULL,2,'2018-02-23'),(20,'003',NULL,2,'2018-02-23'),(21,'',NULL,0,'2018-02-23'),(22,'001',NULL,1,'2018-02-23'),(23,'003',NULL,1,'2018-02-23'),(24,'',NULL,0,'2018-02-23'),(25,'002',NULL,1,'2018-02-23'),(26,'',NULL,0,'2018-02-23'),(27,'001',NULL,1,'2018-02-23'),(28,'003',NULL,2,'2018-02-23'),(29,'',NULL,0,'2018-02-23'),(30,'001',NULL,1,'2018-02-23'),(31,'003',NULL,1,'2018-02-23');
/*!40000 ALTER TABLE `item_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(50) NOT NULL,
  `item_amount` decimal(10,2) NOT NULL,
  `item_code` varchar(50) NOT NULL,
  `item_quantity` int(50) NOT NULL,
  `item_color` varchar(50) DEFAULT NULL,
  `item_size` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,'Polo',150.00,'001',59,'White','S'),(2,'Blouse',100.00,'002',146,'White','M'),(3,'Pants',300.00,'003',69,'Blue','M');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_number` varchar(15) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `scholarship_status` enum('Partial','Full') NOT NULL,
  `enrollment_status` enum('PartiallyEnrolled','OfficiallyEnrolled','NotEnrolled') NOT NULL,
  `course` varchar(45) NOT NULL,
  `year_level` enum('1','2','3','4','5') NOT NULL,
  `semester` enum('1','2') NOT NULL,
  `school_year` varchar(45) NOT NULL,
  `email` varchar(200) NOT NULL,
  `home_address` varchar(250) NOT NULL,
  `student_contact` varchar(50) NOT NULL,
  `level` varchar(45) NOT NULL,
  PRIMARY KEY (`id`,`year_level`),
  UNIQUE KEY `student_number` (`student_number`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'15-00252','Joaquin','Canlas','Bordado','Partial','PartiallyEnrolled','B.S. in Accounting','4','1','2017-2018','joaquinbordado@gmail.com','Joaquin House','2147483647','College'),(2,'15-00321','Juan','Manuel','Marquez','Partial','PartiallyEnrolled','Grade 8','3','1','2017-2018','juanmarquez@gmail.com','Juan House','2147483647','Grade School'),(9,'13-00367','qwe','asd','zxc','Partial','PartiallyEnrolled','Grade 12','3','1','2017-2018','qwe@gmail.com','qweqwe','9222222222','Old (not ESC/not OVAP)'),(10,'16-00252','tyu','ghj','bn','Full','OfficiallyEnrolled','Grade 12','4','1','2017-2018','tyu@gmail.com','tyutyu','9123456789','Old (not ESC/not OVAP)'),(15,'14-22677','Carla','asd','Valdez','Partial','PartiallyEnrolled','Kindergarten 1','3','1','2017-2018','qwe@gmail.com','qweqwe','9222222222','Kindergarten'),(16,'14-00235','Carl','ghj','Valdez','Partial','OfficiallyEnrolled','Prep','4','1','2017-2018','tyu@gmail.com','tyutyu','9123456789','Kindergarten'),(17,'13-56410','Normskiee','asd','Bautista','Partial','PartiallyEnrolled','B.S. in Information System','5','2','2017-2018','qwqwee@gmail.com','qweqwexcxzc','922qweqw2222','College'),(18,'13-56412','Eloy','ghj','Ferrer','Partial','OfficiallyEnrolled','B.A. in Broadcasting','5','2','2017-2018','tyu@zgmail.com','tyqweqwutyu','qweq9123456789','College');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_detail`
--

DROP TABLE IF EXISTS `transaction_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(50) DEFAULT NULL,
  `item_quantity` varchar(50) DEFAULT NULL,
  `item_paid_amount` decimal(10,2) NOT NULL,
  `invoice_number` varchar(50) NOT NULL,
  `pay_item_id` int(50) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `date_of_transaction` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_detail`
--

LOCK TABLES `transaction_detail` WRITE;
/*!40000 ALTER TABLE `transaction_detail` DISABLE KEYS */;
INSERT INTO `transaction_detail` VALUES (1,'',NULL,3000.00,'INV20181001',8,'16-00252','2018-01-20'),(2,'002','3',300.00,'INV20181001',2,'16-00252','2018-01-20'),(3,'001','1',150.00,'INV20181002',1,'15-00252','2018-01-29'),(4,'003','1',300.00,'INV20181002',3,'15-00252','2018-01-29'),(5,'001','2',300.00,'INV20181003',1,'13-56412','2018-02-01'),(6,'003','2',600.00,'INV20181003',3,'13-56412','2018-02-01'),(7,'',NULL,350.00,'INV20181004',12,'16-00252','2018-02-14'),(8,'001','1',150.00,'INV20181004',1,'16-00252','2018-02-14'),(9,'',NULL,2000.00,'INV20181005',8,'16-00252','2018-02-19'),(10,'',NULL,3000.00,'INV20181006',8,'16-00252','2018-02-20'),(11,'001','2',300.00,'INV20181006',1,'16-00252','2018-02-20'),(12,'003','2',600.00,'INV20181006',3,'16-00252','2018-02-20'),(13,'',NULL,2100.00,'INV20181007',11,'13-56412','2018-02-21'),(14,'001','1',150.00,'INV20181007',1,'13-56412','2018-02-22'),(15,'003','1',300.00,'INV20181007',3,'13-56412','2018-02-22'),(16,'',NULL,1000.00,'INV20181008',8,'13-00367','2018-02-23'),(17,'002','1',100.00,'INV20181008',2,'13-00367','2018-02-23'),(18,'',NULL,1000.00,'INV20181009',8,'16-00252','2018-06-23'),(19,'001','1',150.00,'INV20181009',1,'16-00252','2018-06-23'),(20,'003','2',600.00,'INV20181009',3,'16-00252','2018-07-23'),(21,'',NULL,1000.00,'INV20181010',8,'13-00367','2018-09-23'),(22,'001','1',150.00,'INV20181010',1,'13-00367','2018-10-23'),(23,'003','1',300.00,'INV20181010',3,'13-00367','2018-10-23');
/*!40000 ALTER TABLE `transaction_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `transactions_id` int(20) NOT NULL AUTO_INCREMENT,
  `payment_type` enum('Cash','Cheque') NOT NULL,
  `amount_paid` decimal(19,2) NOT NULL,
  `amount_tendered` decimal(10,2) NOT NULL,
  `amount_change` decimal(10,2) NOT NULL,
  `invoice_number` varchar(45) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `student_number` varchar(50) NOT NULL,
  PRIMARY KEY (`transactions_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,'Cash',3300.00,3500.00,200.00,'INV20181001','2','16-00252'),(2,'Cash',450.00,500.00,50.00,'INV20181002','2','15-00252'),(3,'Cash',900.00,1000.00,100.00,'INV20181003','2','13-56412'),(4,'Cash',500.00,500.00,0.00,'INV20181004','2','16-00252'),(5,'Cash',2000.00,2000.00,0.00,'INV20181005','2','16-00252'),(6,'Cash',3900.00,4000.00,100.00,'INV20181006','2','16-00252'),(7,'Cash',2550.00,2600.00,50.00,'INV20181007','2','13-56412'),(8,'Cash',1100.00,1100.00,0.00,'INV20181008','2','13-00367'),(9,'Cash',1750.00,2000.00,250.00,'INV20181009','2','16-00252'),(10,'Cash',1450.00,1500.00,50.00,'INV20181010','2','13-00367');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_accounts`
--

DROP TABLE IF EXISTS `user_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_accounts` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `account_type` enum('Admin_Accounting','Cashier') NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_accounts`
--

LOCK TABLES `user_accounts` WRITE;
/*!40000 ALTER TABLE `user_accounts` DISABLE KEYS */;
INSERT INTO `user_accounts` VALUES (1,'John','C','Doe','john_doe','secret123','Cashier'),(2,'I','am','Admin','admin','admin','Admin_Accounting');
/*!40000 ALTER TABLE `user_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'cashierdb'
--

--
-- Dumping routines for database 'cashierdb'
--
/*!50003 DROP PROCEDURE IF EXISTS `AddFees` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddFees`(
    _FeeName VARCHAR(50),
    _FeeAmount DECIMAL(10, 2),
    _AssignTo VARCHAR(50)
    
)
BEGIN
	declare dateNow varchar(50);
    set dateNow = CURDATE();
    
	INSERT INTO fees(fee_name, fee_amount, assign_to, date_of_entry)
	VALUES (_FeeName, _FeeAmount, _AssignTo, dateNow);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddItems` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddItems`(
    _ItemCode VARCHAR(50),
    _ItemName VARCHAR(50),
    _ItemAmount DECIMAL(10, 2),
    _Quantity INT(50),
    _Color VARCHAR(50),
    _Size VARCHAR(50)
    
)
BEGIN
declare dateNow varchar(50);
set dateNow = CURDATE();
    
	INSERT INTO items(item_name, item_amount, item_code, item_quantity, item_color, item_size)
	VALUES (_ItemName,  _ItemAmount, _ItemCode, _Quantity, _Color, _Size);


	
	INSERT INTO item_history(item_code, added, deducted, date_of_entry)
    VALUES (_ItemCode, _Quantity, NULL, dateNow);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddQuantity` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddQuantity`(    
    _ItemCode VARCHAR(50),
    _ItemId INT(50),
    _Quantity INT(50),
    _Quantity2 INT(50)
    
)
BEGIN
declare dateNow varchar(50);
    set dateNow = CURDATE();
    
    UPDATE items 
    SET item_quantity = _Quantity2
	WHERE item_id = _ItemId AND item_code = _ItemCode;

	INSERT INTO item_history(item_code, added, deducted, date_of_entry)
    VALUES (_ItemCode, _Quantity, NULL, dateNow);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddStudent` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddStudent`(
	_StudentNo VARCHAR(15),
    _Fname VARCHAR(30),
    _Mname VARCHAR(30),
    _Lname VARCHAR(30),
    _SStatus ENUM('Partial','Full'),
    _EStatus ENUM('PartiallyEnrolled', 'OfficiallyEnrolled', 'NotEnrolled'),
    _Course VARCHAR(50),
    _YearLevel ENUM('1', '2', '3', '4', '5'),
    _Semester ENUM('1', '2'),
    _SchoolYear VARCHAR(50),
    _Email VARCHAR(50),
    _HAddress VARCHAR(50),
    _StudentContact VARCHAR(50)
)
BEGIN
	INSERT INTO students(student_number, fname, mname, lname, scholarship_status,
						enrollment_status, course, year_level, semester, school_year, email,
                        home_address, student_contact)
	VALUES (_StudentNo, _Fname, _Mname, _Lname, _SStatus, _EStatus, _Course, _YearLevel,
			_Semester, _SchoolYear, _Email, _HAddress, _StudentContact);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddTransaction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddTransaction`()
BEGIN

declare transac_id int(50);

set transac_id = (select transactions_id from transactions order by transactions_id desc limit 1);

select transac_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AssignFee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AssignFee`(
	_Amount DECIMAL(10,2),
	_FeeId INT(50),
    _StudentId VARCHAR(50)
)
BEGIN
	INSERT INTO balances(fee_balance, fee_id, student_id)
    VALUES (_Amount, _FeeId, _StUdentId);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeleteFeeByID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteFeeByID`(
	_FeeId INT(50)
)
BEGIN
	DELETE FROM fees
    WHERE fee_id = _FeeId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeleteItemByID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteItemByID`(
	_ItemId INT(50)
)
BEGIN
	DELETE FROM items
    WHERE item_id = _ItemId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `EditFee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `EditFee`(
	_FeeID INT,
    _FeeName VARCHAR(50),
    _AppliedTo VARCHAR(50),
    _Department VARCHAr(50),
    _Amount DECIMAL(10, 2)
    
)
BEGIN
	UPDATE fees
	SET
		fee_name = _FeeName,
		applied_to = _AppliedTo,
		department = _Department,
		amount = _Amount
	WHERE fee_id = _FeeID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllCollectionsByDate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllCollectionsByDate`(
	_FromDate VARCHAR(50),
    _ToDate VARCHAR(50)
)
BEGIN
	SELECT td.item_code, i.item_name, f.fee_name, LEFT(td.date_of_transaction, 10) ,td.item_paid_amount 
    FROM transaction_detail td 
    LEFT JOIN items i ON i.item_id=td.pay_item_id
    LEFT JOIN fees f ON f.fee_id=td.pay_item_id
    WHERE 
    td.date_of_transaction BETWEEN _FromDate AND _ToDate;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllFees` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllFees`()
BEGIN
	SELECT fee_id, fee_name, assign_to, fee_amount FROM fees;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllItemHistoryByItemCode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllItemHistoryByItemCode`(
	_ItemCode VARCHAR(100)
)
BEGIN
	SELECT i.item_code, i.item_name, i.item_size, i.item_color,
			ih.added, ih.deducted, LEFT(ih.date_of_entry, 10)
    FROM  items i
    LEFT JOIN item_history ih ON i.item_code=ih.item_code
    WHERE i.item_code = _ItemCode ORDER BY ih.date_of_entry ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllItems` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllItems`()
BEGIN
	SELECT item_id, item_code, item_name, item_color, item_size, 
			 item_quantity, item_amount
    FROM items;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetBalances` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetBalances`(
    _ItemPaidAmount DECIMAL(10, 2),
    _OR VARCHAR(50),
    _PayItemId VARCHAR(50),
    _StudentId VARCHAR(50)
)
BEGIN
	declare balance DECIMAL(10, 2);
    set balance = (SELECT fee_balance FROM balances WHERE pay_item_id = _PayItemId 
					AND student_id = _StudentId);
                    
    UPDATE balances SET fee_balance = balance - _ItemPaidAmount
	WHERE pay_item_id = _PayItemId AND student_id = _StudentId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetFeesByStudentId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetFeesByStudentId`(
	_StudentId VARCHAR(50)
)
BEGIN
	SELECT f.fee_name, f.fee_amount, b.fee_balance
	FROM fees f
	RIGHT JOIN balances b on f.fee_id=b.fee_id
	WHERE b.student_id = _Studentid;
    
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetItemCode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetItemCode`()
BEGIN
	SELECT item_code FROM items ORDER BY item_code ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetItemHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetItemHistory`()
BEGIN
	SELECT i.item_code, i.item_name, i.item_size, i.item_color,
			ih.added, ih.deducted, LEFT(ih.date_of_entry, 10)
	FROM items i
	INNER JOIN item_history ih
	ON i.item_code = ih.item_code;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetLatestORNumber` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetLatestORNumber`()
BEGIN
declare latest_or VARCHAR(50);

set latest_or = (select invoice_number from transactions order by invoice_number desc limit 1);

select latest_or;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetTransaction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetTransaction`(
	_OR VARCHAR(50)
)
BEGIN
		SELECT t.payment_type, t.amount_paid, t.amount_tendered, 
				t.amount_change, t.invoice_number,
				ua.fname, ua.lname, s.fname, s.lname
        FROM transactions t
        INNER JOIN user_accounts ua ON t.user_id=ua.user_id
        INNER JOIN students s ON t.student_number=s.student_number
		WHERE t.invoice_number = _OR;
				
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetTransactionDetail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetTransactionDetail`(
	_OR VARCHAR(50)
)
BEGIN
	SELECT td.item_code, td.item_quantity, td.item_paid_amount, td.date_of_transaction,
	f.fee_name, i.item_name
	FROM transaction_detail td
	LEFT JOIN fees f ON td.pay_item_id=f.fee_id
	LEFT JOIN items i ON td.pay_item_id=i.item_id
	WHERE td.invoice_number = _OR;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetTransactionID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetTransactionID`()
BEGIN

declare transac_id int(50);

set transac_id = (select transactions_id from transactions order by transactions_id desc limit 1) + 1;

select transac_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetTransactionMade` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetTransactionMade`(
	_StudentId VARCHAR(50)
)
BEGIN
	SELECT LEFT(td.date_of_transaction, 10), td.invoice_number, td.item_paid_amount, f.fee_name, i.item_name, i.item_code, td.item_quantity
	FROM transaction_detail td
	LEFT JOIN fees f ON f.fee_id=td.pay_item_id
	LEFT JOIN items i ON i.item_id=td.pay_item_id
	WHERE td.student_id = _StudentId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InvoiceNumber` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InvoiceNumber`()
BEGIN

declare invName varchar(10);
declare yr int(20);
declare max varchar(40);
declare num int(20);
declare invNumber varchar(40);
declare kanan int(30);
declare transac_id int(40);

set invName = 'INV';
set yr = year(now());
set max = (select invoice_number from transactions ORDER BY transactions_id DESC LIMIT 1);
set transac_id = (select transactions_id from transactions order by transactions_id desc limit 1);

set kanan = right(max, 4);
set num = kanan + 1;
set invNumber = concat(invName, yr, num);

select invNumber, transac_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PaymentType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `PaymentType`(
	_Category VARCHAR(100)
)
BEGIN

if (_Category = "Down payment")
    then
    select fees.fee_name, fees.amount from fees left join items_to_pay on fees.fee_id = items_to_pay.fee_id where items_to_pay.items_to_pay_for = "Down payment";

elseif (_Category = "Final payment")
	then
    select fees.fee_name, fees.amount from fees left join items_to_pay on fees.fee_id = items_to_pay.fee_id where items_to_pay.items_to_pay_for = "Final payment";

elseif (_Category = "Midterm payment")
	then   
     select fees.fee_name, fees.amount from fees left join items_to_pay on fees.fee_id = items_to_pay.fee_id where items_to_pay.items_to_pay_for = "";
end if;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SaveTransaction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `SaveTransaction`(
    _PaymentType VARCHAR(50),
    _AmountPaid DECIMAL(10, 2),
    _AmountTendered DECIMAL(10, 2),
    _AmountChange DECIMAL(10, 2),
    _OR VARCHAR(50),
    _UserId VARCHAR(50),
    _StudentNo VARCHAR(50)
)
BEGIN
	declare dateNow varchar(50);
    set dateNow = CURDATE();
    INSERT INTO transactions(payment_type, amount_paid, amount_tendered, amount_change,
				invoice_number, user_id, student_number)
		VALUES(_PaymentType, _AmountPaid, _AmountTendered, _AmountChange,
				_OR, _UserId, _StudentNo);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SaveTransactionDetail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `SaveTransactionDetail`(
    _ItemCode VARCHAR(50),
    _ItemQuantity INT(50),
    _ItemAmount DECIMAL(10,2),
    _OR VARCHAR(50),
    _PayItemId INT(50),
    _StudentId VARCHAR(50)
)
BEGIN
	declare balance DECIMAL(10, 2);
    declare paid_amount DECIMAL(10, 2);
    declare dateNow VARCHAR(50);
    set dateNow = CURDATE();
    
    
    INSERT INTO transaction_detail(item_code, item_quantity, item_paid_amount, invoice_number, pay_item_id, student_id, date_of_transaction)
    VALUES (_ItemCode, _ItemQuantity, _ItemAmount, _OR, _PayItemId, _StudentId, dateNow);
    
    UPDATE items SET item_quantity = items.item_quantity - _ItemQuantity 
	WHERE items.item_id = _PayItemId;
    
    UPDATE transaction_detail SET item_quantity = NULL WHERE item_quantity = 0;
    
    set balance = (SELECT fee_balance FROM balances WHERE fee_id = _PayItemId 
					AND student_id = _StudentId);
                    
	set paid_amount = (SELECT item_paid_amount FROM transaction_detail WHERE pay_item_id = _PayItemId 
						AND student_id = _StudentId AND invoice_number =  _OR);
                    
    UPDATE balances SET fee_balance = balance - paid_amount
	WHERE fee_id = _PayItemId AND student_id = _StudentId;
    
    
    INSERT INTO item_history (item_code, added, deducted, date_of_entry)
    VALUES (_ItemCode, null, _ItemQuantity, dateNow);
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `StudentsViewAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `StudentsViewAll`()
BEGIN
	SELECT * FROM students;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `StudentsViewAllByValue` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `StudentsViewAllByValue`(
	_SearchValue VARCHAR(100)
)
BEGIN
	SELECT * FROM students WHERE CONCAT(lname, " ", fname, " ", mname)  LIKE CONCAT("%", _SearchValue, "%")
    OR course LIKE CONCAT("%", _SearchValue, "%") ORDER BY lname ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateBalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateBalance`(
    _PayItemId INT(50),
    _StudentId VARCHAR(50)
)
BEGIN
	declare balance DECIMAL(10, 2);
    declare paid_amount DECIMAL(10, 2);
    
    set balance = (SELECT fee_balance FROM balances WHERE pay_item_id = _PayItemId 
					AND student_id = _StudentId);
                    
	set paid_amount = (SELECT item_paid_amount FROM transaction_detail WHERE pay_item_id = _PayItemId 
						AND student_id = _StudentId);
                    
    UPDATE balances SET fee_balance = balance - paid_amount
	WHERE pay_item_id = _PayItemId AND student_id = _StudentId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateFees` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateFees`(
	_FeeId INT(50),
    _FeeName VARCHAR(50),
    _FeeAmount DECIMAL(10, 2),
    _AssignTo VARCHAR(50)
)
BEGIN
	UPDATE fees
	SET
		fee_name = _FeeName,
		fee_amount = _FeeAmount,
        assign_to = _AssignTo
	WHERE fee_id = _FeeId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateItem` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateItem`(
	_ItemId INT(50),
    _ItemCode VARCHAR(50),
    _ItemName VARCHAR(50),
    _ItemAmount DECIMAL(10, 2),
    _Color VARCHAR(50),
    _Size VARCHAR(50)
)
BEGIN
	UPDATE items
	SET
		item_code = _ItemCode,
		item_name = _ItemName,
		item_amount = _ItemAmount,
		item_color = _Color,
        item_size = _Size
	WHERE item_id = _ItemId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ViewAllStudentsByPartial` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ViewAllStudentsByPartial`()
BEGIN
	SELECT student_number, fname, mname, lname, scholarship_status, course 
    FROM students
    WHERE scholarship_status LIKE 'Partial';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-28  8:34:06
