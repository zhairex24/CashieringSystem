﻿namespace CashieringSystem
{
    partial class Collections
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.txtToDate = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.txtFromDate = new Telerik.WinControls.UI.RadDateTimePicker();
            this.eadd = new Telerik.WinControls.UI.RadLabel();
            this.dgvCollections = new Telerik.WinControls.UI.RadGridView();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.txtItemId = new Telerik.WinControls.UI.RadTextBox();
            this.office2013LightTheme1 = new Telerik.WinControls.Themes.Office2013LightTheme();
            this.balance = new Telerik.WinControls.UI.RadLabel();
            this.txtTotal = new Telerik.WinControls.UI.RadTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).BeginInit();
            this.radPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtToDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFromDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eadd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCollections)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCollections.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            this.radLabel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.balance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radPanel1
            // 
            this.radPanel1.Controls.Add(this.txtToDate);
            this.radPanel1.Controls.Add(this.radLabel1);
            this.radPanel1.Controls.Add(this.txtFromDate);
            this.radPanel1.Controls.Add(this.eadd);
            this.radPanel1.Controls.Add(this.dgvCollections);
            this.radPanel1.Controls.Add(this.radLabel5);
            this.radPanel1.Location = new System.Drawing.Point(132, 5);
            this.radPanel1.Name = "radPanel1";
            this.radPanel1.Size = new System.Drawing.Size(1078, 480);
            this.radPanel1.TabIndex = 1;
            this.radPanel1.ThemeName = "Office2013Light";
            // 
            // txtToDate
            // 
            this.txtToDate.AccessibleName = "";
            this.txtToDate.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtToDate.Location = new System.Drawing.Point(880, 22);
            this.txtToDate.Name = "txtToDate";
            this.txtToDate.Size = new System.Drawing.Size(186, 25);
            this.txtToDate.TabIndex = 78;
            this.txtToDate.TabStop = false;
            this.txtToDate.Text = "Wednesday, December 13, 2017";
            this.txtToDate.ThemeName = "Office2013Light";
            this.txtToDate.Value = new System.DateTime(2017, 12, 13, 15, 45, 1, 255);
            this.txtToDate.ValueChanged += new System.EventHandler(this.txtToDate_ValueChanged);
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.Location = new System.Drawing.Point(846, 22);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(28, 24);
            this.radLabel1.TabIndex = 77;
            this.radLabel1.Text = "To:";
            this.radLabel1.ThemeName = "Office2013Light";
            // 
            // txtFromDate
            // 
            this.txtFromDate.AccessibleName = "";
            this.txtFromDate.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFromDate.Location = new System.Drawing.Point(616, 22);
            this.txtFromDate.Name = "txtFromDate";
            this.txtFromDate.Size = new System.Drawing.Size(186, 25);
            this.txtFromDate.TabIndex = 76;
            this.txtFromDate.TabStop = false;
            this.txtFromDate.Text = "Wednesday, December 13, 2017";
            this.txtFromDate.ThemeName = "Office2013Light";
            this.txtFromDate.Value = new System.DateTime(2017, 12, 13, 15, 45, 1, 255);
            this.txtFromDate.ValueChanged += new System.EventHandler(this.txtFromDate_ValueChanged);
            // 
            // eadd
            // 
            this.eadd.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eadd.Location = new System.Drawing.Point(564, 22);
            this.eadd.Name = "eadd";
            this.eadd.Size = new System.Drawing.Size(46, 24);
            this.eadd.TabIndex = 75;
            this.eadd.Text = "From:";
            this.eadd.ThemeName = "Office2013Light";
            // 
            // dgvCollections
            // 
            this.dgvCollections.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvCollections.Location = new System.Drawing.Point(0, 61);
            // 
            // dgvCollections
            // 
            this.dgvCollections.MasterTemplate.AllowAddNewRow = false;
            this.dgvCollections.MasterTemplate.AllowColumnChooser = false;
            this.dgvCollections.MasterTemplate.AllowColumnResize = false;
            this.dgvCollections.MasterTemplate.AllowDeleteRow = false;
            this.dgvCollections.MasterTemplate.AllowDragToGroup = false;
            this.dgvCollections.MasterTemplate.AllowEditRow = false;
            this.dgvCollections.MasterTemplate.AllowRowResize = false;
            this.dgvCollections.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            this.dgvCollections.MasterTemplate.EnableGrouping = false;
            this.dgvCollections.Name = "dgvCollections";
            this.dgvCollections.Size = new System.Drawing.Size(1078, 419);
            this.dgvCollections.TabIndex = 73;
            this.dgvCollections.Text = "radGridView1";
            this.dgvCollections.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel5
            // 
            this.radLabel5.Controls.Add(this.txtItemId);
            this.radLabel5.Font = new System.Drawing.Font("Segoe UI", 20F);
            this.radLabel5.Location = new System.Drawing.Point(15, 15);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(115, 31);
            this.radLabel5.TabIndex = 72;
            this.radLabel5.Text = "Collections";
            this.radLabel5.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadLabelElement)(this.radLabel5.GetChildAt(0))).Text = "Collections";
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel5.GetChildAt(0).GetChildAt(2).GetChildAt(1))).TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel5.GetChildAt(0).GetChildAt(2).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            // 
            // txtItemId
            // 
            this.txtItemId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemId.Location = new System.Drawing.Point(115, 43);
            this.txtItemId.Name = "txtItemId";
            this.txtItemId.Size = new System.Drawing.Size(30, 23);
            this.txtItemId.TabIndex = 72;
            this.txtItemId.ThemeName = "Office2013Light";
            // 
            // balance
            // 
            this.balance.Enabled = false;
            this.balance.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balance.Location = new System.Drawing.Point(925, 499);
            this.balance.Name = "balance";
            this.balance.Size = new System.Drawing.Size(134, 24);
            this.balance.TabIndex = 78;
            this.balance.Text = "                 Total:  ₱";
            this.balance.ThemeName = "Office2013Light";
            // 
            // txtTotal
            // 
            this.txtTotal.Enabled = false;
            this.txtTotal.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.Location = new System.Drawing.Point(1065, 500);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(145, 23);
            this.txtTotal.TabIndex = 77;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotal.ThemeName = "Office2013Light";
            // 
            // Collections
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 697);
            this.Controls.Add(this.balance);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.radPanel1);
            this.Name = "Collections";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "Collections";
            this.ThemeName = "Office2013Light";
            this.Load += new System.EventHandler(this.Collections_Load);
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).EndInit();
            this.radPanel1.ResumeLayout(false);
            this.radPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtToDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFromDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eadd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCollections.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCollections)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            this.radLabel5.ResumeLayout(false);
            this.radLabel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.balance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadPanel radPanel1;
        private Telerik.WinControls.UI.RadLabel eadd;
        private Telerik.WinControls.UI.RadGridView dgvCollections;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadTextBox txtItemId;
        public Telerik.WinControls.UI.RadDateTimePicker txtToDate;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        public Telerik.WinControls.UI.RadDateTimePicker txtFromDate;
        private Telerik.WinControls.Themes.Office2013LightTheme office2013LightTheme1;
        private Telerik.WinControls.UI.RadLabel balance;
        public Telerik.WinControls.UI.RadTextBox txtTotal;
    }
}
