﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class Collections : Telerik.WinControls.UI.RadForm
    {
        public Collections()
        {
            InitializeComponent();
        }

        Payment p = new Payment();

        private void Collections_Load(object sender, EventArgs e)
        {
            txtFromDate.Text = Convert.ToString(DateTime.Today);
            txtToDate.Text = Convert.ToString(DateTime.Today);
            dgvCollections.Columns[0].HeaderText = "Item Code";
            dgvCollections.Columns[1].HeaderText = "Item Name";
            dgvCollections.Columns[2].HeaderText = "Fee Name";
            dgvCollections.Columns[3].HeaderText = "Date";
            dgvCollections.Columns[4].HeaderText = "Amount";

            decimal sum = 0;
            for (int i = 0; i < dgvCollections.Rows.Count; i++)
            {
                sum += Convert.ToDecimal(dgvCollections.Rows[i].Cells[4].Value);
            }
            txtTotal.Text = sum.ToString();

        }

        private void txtFromDate_ValueChanged(object sender, EventArgs e)
        {
            string dateFrom = String.Format("{0:yyyy-MM-dd}", txtFromDate.Value);
            string dateTo = String.Format("{0:yyyy-MM-dd}", txtToDate.Value);

            dgvCollections.DataSource = p.GetAllCollectionsByDate(dateFrom, dateTo);

            decimal sum = 0;
            for (int i = 0; i < dgvCollections.Rows.Count; i++)
            {
                sum += Convert.ToDecimal(dgvCollections.Rows[i].Cells[4].Value);
            }
            txtTotal.Text = sum.ToString();

        }

        private void txtToDate_ValueChanged(object sender, EventArgs e)
        {
            string dateFrom = String.Format("{0:yyyy-MM-dd}", txtFromDate.Value);
            string dateTo = String.Format("{0:yyyy-MM-dd}", txtToDate.Value);

            dgvCollections.DataSource = p.GetAllCollectionsByDate(dateFrom, dateTo);

            decimal sum = 0;
            for (int i = 0; i < dgvCollections.Rows.Count; i++)
            {
                sum += Convert.ToDecimal(dgvCollections.Rows[i].Cells[4].Value);
            }
            txtTotal.Text = sum.ToString();

        }
    }
}
