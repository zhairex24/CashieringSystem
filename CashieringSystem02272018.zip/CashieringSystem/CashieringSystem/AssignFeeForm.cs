﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;
using Telerik.WinControls.UI;

namespace CashieringSystem
{
    public partial class AssignFeeForm : Telerik.WinControls.UI.RadForm
    {
        public AssignFeeForm()
        {
            InitializeComponent();
        }

        Payment p = new Payment();
        Register r = new Register();

        private void AssignFeeForm_Load(object sender, EventArgs e)
        {
            AddHeaderCheckBox();
            hcb.MouseClick += new MouseEventHandler(HeaderCheckBox_MouseClick);

            dgvFees.DataSource = p.GetAllFees();
            dgvStudents.DataSource = r.ViewAllStudents();
            dgvStudents.Columns[1].IsVisible = false;
            dgvStudents.Columns[7].IsVisible = false;
            dgvStudents.Columns[9].IsVisible = false;
            dgvStudents.Columns[10].IsVisible = false;
            dgvStudents.Columns[11].IsVisible = false;
            dgvStudents.Columns[12].IsVisible = false;
            dgvStudents.Columns[13].IsVisible = false;
            dgvStudents.Columns[14].IsVisible = false;
            dgvStudents.Columns[15].IsVisible = false;

            dgvStudents.Columns[2].HeaderText = "Student ID";
            dgvStudents.Columns[3].HeaderText = "First name";
            dgvStudents.Columns[4].HeaderText = "Middle Name";
            dgvStudents.Columns[5].HeaderText = "Last Name";
            dgvStudents.Columns[6].HeaderText = "Scholarship Status";
            dgvStudents.Columns[8].HeaderText = "Course/Grade";

            dgvFees.Columns[1].HeaderText = "Fee ID";
            dgvFees.Columns[2].HeaderText = "Name of Fee";
            dgvFees.Columns[3].HeaderText = "Assign To";
            dgvFees.Columns[4].HeaderText = "Amount";
            
            dgvFees.Columns[2].Width = 190;
            dgvFees.Columns[4].Width = 100;
            dgvFees.Columns[3].Width = 280;

        }

        CheckBox hcb = null;
        bool IsHeaderCheckboxClicked = false;
        private void AddHeaderCheckBox()
        {
            hcb = new CheckBox();

            hcb.Size = new Size(15, 15);
            hcb.Location = new Point(25, 13);
            this.dgvStudents.Controls.Add(hcb);
        }

        private void HeadCheckBoxClick(CheckBox HCheckBox)
        {
            IsHeaderCheckboxClicked = true;

            foreach (GridViewRowInfo row in dgvStudents.Rows)
            {
                ((GridViewCellInfo)row.Cells["chk"]).Value = HCheckBox.Checked;
                dgvStudents.Refresh();
                IsHeaderCheckboxClicked = false;
            }
        }

        private void HeaderCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            HeadCheckBoxClick((CheckBox)sender);
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            string searchValue = txtSearch.Text;
            dgvStudents.DataSource = r.SearchStudentByValue(searchValue);
        }

        private void dgvFees_CellValueChanged(object sender, GridViewCellEventArgs e)
        {
            var columnIndex = 0;
            if (e.ColumnIndex == columnIndex)
            {
                var isChecked = (bool)dgvFees.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                if (isChecked)
                {

                    foreach (GridViewRowInfo row in dgvFees.Rows)
                    {
                        if (row.Index != e.RowIndex)
                        {

                            row.Cells[columnIndex].Value = !isChecked;

                        }
                    }

                }
            } 
        }

        private void btnSaveFee_Click(object sender, EventArgs e)
        {
             if (dgvAssignFee.Rows.Count == 0)
            {

                AFFMessageBox affMB = new AFFMessageBox();
                affMB.Show();

            }
            else
            {

                try
                {
                    for (int i = 0; i < dgvAssignFee.Rows.Count; i++)
                    {

                        int fee_id;
                        string student_id;
                        decimal amount;

                        fee_id = Convert.ToInt32(dgvAssignFee.Rows[i].Cells[1].Value.ToString());
                        student_id = dgvAssignFee.Rows[i].Cells[0].Value.ToString();
                        amount = Convert.ToDecimal(dgvAssignFee.Rows[i].Cells[2].Value.ToString());
                        p.AssignFee(amount, fee_id, student_id);
                    }


                }
                catch { }

                this.Controls.Clear();
                this.InitializeComponent();

                AddHeaderCheckBox();
                hcb.MouseClick += new MouseEventHandler(HeaderCheckBox_MouseClick);

                dgvFees.DataSource = p.GetAllFees();
                dgvStudents.DataSource = r.ViewAllStudents();
                dgvStudents.Columns[1].IsVisible = false;
                dgvStudents.Columns[7].IsVisible = false;
                dgvStudents.Columns[9].IsVisible = false;
                dgvStudents.Columns[10].IsVisible = false;
                dgvStudents.Columns[11].IsVisible = false;
                dgvStudents.Columns[13].IsVisible = false;
                dgvStudents.Columns[14].IsVisible = false;
                dgvStudents.Columns[15].IsVisible = false;

                dgvStudents.Columns[2].HeaderText = "Student ID";
                dgvStudents.Columns[3].HeaderText = "First name";
                dgvStudents.Columns[4].HeaderText = "Middle Name";
                dgvStudents.Columns[5].HeaderText = "Last Name";
                dgvStudents.Columns[6].HeaderText = "Scholarship Status";
                dgvStudents.Columns[8].HeaderText = "Course/Grade";

                dgvFees.Columns[1].HeaderText = "Fee ID";
                dgvFees.Columns[2].HeaderText = "Name of Fee";
                dgvFees.Columns[3].HeaderText = "Assign To";
                dgvFees.Columns[4].HeaderText = "Amount";

                dgvFees.Columns[2].Width = 190;
                dgvFees.Columns[4].Width = 100;
                dgvFees.Columns[3].Width = 280;

            }
        }

        private void btnAssign_Click(object sender, EventArgs e)
        {
            DataTable table = new DataTable();

            table.Columns.Add("Student ID");
            table.Columns.Add("Fee ID");
            table.Columns.Add("Amount");

            for (int i = 0; i < dgvStudents.Rows.Count; i++)
            {

                GridViewRowInfo row = dgvStudents.Rows[i];

                for (int y = 0; y < dgvFees.Rows.Count; y++)
                {

                    GridViewRowInfo r = dgvFees.Rows[y];
                    if (Convert.ToBoolean(row.Cells[0].Value) && Convert.ToBoolean(r.Cells[0].Value))
                    {
                        DataRow wr = table.NewRow();
                        wr[0] = row.Cells[2].Value.ToString();
                        wr[1] = r.Cells[1].Value.ToString();
                        wr[2] = r.Cells[4].Value.ToString();
                        table.Rows.Add(wr);
                    }
                }

            }

            for (int i = 0; i < table.Rows.Count; i++)
            {
                dgvAssignFee.Rows.Add(table.Rows[i][0].ToString()
                    , table.Rows[i][1].ToString(), table.Rows[i][2].ToString());
            }
        }

    }
}
