﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class AddPaymentForm : Telerik.WinControls.UI.RadForm
    {
        public AddPaymentForm()
        {
            InitializeComponent();
        }

        Payment p = new Payment();
        Inventory i = new Inventory();

        private void Payments_Load(object sender, EventArgs e)
        {
            try
            {

                dgvFees.DataSource = p.ViewAllFees();

                dgvFees.Columns[0].HeaderText = "FEE ID";
                dgvFees.Columns[1].HeaderText = "FEE NAME";
                dgvFees.Columns[2].HeaderText = "ASSIGN TO";
                dgvFees.Columns[3].HeaderText = "AMOUNT";
                dgvFees.Columns[0].IsVisible = false;

                dgvItems.DataSource = i.ViewAllItems();

                dgvItems.Columns[0].HeaderText = "ITEM ID";
                dgvItems.Columns[1].HeaderText = "ITEM CODE";
                dgvItems.Columns[2].HeaderText = "ITEM NAME";
                dgvItems.Columns[3].HeaderText = "COLOR";
                dgvItems.Columns[4].HeaderText = "SIZE";
                dgvItems.Columns[5].HeaderText = "QUANTITY";
                dgvItems.Columns[6].HeaderText = "AMOUNT";

            }
            catch {}
        }

        private void btnSaveFee_Click(object sender, EventArgs e)
        {
            try
            {
               
                decimal amount = Convert.ToDecimal(txtFeeAmount.Text);
                p.AddFees(txtFeeName.Text, amount, txtAssignTo.Text);
                txtFeeName.Text = null;
                txtFeeAmount.Text = null;
                txtAssignTo.Text = null;
                txtFeeId.Text = null;

                dgvFees.DataSource = p.ViewAllFees();

            }
            catch { }
        }

        private void btnUpdateFee_Click(object sender, EventArgs e)
        {
            
            try
            {
                int fee_id = Convert.ToInt32(txtFeeId.Text);
                decimal amount = Convert.ToDecimal(txtFeeAmount.Text);

                p.UpdateFee(txtFeeName.Text, amount, txtAssignTo.Text, fee_id);
                txtFeeName.Text = null;
                txtFeeAmount.Text = null;
                txtAssignTo.Text = null;
                txtFeeId.Text = null;

                dgvFees.DataSource = p.ViewAllFees();
            }
            catch {}

        }

        private void btnDeleteFee_Click(object sender, EventArgs e)
        {
            try
            {

                int fee_id = Convert.ToInt32(txtFeeId.Text);

                p.DeleteFee(fee_id);
                txtFeeName.Text = null;
                txtFeeAmount.Text = null;
                txtAssignTo.Text = null;
                txtFeeId.Text = null;

                dgvFees.DataSource = p.ViewAllFees();

            }
            catch { }
        }

        private void btnClearFee_Click(object sender, EventArgs e)
        {
           
        }

        private void btnSaveItem_Click(object sender, EventArgs e)
        {

            try
            {
                decimal amount = Convert.ToDecimal(txtItemAmount.Text);
                int quantity = Convert.ToInt32(txtQuantity.Text);

                i.AddItems(txtItemCode.Text, txtItemName.Text, amount, quantity, txtColor.Text, txtSize.Text);
                txtItemCode.Text = null;
                txtItemName.Text = null;
                txtItemAmount.Text = null;
                txtQuantity.Text = null;
                txtColor.Text = null;
                txtSize.Text = null;

                dgvItems.DataSource = i.ViewAllItems();

            }
            catch {}
            
        }

        private void btnUpdateItem_Click(object sender, EventArgs e)
        {
            

                decimal amount = Convert.ToDecimal(txtItemAmount.Text);
                int item_id = Convert.ToInt32(txtItemId.Text);

                i.UpdateItem(txtItemCode.Text, txtItemName.Text, amount, txtColor.Text, txtSize.Text, item_id);
                txtItemCode.Text = null;
                txtItemCode2.Text = null;
                txtItemName.Text = null;
                txtItemName2.Text = null;
                txtItemAmount.Text = null;
                txtQuantity.Text = null;
                txtQuantity2.Text = null;
                txtQuantityToAdd.Text = null;
                txtColor.Text = null;
                txtSize.Text = null;

                dgvItems.DataSource = i.ViewAllItems();

            
        }

        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            try
            {
                int item_id = Convert.ToInt32(txtItemId.Text);
                
                i.DeleteItem(item_id);

                txtItemCode.Text = null;
                txtItemCode2.Text = null;
                txtItemName.Text = null;
                txtItemName2.Text = null;
                txtItemAmount.Text = null;
                txtQuantity.Text = null;
                txtQuantity2.Text = null;
                txtQuantityToAdd.Text = null;
                txtColor.Text = null;
                txtSize.Text = null;

                dgvItems.DataSource = i.ViewAllItems();

            }
            catch { }
        }

        private void btnClearItem_Click(object sender, EventArgs e)
        {

        }

        private void dgvFees_CellDoubleClick(object sender, Telerik.WinControls.UI.GridViewCellEventArgs e)
        {
            txtFeeId.Text = this.dgvFees.CurrentRow.Cells[0].Value.ToString();
            txtFeeName.Text = this.dgvFees.CurrentRow.Cells[1].Value.ToString();
            txtFeeAmount.Text = this.dgvFees.CurrentRow.Cells[3].Value.ToString();
            txtAssignTo.Text = this.dgvFees.CurrentRow.Cells[2].Value.ToString();
        }

        private void txtFeeAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
        }

        private void dgvItems_CellDoubleClick(object sender, Telerik.WinControls.UI.GridViewCellEventArgs e)
        {

            txtItemId.Text = this.dgvItems.CurrentRow.Cells[0].Value.ToString();
            txtItemCode.Text = this.dgvItems.CurrentRow.Cells[1].Value.ToString();
            txtItemName.Text = this.dgvItems.CurrentRow.Cells[2].Value.ToString();
            txtColor.Text = this.dgvItems.CurrentRow.Cells[3].Value.ToString();
            txtSize.Text = this.dgvItems.CurrentRow.Cells[4].Value.ToString();
            txtQuantity.Text = this.dgvItems.CurrentRow.Cells[5].Value.ToString();
            txtItemAmount.Text = this.dgvItems.CurrentRow.Cells[6].Value.ToString();

            txtItemCode2.Text = this.dgvItems.CurrentRow.Cells[1].Value.ToString();
            txtItemName2.Text = this.dgvItems.CurrentRow.Cells[2].Value.ToString();
            txtQuantity2.Text = this.dgvItems.CurrentRow.Cells[5].Value.ToString();

        }

        private void btnAddQuantity_Click(object sender, EventArgs e)
        {

            int quantity = Convert.ToInt32(txtQuantityToAdd.Text);
            int quantity2 = Convert.ToInt32(txtQuantity2.Text) + Convert.ToInt32(txtQuantityToAdd.Text);
            int item_id = Convert.ToInt32(txtItemId.Text);

            i.AddQuantity(txtItemCode2.Text, item_id, quantity, quantity2);
            txtItemCode.Text = null;
            txtItemCode2.Text = null;
            txtItemName.Text = null;
            txtItemName2.Text = null;
            txtItemAmount.Text = null;
            txtQuantity.Text = null;
            txtQuantity2.Text = null;
            txtQuantityToAdd.Text = null;
            txtColor.Text = null;
            txtSize.Text = null;

            dgvItems.DataSource = i.ViewAllItems();

        }

    }
}
