﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using System.IO;
using Excel;
using MySql.Data.Entity;
using System.Data.OleDb;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class StudentForm : Telerik.WinControls.UI.RadForm
    {
        public StudentForm()
        {
            InitializeComponent();
        }

        private void btnSaveFee_Click(object sender, EventArgs e)
        {
            Register reg = new Register();
            string sy = txtFrom.Text + "-" + txtTo.Text;
            reg.addStudent(txtStudentNo.Text, txtFname.Text, txtMname.Text, txtLname.Text, txtScholarshipStatus.Text
                          , txtES.Text, txtCourse.Text, txtCollegeLevel.Text, txtSemester.Text, sy, txtEmail.Text
                          , txtHome.Text, txtStudentNo.Text);
            
        }

        private void btnImportExcel_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.txtPathFile.Text = ofd.FileName;
            }
        }

        private void btnLoadExcel_Click(object sender, EventArgs e)
        {
            string pathString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + txtPathFile.Text + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\";";
            OleDbConnection conn = new OleDbConnection(pathString);

            OleDbDataAdapter myDataAdapter = new OleDbDataAdapter("SELECT * FROM [" + txtSheet.Text + "$]", conn);
            DataTable dt = new DataTable();

            myDataAdapter.Fill(dt);

            dgvStudent.DataSource = dt;
        }

        private void btnSaveData_Click(object sender, EventArgs e)
        {
            Register reg = new Register();
            for (int i = 0; i < dgvStudent.Rows.Count; i++)
            {
                reg.addStudent(dgvStudent.Rows[i].Cells[0].Value.ToString(), dgvStudent.Rows[i].Cells[1].Value.ToString(),
                                dgvStudent.Rows[i].Cells[2].Value.ToString(), dgvStudent.Rows[i].Cells[3].Value.ToString(),
                                dgvStudent.Rows[i].Cells[4].Value.ToString(), dgvStudent.Rows[i].Cells[5].Value.ToString(),
                                dgvStudent.Rows[i].Cells[6].Value.ToString(), dgvStudent.Rows[i].Cells[7].Value.ToString(),
                                dgvStudent.Rows[i].Cells[8].Value.ToString(), dgvStudent.Rows[i].Cells[9].Value.ToString(),
                                dgvStudent.Rows[i].Cells[10].Value.ToString(), dgvStudent.Rows[i].Cells[11].Value.ToString(),
                                dgvStudent.Rows[i].Cells[12].Value.ToString());
            }
        }
    }
}
