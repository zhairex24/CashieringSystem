﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using CashieringSystem.Properties;
using System.Data;
using System.Windows.Forms;
using Telerik.WinControls.UI;


namespace CashieringSystem.Classes
{
    class Register
    {
        public const string saveStudent = "Student information is successfully added!";
        private string conString = Settings.Default.constring;
        private MySqlConnection conn;

        public void addStudent(string sn, string fname, string mname, string lname, string ss, string es,
                               string course, string yl, string s, string sy, string email, string ha, string sc)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("AddStudent", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_StudentNo", sn);
            cmd.Parameters.AddWithValue("_Fname", fname);
            cmd.Parameters.AddWithValue("_Mname", mname);
            cmd.Parameters.AddWithValue("_Lname", lname);
            cmd.Parameters.AddWithValue("_SStatus", ss);
            cmd.Parameters.AddWithValue("_EStatus", es);
            cmd.Parameters.AddWithValue("_Course", course);
            cmd.Parameters.AddWithValue("_YearLevel", yl);
            cmd.Parameters.AddWithValue("_Semester", s);
            cmd.Parameters.AddWithValue("_SchoolYear", sy);
            cmd.Parameters.AddWithValue("_Email", email);
            cmd.Parameters.AddWithValue("_HAddress", ha);
            cmd.Parameters.AddWithValue("_StudentContact", sc);
            cmd.ExecuteNonQuery();
            conn.Dispose();
            
            //MessageBox.Show(saveStudent, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public DataTable SearchStudentByValue(string value)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("StudentsViewAllByValue", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_SearchValue", value);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            conn.Dispose();
            return dt;
        }

        public DataTable ViewAllStudents()
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlDataAdapter mysqlDa = new MySqlDataAdapter("StudentsViewAll", conn);
            mysqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataTable dtblFee = new DataTable();
            mysqlDa.Fill(dtblFee);
            conn.Dispose();
            return dtblFee;
        }


        public DataTable ViewAllStudentsByPartial()
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlDataAdapter mysqlDa = new MySqlDataAdapter("ViewAllStudentsByPartial", conn);
            mysqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataTable dtblFee = new DataTable();
            mysqlDa.Fill(dtblFee);
            conn.Dispose();
            return dtblFee;
        }
    }
}
