﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using CashieringSystem.Properties;
using System.Data;
using Telerik.WinControls.UI;

namespace CashieringSystem.Classes
{
    class ServerConnection
    {
        public static string userType;
        public static string fname;
        public static string lname;
        public static string user_id;
        private MySqlConnection conn;
        private string conString = Settings.Default.constring;
        public const string saveConnection = "Connetion string has been saved!";
        public const string noConnection = "No Connection Founded.";
        public const string hasConnection = "Connection Founded.";
        public const string authenticator = "SQL Server!";

        public void db_connection()
        {
            try
            {
                conn = new MySqlConnection(conString);
                conn.Open();
            }
            catch (MySqlException e)
            {
                throw e;
            }
        }

        public void SaveConnectionString(string server, string db, string uid, string pw)
        {
            try
            {
                string constr = "SERVER=" + server +
                                ";DATABASE=" + db +
                                ";UID=" + uid +
                                ";PASSWORD=" + pw + ";";
                MySqlConnection sqlcon = new MySqlConnection(constr);
                sqlcon.Open();
                if (sqlcon.State == ConnectionState.Open)
                {
                    Settings.Default.dsource = server;
                    Settings.Default.dbname = db;
                    Settings.Default.user_id = uid;
                    Settings.Default.password = pw;
                    Settings.Default.constring = "SERVER='" + server + "';DATABASE='" + db +
                                                 "';UID='" + uid +
                                                 "';PASSWORD='" + pw + "';";
                    Settings.Default.Save();
                    MessageBox.Show(saveConnection, authenticator, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception)
            {
                MessageBox.Show(noConnection, authenticator, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void TestConnectionString(string server, string db, string uid, string pw)
        {
            try
            {
                string constr = "SERVER=" + server +
                                ";DATABASE=" + db +
                                ";UID=" + uid +
                                ";PASSWORD=" + pw + ";";
                MySqlConnection sqlcon1 = new MySqlConnection(constr);
                sqlcon1.Open();
                if (sqlcon1.State == ConnectionState.Open)
                {
                    MessageBox.Show(hasConnection, authenticator, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (MySqlException)
            {
                MessageBox.Show(noConnection, authenticator, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void ClearFields(RadTextBox server, Control db, Control uid, Control pw)
        {
            server.Clear();
            db.Text = null;
            uid.Text = null;
            pw.Text = null;
        }

        public void ShowCurrentConnectionString(Control server, Control db, Control uid, Control pw)
        {
            server.Text = Settings.Default.dsource;
            db.Text = Settings.Default.dbname;
            uid.Text = Settings.Default.user_id;
            pw.Text = Settings.Default.password;
        }

        public bool validate_login(string user, string pass)
        {
            db_connection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = "SELECT * FROM user_accounts WHERE username=@user AND password=@pass";
            cmd.Parameters.AddWithValue("@user", user);
            cmd.Parameters.AddWithValue("@pass", pass);
            cmd.Connection = conn;
            MySqlDataReader login = cmd.ExecuteReader();          
            if (login.Read())
            {
                userType = (login["account_type"].ToString());
                fname = (login["fname"].ToString());
                lname = (login["lname"].ToString());
                user_id = (login["id"].ToString());
                return true;
            }
            else
            {
                conn.Close();
                return false;
            }
        }
    }
}
