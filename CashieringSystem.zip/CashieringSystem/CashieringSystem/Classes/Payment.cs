﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using CashieringSystem.Properties;
using System.Data;
using System.Windows.Forms;
using Telerik.WinControls.UI;

namespace CashieringSystem.Classes
{
    class Payment
    {       
        public const string saveFee = "Successfully Added!";
        public const string updatedFee = "Successfully Updated!";
        public const string deletedFee = "Successfully Deleted!";
        public const string authenticator = "Saving Fee!";
        public const string confirmation = "Transactions cannot be reverted. Do you want to proceed?";
        private string conString = Settings.Default.constring;
        private MySqlConnection conn;

        public static DataTable items_to_pay;

        public void AddPayment(string n, decimal amount, string it, string at, string asst, int stocks) 
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("AddPayment", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_Name", n);
            cmd.Parameters.AddWithValue("_Amount", amount);
            cmd.Parameters.AddWithValue("_ItemType", it);
            cmd.Parameters.AddWithValue("_AppliedTo", at);
            cmd.Parameters.AddWithValue("_AssignTo", asst);
            cmd.Parameters.AddWithValue("_NoOfStocks", stocks);
            cmd.ExecuteNonQuery();
            MessageBox.Show(saveFee, authenticator, MessageBoxButtons.OK, MessageBoxIcon.Information);
            conn.Dispose();
        }

        public void UpdatePayment(string name, decimal amount, string it, string at, string asst, int stocks, int id)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("UpdatePayment", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_PayItemId", id);
            cmd.Parameters.AddWithValue("_Name", name);
            cmd.Parameters.AddWithValue("_Amount", amount);
            cmd.Parameters.AddWithValue("_ItemType", it);
            cmd.Parameters.AddWithValue("_AppliedTo", at);
            cmd.Parameters.AddWithValue("_AssignTo", asst);
            cmd.Parameters.AddWithValue("_NoOfStocks", stocks);
            
            cmd.ExecuteNonQuery();
            MessageBox.Show(updatedFee, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            conn.Dispose();
        }

        public void DeletePayment(int id)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("PaymentDeletedByID", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_PayItemId", id);
            cmd.ExecuteNonQuery();
            MessageBox.Show(deletedFee, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void ClearFields(Control name, Control amount, Control it, Control at, Control stocks)
        {
            name.Text = null;
            amount.Text = null;
            it.Text = null;
            at.Text = null;
            stocks.Text = null;

        }

        public DataTable ViewAllFees()
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlDataAdapter mysqlDa = new MySqlDataAdapter("GetAllPayments", conn);
            mysqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataTable dtblFee = new DataTable();
            mysqlDa.Fill(dtblFee);
            conn.Dispose();
            return dtblFee;
        }

        public string GenerateOR()
        { 
            string or = null;
            
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("InvoiceNumber", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            MySqlDataReader mysqlDR = cmd.ExecuteReader();

            if (mysqlDR.Read())
            {
                or = mysqlDR[0].ToString();
            }
            conn.Dispose();
            return or;
        }

        public string GetTransactionID()
        {
            string transac_id = null;

            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetTransactionID", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            MySqlDataReader mysqlDR = cmd.ExecuteReader();

            if (mysqlDR.Read())
            {
                transac_id = mysqlDR[0].ToString();
            }
            conn.Dispose();
            return transac_id;
           
        }

        public DataTable GetAllItemByFee()
        {
         
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetAllItemByFee", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            conn.Dispose();
            return dt;
        }

        public DataTable GetAllItemByOther()
        {

            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetAllItemByOther", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            conn.Dispose();
            return dt;
        }

        public void SaveTransaction(string payment_type, decimal amount_paid, decimal amount_tendered, decimal amount_change, string or, string user_id, string student_no)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("SaveTransaction", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_PaymentType", payment_type);
            cmd.Parameters.AddWithValue("_AmountPaid", amount_paid);
            cmd.Parameters.AddWithValue("_AmountTendered", amount_tendered);
            cmd.Parameters.AddWithValue("_AmountChange", amount_change);
            cmd.Parameters.AddWithValue("_OR", or);
            cmd.Parameters.AddWithValue("_UserId", user_id);
            cmd.Parameters.AddWithValue("_StudentNo", student_no);

            cmd.ExecuteNonQuery();
            conn.Dispose();
        }

        public void SaveTransactionDetail(int? item_quantity, decimal item_amount, string or, int pay_item_id, string stud_no)
        {
            
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("SaveTransactionDetail", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("_ItemName", item_name);
            cmd.Parameters.AddWithValue("_ItemQuantity", item_quantity);
            cmd.Parameters.AddWithValue("_ItemAmount", item_amount);
            cmd.Parameters.AddWithValue("_OR", or);
            cmd.Parameters.AddWithValue("_PayItemId", pay_item_id);
            cmd.Parameters.AddWithValue("_StudentId", stud_no);

            cmd.ExecuteNonQuery();
            conn.Dispose();
        }

        public DataSet GetTransaction(string or)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetTransaction", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_OR", or);
            cmd.ExecuteNonQuery();

            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "Data");
            conn.Dispose();
            return ds;
        }


        public DataSet GetTransactionDetail(string or)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetTransactionDetail", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_OR", or);
            cmd.ExecuteNonQuery();

            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "Data");
            conn.Dispose();
            return ds;
        }


        public string GetLatestORNumber()
        {
            string or_number = null;

            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetLatestORNumber", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            MySqlDataReader mysqlDR = cmd.ExecuteReader();

            if (mysqlDR.Read())
            {
                or_number = mysqlDR[0].ToString();
            }
            conn.Dispose();
            return or_number;

        }

        public DataTable GetFeesByStudentId(string student_id)
        {

            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetFeesByStudentId", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_StudentId", student_id);
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);

            conn.Dispose();
            return dt;
        }

        public void UpdateBalance(int pay_item_id, string student_id)
        {

            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("UpdateBalance", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_PayItemId", pay_item_id);
            cmd.Parameters.AddWithValue("_StudentId", student_id);

            cmd.ExecuteNonQuery();
            conn.Dispose();
        
        }

        public void AssignFee(decimal amount, int fee_id, string student_no)
        {

            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("AssignFee", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_Amount", amount);
            cmd.Parameters.AddWithValue("_FeeId", fee_id);
            cmd.Parameters.AddWithValue("_StudentId", student_no);

            cmd.ExecuteNonQuery();
            conn.Dispose();
        }
        
    }
}
