﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using CashieringSystem.Properties;
using System.Data;
using System.Windows.Forms;
using Telerik.WinControls.UI;

namespace CashieringSystem.Classes
{
    public class Payment
    {       
        public const string saveFee = "Successfully Added!";
        public const string updatedFee = "Successfully Updated!";
        public const string deletedFee = "Successfully Deleted!";
        public const string authenticator = "Saving Fee!";
        public const string confirmation = "Transactions cannot be reverted. Do you want to proceed?";
        private string conString = Settings.Default.constring;
        private MySqlConnection conn;

        public static DataTable items_to_pay;

        public void AddFee(string feeName, decimal amount, string at, string dept) 
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("AddFee", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_FeeName", feeName);
            cmd.Parameters.AddWithValue("_Amount", amount);
            cmd.Parameters.AddWithValue("_AppliedTo", at);
            cmd.Parameters.AddWithValue("_Department", dept);
            cmd.ExecuteNonQuery();
            MessageBox.Show(saveFee, authenticator, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void UpdateFee(string feeName, decimal amount, string at, string dept, int feeID)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("FeeAddOrEdit", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_FeeID", feeID);
            cmd.Parameters.AddWithValue("_FeeName", feeName);
            cmd.Parameters.AddWithValue("_Amount", amount);
            cmd.Parameters.AddWithValue("_AppliedTo", at);
            cmd.Parameters.AddWithValue("_Department", dept);
            cmd.ExecuteNonQuery();
            MessageBox.Show(updatedFee, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void DeleteFee(int feeID)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("FeeDeletedByID", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_FeeID", feeID);
            cmd.ExecuteNonQuery();
            MessageBox.Show(deletedFee, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void ClearFields(Control feeName, Control amount, Control at, Control dept)
        {
            feeName.Text = null;
            amount.Text = null;
            at.Text = null;
            dept.Text = null;
        }

        public DataTable ViewAllFees()
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlDataAdapter mysqlDa = new MySqlDataAdapter("FeeViewAll", conn);
            mysqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataTable dtblFee = new DataTable();
            mysqlDa.Fill(dtblFee);
            return dtblFee;
        }

        public string GenerateOR()
        { 
            string or = null;
            
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("InvoiceNumber", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            MySqlDataReader mysqlDR = cmd.ExecuteReader();

            if (mysqlDR.Read())
            {
                or = mysqlDR[0].ToString();
            }
            return or;
        }

        public string GetTransactionID()
        {
            string transac_id = null;

            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetTransactionID", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            MySqlDataReader mysqlDR = cmd.ExecuteReader();

            if (mysqlDR.Read())
            {
                transac_id = mysqlDR[0].ToString();
            }
            return transac_id;
           
        }

        public DataTable PaymentType(string value)
        {
           // PaymentTypeList ptl = new PaymentTypeList();
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("PaymentType", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_Category", value);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            return dt;

          /*  ptl.dgvItemsToPay.Rows.Clear();

            foreach (DataRow item in dt.Rows)
            {
                int n = ptl.dgvItemsToPay.Rows.Add();
                ptl.dgvItemsToPay.Rows[n].Cells[1].Value = item[0].ToString();
                ptl.dgvItemsToPay.Rows[n].Cells[2].Value = item[1].ToString();
            }
            */
        }

        
    }
}
