﻿namespace CashieringSystem
{
    partial class ORPrintView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.getTransactionDetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cashieringdbDataSet = new CashieringSystem.cashieringdbDataSet();
            this.getTransactionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.getTransactionDetailTableAdapter = new CashieringSystem.cashieringdbDataSetTableAdapters.GetTransactionDetailTableAdapter();
            this.getTransactionTableAdapter = new CashieringSystem.cashieringdbDataSetTableAdapters.GetTransactionTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.getTransactionDetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashieringdbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.getTransactionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // getTransactionDetailBindingSource
            // 
            this.getTransactionDetailBindingSource.DataMember = "GetTransactionDetail";
            this.getTransactionDetailBindingSource.DataSource = this.cashieringdbDataSet;
            // 
            // cashieringdbDataSet
            // 
            this.cashieringdbDataSet.DataSetName = "cashieringdbDataSet";
            this.cashieringdbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // getTransactionBindingSource
            // 
            this.getTransactionBindingSource.DataMember = "GetTransaction";
            this.getTransactionBindingSource.DataSource = this.cashieringdbDataSet;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "ORDataSet";
            reportDataSource1.Value = this.getTransactionDetailBindingSource;
            reportDataSource2.Name = "ORDataSet2";
            reportDataSource2.Value = this.getTransactionBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "CashieringSystem.ReportViewer.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(892, 570);
            this.reportViewer1.TabIndex = 0;
            // 
            // getTransactionDetailTableAdapter
            // 
            this.getTransactionDetailTableAdapter.ClearBeforeFill = true;
            // 
            // getTransactionTableAdapter
            // 
            this.getTransactionTableAdapter.ClearBeforeFill = true;
            // 
            // ORPrintView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 570);
            this.Controls.Add(this.reportViewer1);
            this.Name = "ORPrintView";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ORPrintView";
            this.ThemeName = "ControlDefault";
            this.Load += new System.EventHandler(this.ORPrintView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.getTransactionDetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashieringdbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.getTransactionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private cashieringdbDataSet cashieringdbDataSet;
        private System.Windows.Forms.BindingSource getTransactionDetailBindingSource;
        private System.Windows.Forms.BindingSource getTransactionBindingSource;
        private cashieringdbDataSetTableAdapters.GetTransactionDetailTableAdapter getTransactionDetailTableAdapter;
        private cashieringdbDataSetTableAdapters.GetTransactionTableAdapter getTransactionTableAdapter;
    }
}
