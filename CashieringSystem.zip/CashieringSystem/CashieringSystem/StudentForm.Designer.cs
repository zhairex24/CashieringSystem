﻿namespace CashieringSystem
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.RadListDataItem radListDataItem6 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem7 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem8 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem9 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem10 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem11 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem12 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem13 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem14 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem15 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem16 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem17 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem18 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem19 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem20 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem21 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem4 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem5 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem1 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem2 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem3 = new Telerik.WinControls.UI.RadListDataItem();
            this.radPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.to = new Telerik.WinControls.UI.RadLabel();
            this.from = new Telerik.WinControls.UI.RadLabel();
            this.schoolyear = new Telerik.WinControls.UI.RadLabel();
            this.semester = new Telerik.WinControls.UI.RadLabel();
            this.collegelevel = new Telerik.WinControls.UI.RadLabel();
            this.txtSemester = new Telerik.WinControls.UI.RadDropDownList();
            this.lname = new Telerik.WinControls.UI.RadLabel();
            this.txtCollegeLevel = new Telerik.WinControls.UI.RadDropDownList();
            this.mname = new Telerik.WinControls.UI.RadLabel();
            this.txtLname = new Telerik.WinControls.UI.RadTextBox();
            this.radPanel3 = new Telerik.WinControls.UI.RadPanel();
            this.txtMname = new Telerik.WinControls.UI.RadTextBox();
            this.btnClear = new Telerik.WinControls.UI.RadButton();
            this.course = new Telerik.WinControls.UI.RadLabel();
            this.txtCourse = new Telerik.WinControls.UI.RadDropDownList();
            this.fname = new Telerik.WinControls.UI.RadLabel();
            this.txtFname = new Telerik.WinControls.UI.RadTextBox();
            this.btnSaveFee = new Telerik.WinControls.UI.RadButton();
            this.radPanel2 = new Telerik.WinControls.UI.RadPanel();
            this.radPanel5 = new Telerik.WinControls.UI.RadPanel();
            this.btnLoadExcel = new Telerik.WinControls.UI.RadButton();
            this.btnImportExcel = new Telerik.WinControls.UI.RadButton();
            this.txtSheet = new Telerik.WinControls.UI.RadTextBox();
            this.txtPathFile = new Telerik.WinControls.UI.RadTextBox();
            this.dgvStudent = new Telerik.WinControls.UI.RadGridView();
            this.radPanel6 = new Telerik.WinControls.UI.RadPanel();
            this.btnSaveData = new Telerik.WinControls.UI.RadButton();
            this.radPanel4 = new Telerik.WinControls.UI.RadPanel();
            this.radButton1 = new Telerik.WinControls.UI.RadButton();
            this.office2013LightTheme1 = new Telerik.WinControls.Themes.Office2013LightTheme();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.txtStudentNo = new Telerik.WinControls.UI.RadTextBox();
            this.txtTo = new Telerik.WinControls.UI.RadTextBox();
            this.txtFrom = new Telerik.WinControls.UI.RadTextBox();
            this.txtScholarshipStatus = new Telerik.WinControls.UI.RadDropDownList();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.txtEmail = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.txtHome = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.txtContact = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.txtES = new Telerik.WinControls.UI.RadDropDownList();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).BeginInit();
            this.radPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.to)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.from)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolyear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.semester)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.collegelevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSemester)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCollegeLevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.course)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCourse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).BeginInit();
            this.radPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel5)).BeginInit();
            this.radPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnLoadExcel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnImportExcel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSheet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPathFile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent.MasterTemplate)).BeginInit();
            this.dgvStudent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel6)).BeginInit();
            this.radPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel4)).BeginInit();
            this.radPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtStudentNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtScholarshipStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContact)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtES)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radPanel1
            // 
            this.radPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.radPanel1.Controls.Add(this.txtES);
            this.radPanel1.Controls.Add(this.radLabel6);
            this.radPanel1.Controls.Add(this.radLabel5);
            this.radPanel1.Controls.Add(this.txtContact);
            this.radPanel1.Controls.Add(this.radLabel4);
            this.radPanel1.Controls.Add(this.radLabel3);
            this.radPanel1.Controls.Add(this.txtHome);
            this.radPanel1.Controls.Add(this.txtEmail);
            this.radPanel1.Controls.Add(this.txtScholarshipStatus);
            this.radPanel1.Controls.Add(this.txtTo);
            this.radPanel1.Controls.Add(this.txtFrom);
            this.radPanel1.Controls.Add(this.radLabel1);
            this.radPanel1.Controls.Add(this.radLabel2);
            this.radPanel1.Controls.Add(this.txtStudentNo);
            this.radPanel1.Controls.Add(this.to);
            this.radPanel1.Controls.Add(this.from);
            this.radPanel1.Controls.Add(this.schoolyear);
            this.radPanel1.Controls.Add(this.semester);
            this.radPanel1.Controls.Add(this.collegelevel);
            this.radPanel1.Controls.Add(this.txtSemester);
            this.radPanel1.Controls.Add(this.lname);
            this.radPanel1.Controls.Add(this.txtCollegeLevel);
            this.radPanel1.Controls.Add(this.mname);
            this.radPanel1.Controls.Add(this.txtLname);
            this.radPanel1.Controls.Add(this.radPanel3);
            this.radPanel1.Controls.Add(this.txtMname);
            this.radPanel1.Controls.Add(this.btnClear);
            this.radPanel1.Controls.Add(this.course);
            this.radPanel1.Controls.Add(this.txtCourse);
            this.radPanel1.Controls.Add(this.fname);
            this.radPanel1.Controls.Add(this.txtFname);
            this.radPanel1.Controls.Add(this.btnSaveFee);
            this.radPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.radPanel1.Location = new System.Drawing.Point(0, 0);
            this.radPanel1.Name = "radPanel1";
            this.radPanel1.Size = new System.Drawing.Size(402, 697);
            this.radPanel1.TabIndex = 8;
            this.radPanel1.ThemeName = "Office2013Light";
            this.radPanel1.UseCompatibleTextRendering = false;
            // 
            // to
            // 
            this.to.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.to.Location = new System.Drawing.Point(268, 308);
            this.to.Name = "to";
            this.to.Size = new System.Drawing.Size(28, 24);
            this.to.TabIndex = 18;
            this.to.Text = "To:";
            this.to.ThemeName = "Office2013Light";
            // 
            // from
            // 
            this.from.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.from.Location = new System.Drawing.Point(140, 309);
            this.from.Name = "from";
            this.from.Size = new System.Drawing.Size(46, 24);
            this.from.TabIndex = 17;
            this.from.Text = "From:";
            this.from.ThemeName = "Office2013Light";
            // 
            // schoolyear
            // 
            this.schoolyear.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.schoolyear.Location = new System.Drawing.Point(25, 309);
            this.schoolyear.Name = "schoolyear";
            this.schoolyear.Size = new System.Drawing.Size(91, 24);
            this.schoolyear.TabIndex = 16;
            this.schoolyear.Text = "School Year:";
            this.schoolyear.ThemeName = "Office2013Light";
            // 
            // semester
            // 
            this.semester.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.semester.Location = new System.Drawing.Point(24, 275);
            this.semester.Name = "semester";
            this.semester.Size = new System.Drawing.Size(74, 24);
            this.semester.TabIndex = 14;
            this.semester.Text = "Semester:";
            this.semester.ThemeName = "Office2013Light";
            // 
            // collegelevel
            // 
            this.collegelevel.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.collegelevel.Location = new System.Drawing.Point(25, 239);
            this.collegelevel.Name = "collegelevel";
            this.collegelevel.Size = new System.Drawing.Size(101, 24);
            this.collegelevel.TabIndex = 12;
            this.collegelevel.Text = "College Level:";
            this.collegelevel.ThemeName = "Office2013Light";
            // 
            // txtSemester
            // 
            this.txtSemester.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem6.Text = "1";
            radListDataItem6.TextWrap = true;
            radListDataItem7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem7.Text = "2";
            radListDataItem7.TextWrap = true;
            this.txtSemester.Items.Add(radListDataItem6);
            this.txtSemester.Items.Add(radListDataItem7);
            this.txtSemester.Location = new System.Drawing.Point(144, 276);
            this.txtSemester.Name = "txtSemester";
            // 
            // 
            // 
            this.txtSemester.RootElement.StretchVertically = true;
            this.txtSemester.Size = new System.Drawing.Size(235, 21);
            this.txtSemester.TabIndex = 13;
            this.txtSemester.ThemeName = "Office2013Light";
            // 
            // lname
            // 
            this.lname.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lname.Location = new System.Drawing.Point(23, 167);
            this.lname.Name = "lname";
            this.lname.Size = new System.Drawing.Size(83, 24);
            this.lname.TabIndex = 9;
            this.lname.Text = "Last Name:";
            this.lname.ThemeName = "Office2013Light";
            // 
            // txtCollegeLevel
            // 
            this.txtCollegeLevel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem8.Text = "1";
            radListDataItem8.TextWrap = true;
            radListDataItem9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem9.Text = "2";
            radListDataItem9.TextWrap = true;
            radListDataItem10.Text = "3";
            radListDataItem10.TextWrap = true;
            radListDataItem11.Text = "4";
            radListDataItem11.TextWrap = true;
            radListDataItem12.Text = "5";
            radListDataItem12.TextWrap = true;
            this.txtCollegeLevel.Items.Add(radListDataItem8);
            this.txtCollegeLevel.Items.Add(radListDataItem9);
            this.txtCollegeLevel.Items.Add(radListDataItem10);
            this.txtCollegeLevel.Items.Add(radListDataItem11);
            this.txtCollegeLevel.Items.Add(radListDataItem12);
            this.txtCollegeLevel.Location = new System.Drawing.Point(144, 240);
            this.txtCollegeLevel.Name = "txtCollegeLevel";
            // 
            // 
            // 
            this.txtCollegeLevel.RootElement.StretchVertically = true;
            this.txtCollegeLevel.Size = new System.Drawing.Size(235, 21);
            this.txtCollegeLevel.TabIndex = 11;
            this.txtCollegeLevel.ThemeName = "Office2013Light";
            // 
            // mname
            // 
            this.mname.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mname.Location = new System.Drawing.Point(23, 130);
            this.mname.Name = "mname";
            this.mname.Size = new System.Drawing.Size(104, 24);
            this.mname.TabIndex = 9;
            this.mname.Text = "Middle Name:";
            this.mname.ThemeName = "Office2013Light";
            // 
            // txtLname
            // 
            this.txtLname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLname.Location = new System.Drawing.Point(144, 167);
            this.txtLname.Name = "txtLname";
            this.txtLname.Size = new System.Drawing.Size(235, 23);
            this.txtLname.TabIndex = 8;
            this.txtLname.ThemeName = "Office2013Light";
            // 
            // radPanel3
            // 
            this.radPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.radPanel3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radPanel3.Location = new System.Drawing.Point(0, 0);
            this.radPanel3.Name = "radPanel3";
            this.radPanel3.Size = new System.Drawing.Size(402, 42);
            this.radPanel3.TabIndex = 8;
            this.radPanel3.Text = "Add Student";
            this.radPanel3.ThemeName = "Office2013Light";
            // 
            // txtMname
            // 
            this.txtMname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMname.Location = new System.Drawing.Point(144, 130);
            this.txtMname.Name = "txtMname";
            this.txtMname.Size = new System.Drawing.Size(235, 23);
            this.txtMname.TabIndex = 8;
            this.txtMname.ThemeName = "Office2013Light";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(242, 537);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(65, 32);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "Clear";
            this.btnClear.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnClear.GetChildAt(0))).Text = "Clear";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnClear.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // course
            // 
            this.course.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course.Location = new System.Drawing.Point(24, 203);
            this.course.Name = "course";
            this.course.Size = new System.Drawing.Size(58, 24);
            this.course.TabIndex = 10;
            this.course.Text = "Course:";
            this.course.ThemeName = "Office2013Light";
            // 
            // txtCourse
            // 
            this.txtCourse.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem13.Text = "B.A. in Broadcasting";
            radListDataItem13.TextWrap = true;
            radListDataItem14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem14.Text = "B.S. in Information System";
            radListDataItem14.TextWrap = true;
            radListDataItem15.Text = "B.S. in Accounting Technology";
            radListDataItem15.TextWrap = true;
            radListDataItem16.Text = "B.S. in Accountancy";
            radListDataItem16.TextWrap = true;
            radListDataItem17.Text = "International Cookery";
            radListDataItem17.TextWrap = true;
            radListDataItem18.Text = "Office Management";
            radListDataItem18.TextWrap = true;
            radListDataItem19.Text = "Associate in Computer Technology";
            radListDataItem19.TextWrap = true;
            radListDataItem20.Text = "Mass Communication";
            radListDataItem20.TextWrap = true;
            radListDataItem21.Text = "B.S. in Social Work";
            radListDataItem21.TextWrap = true;
            this.txtCourse.Items.Add(radListDataItem13);
            this.txtCourse.Items.Add(radListDataItem14);
            this.txtCourse.Items.Add(radListDataItem15);
            this.txtCourse.Items.Add(radListDataItem16);
            this.txtCourse.Items.Add(radListDataItem17);
            this.txtCourse.Items.Add(radListDataItem18);
            this.txtCourse.Items.Add(radListDataItem19);
            this.txtCourse.Items.Add(radListDataItem20);
            this.txtCourse.Items.Add(radListDataItem21);
            this.txtCourse.Location = new System.Drawing.Point(144, 204);
            this.txtCourse.Name = "txtCourse";
            // 
            // 
            // 
            this.txtCourse.RootElement.StretchVertically = true;
            this.txtCourse.Size = new System.Drawing.Size(235, 21);
            this.txtCourse.TabIndex = 2;
            this.txtCourse.ThemeName = "Office2013Light";
            // 
            // fname
            // 
            this.fname.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fname.Location = new System.Drawing.Point(23, 95);
            this.fname.Name = "fname";
            this.fname.Size = new System.Drawing.Size(84, 24);
            this.fname.TabIndex = 7;
            this.fname.Text = "First Name:";
            this.fname.ThemeName = "Office2013Light";
            // 
            // txtFname
            // 
            this.txtFname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFname.Location = new System.Drawing.Point(144, 95);
            this.txtFname.Name = "txtFname";
            this.txtFname.Size = new System.Drawing.Size(235, 23);
            this.txtFname.TabIndex = 0;
            this.txtFname.ThemeName = "Office2013Light";
            // 
            // btnSaveFee
            // 
            this.btnSaveFee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnSaveFee.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnSaveFee.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveFee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnSaveFee.Location = new System.Drawing.Point(313, 537);
            this.btnSaveFee.Name = "btnSaveFee";
            this.btnSaveFee.Size = new System.Drawing.Size(65, 31);
            this.btnSaveFee.TabIndex = 4;
            this.btnSaveFee.Text = "Save";
            this.btnSaveFee.ThemeName = "Office2013Light";
            this.btnSaveFee.Click += new System.EventHandler(this.btnSaveFee_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).Text = "Save";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // radPanel2
            // 
            this.radPanel2.Controls.Add(this.radPanel5);
            this.radPanel2.Controls.Add(this.dgvStudent);
            this.radPanel2.Controls.Add(this.radPanel4);
            this.radPanel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.radPanel2.Location = new System.Drawing.Point(418, 0);
            this.radPanel2.Name = "radPanel2";
            this.radPanel2.Size = new System.Drawing.Size(940, 697);
            this.radPanel2.TabIndex = 13;
            // 
            // radPanel5
            // 
            this.radPanel5.Controls.Add(this.btnLoadExcel);
            this.radPanel5.Controls.Add(this.btnImportExcel);
            this.radPanel5.Controls.Add(this.txtSheet);
            this.radPanel5.Controls.Add(this.txtPathFile);
            this.radPanel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.radPanel5.Location = new System.Drawing.Point(0, 623);
            this.radPanel5.Name = "radPanel5";
            this.radPanel5.Size = new System.Drawing.Size(940, 74);
            this.radPanel5.TabIndex = 16;
            // 
            // btnLoadExcel
            // 
            this.btnLoadExcel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadExcel.Location = new System.Drawing.Point(609, 38);
            this.btnLoadExcel.Name = "btnLoadExcel";
            this.btnLoadExcel.Size = new System.Drawing.Size(82, 23);
            this.btnLoadExcel.TabIndex = 22;
            this.btnLoadExcel.Text = "Load Excel";
            this.btnLoadExcel.ThemeName = "Office2013Light";
            this.btnLoadExcel.Click += new System.EventHandler(this.btnLoadExcel_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnLoadExcel.GetChildAt(0))).Text = "Load Excel";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnLoadExcel.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnImportExcel
            // 
            this.btnImportExcel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImportExcel.Location = new System.Drawing.Point(609, 9);
            this.btnImportExcel.Name = "btnImportExcel";
            this.btnImportExcel.Size = new System.Drawing.Size(82, 23);
            this.btnImportExcel.TabIndex = 20;
            this.btnImportExcel.Text = "Import Excel";
            this.btnImportExcel.ThemeName = "Office2013Light";
            this.btnImportExcel.Click += new System.EventHandler(this.btnImportExcel_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnImportExcel.GetChildAt(0))).Text = "Import Excel";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnImportExcel.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // txtSheet
            // 
            this.txtSheet.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSheet.Location = new System.Drawing.Point(697, 37);
            this.txtSheet.Name = "txtSheet";
            this.txtSheet.Size = new System.Drawing.Size(235, 23);
            this.txtSheet.TabIndex = 21;
            this.txtSheet.ThemeName = "Office2013Light";
            // 
            // txtPathFile
            // 
            this.txtPathFile.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPathFile.Location = new System.Drawing.Point(697, 8);
            this.txtPathFile.Name = "txtPathFile";
            this.txtPathFile.Size = new System.Drawing.Size(235, 23);
            this.txtPathFile.TabIndex = 19;
            this.txtPathFile.ThemeName = "Office2013Light";
            // 
            // dgvStudent
            // 
            this.dgvStudent.AutoSizeRows = true;
            this.dgvStudent.Controls.Add(this.radPanel6);
            this.dgvStudent.Location = new System.Drawing.Point(0, 38);
            // 
            // dgvStudent
            // 
            this.dgvStudent.MasterTemplate.AllowAddNewRow = false;
            this.dgvStudent.MasterTemplate.AllowCellContextMenu = false;
            this.dgvStudent.MasterTemplate.AllowColumnChooser = false;
            this.dgvStudent.MasterTemplate.AllowColumnHeaderContextMenu = false;
            this.dgvStudent.MasterTemplate.AllowColumnReorder = false;
            this.dgvStudent.MasterTemplate.AllowColumnResize = false;
            this.dgvStudent.MasterTemplate.AllowDragToGroup = false;
            this.dgvStudent.MasterTemplate.AllowRowResize = false;
            this.dgvStudent.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            this.dgvStudent.MasterTemplate.ShowFilteringRow = false;
            this.dgvStudent.Name = "dgvStudent";
            this.dgvStudent.ShowCellErrors = false;
            this.dgvStudent.ShowGroupPanel = false;
            this.dgvStudent.ShowItemToolTips = false;
            this.dgvStudent.Size = new System.Drawing.Size(940, 587);
            this.dgvStudent.TabIndex = 15;
            this.dgvStudent.Text = "radGridView1";
            this.dgvStudent.ThemeName = "Office2013Light";
            // 
            // radPanel6
            // 
            this.radPanel6.Controls.Add(this.btnSaveData);
            this.radPanel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.radPanel6.Location = new System.Drawing.Point(0, 0);
            this.radPanel6.Name = "radPanel6";
            this.radPanel6.Size = new System.Drawing.Size(940, 45);
            this.radPanel6.TabIndex = 17;
            // 
            // btnSaveData
            // 
            this.btnSaveData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnSaveData.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnSaveData.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveData.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnSaveData.Location = new System.Drawing.Point(854, 6);
            this.btnSaveData.Name = "btnSaveData";
            this.btnSaveData.Size = new System.Drawing.Size(78, 31);
            this.btnSaveData.TabIndex = 6;
            this.btnSaveData.Text = "Save Data";
            this.btnSaveData.ThemeName = "Office2013Light";
            this.btnSaveData.Click += new System.EventHandler(this.btnSaveData_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveData.GetChildAt(0))).Text = "Save Data";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveData.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveData.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveData.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveData.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveData.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveData.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveData.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveData.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveData.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveData.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveData.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnSaveData.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // radPanel4
            // 
            this.radPanel4.Controls.Add(this.radButton1);
            this.radPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.radPanel4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radPanel4.Location = new System.Drawing.Point(0, 0);
            this.radPanel4.Name = "radPanel4";
            this.radPanel4.Size = new System.Drawing.Size(940, 42);
            this.radPanel4.TabIndex = 9;
            this.radPanel4.Text = "List of Student";
            this.radPanel4.ThemeName = "Office2013Light";
            // 
            // radButton1
            // 
            this.radButton1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radButton1.Location = new System.Drawing.Point(302, 47);
            this.radButton1.Name = "radButton1";
            this.radButton1.Size = new System.Drawing.Size(65, 32);
            this.radButton1.TabIndex = 12;
            this.radButton1.Text = "Delete";
            this.radButton1.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadButtonElement)(this.radButton1.GetChildAt(0))).Text = "Delete";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.radButton1.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.radButton1.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // radLabel2
            // 
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel2.Location = new System.Drawing.Point(23, 60);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(92, 24);
            this.radLabel2.TabIndex = 25;
            this.radLabel2.Text = "Student No.:";
            this.radLabel2.ThemeName = "Office2013Light";
            // 
            // txtStudentNo
            // 
            this.txtStudentNo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStudentNo.Location = new System.Drawing.Point(144, 60);
            this.txtStudentNo.Name = "txtStudentNo";
            this.txtStudentNo.Size = new System.Drawing.Size(235, 23);
            this.txtStudentNo.TabIndex = 24;
            this.txtStudentNo.ThemeName = "Office2013Light";
            // 
            // txtTo
            // 
            this.txtTo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTo.Location = new System.Drawing.Point(295, 309);
            this.txtTo.Name = "txtTo";
            this.txtTo.Size = new System.Drawing.Size(83, 23);
            this.txtTo.TabIndex = 29;
            this.txtTo.ThemeName = "Office2013Light";
            // 
            // txtFrom
            // 
            this.txtFrom.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFrom.Location = new System.Drawing.Point(185, 309);
            this.txtFrom.Name = "txtFrom";
            this.txtFrom.Size = new System.Drawing.Size(81, 23);
            this.txtFrom.TabIndex = 28;
            this.txtFrom.ThemeName = "Office2013Light";
            // 
            // txtScholarshipStatus
            // 
            this.txtScholarshipStatus.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem4.Text = "Full";
            radListDataItem4.TextWrap = true;
            radListDataItem5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem5.Text = "Partial";
            radListDataItem5.TextWrap = true;
            this.txtScholarshipStatus.Items.Add(radListDataItem4);
            this.txtScholarshipStatus.Items.Add(radListDataItem5);
            this.txtScholarshipStatus.Location = new System.Drawing.Point(185, 347);
            this.txtScholarshipStatus.Name = "txtScholarshipStatus";
            // 
            // 
            // 
            this.txtScholarshipStatus.RootElement.StretchVertically = true;
            this.txtScholarshipStatus.Size = new System.Drawing.Size(194, 21);
            this.txtScholarshipStatus.TabIndex = 30;
            this.txtScholarshipStatus.ThemeName = "Office2013Light";
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.Location = new System.Drawing.Point(25, 344);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(135, 24);
            this.radLabel1.TabIndex = 27;
            this.radLabel1.Text = "Scholarship Status:";
            this.radLabel1.ThemeName = "Office2013Light";
            // 
            // radLabel3
            // 
            this.radLabel3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel3.Location = new System.Drawing.Point(23, 417);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(106, 24);
            this.radLabel3.TabIndex = 32;
            this.radLabel3.Text = "Email Address:";
            this.radLabel3.ThemeName = "Office2013Light";
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(144, 417);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(235, 23);
            this.txtEmail.TabIndex = 31;
            this.txtEmail.ThemeName = "Office2013Light";
            // 
            // radLabel4
            // 
            this.radLabel4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel4.Location = new System.Drawing.Point(23, 455);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(111, 24);
            this.radLabel4.TabIndex = 34;
            this.radLabel4.Text = "Home Address:";
            this.radLabel4.ThemeName = "Office2013Light";
            // 
            // txtHome
            // 
            this.txtHome.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHome.Location = new System.Drawing.Point(144, 455);
            this.txtHome.Name = "txtHome";
            this.txtHome.Size = new System.Drawing.Size(235, 23);
            this.txtHome.TabIndex = 33;
            this.txtHome.ThemeName = "Office2013Light";
            // 
            // radLabel5
            // 
            this.radLabel5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel5.Location = new System.Drawing.Point(23, 494);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(92, 24);
            this.radLabel5.TabIndex = 36;
            this.radLabel5.Text = "Contact No.:";
            this.radLabel5.ThemeName = "Office2013Light";
            // 
            // txtContact
            // 
            this.txtContact.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContact.Location = new System.Drawing.Point(144, 494);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(235, 23);
            this.txtContact.TabIndex = 35;
            this.txtContact.ThemeName = "Office2013Light";
            // 
            // radLabel6
            // 
            this.radLabel6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel6.Location = new System.Drawing.Point(23, 381);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(131, 24);
            this.radLabel6.TabIndex = 38;
            this.radLabel6.Text = "Enrollment Status:";
            this.radLabel6.ThemeName = "Office2013Light";
            // 
            // txtES
            // 
            this.txtES.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem1.Text = "PartiallyEnrolled";
            radListDataItem1.TextWrap = true;
            radListDataItem2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem2.Text = "OfficiallyEnrolled";
            radListDataItem2.TextWrap = true;
            radListDataItem3.Text = "NotEnrolled";
            radListDataItem3.TextWrap = true;
            this.txtES.Items.Add(radListDataItem1);
            this.txtES.Items.Add(radListDataItem2);
            this.txtES.Items.Add(radListDataItem3);
            this.txtES.Location = new System.Drawing.Point(185, 383);
            this.txtES.Name = "txtES";
            // 
            // 
            // 
            this.txtES.RootElement.StretchVertically = true;
            this.txtES.Size = new System.Drawing.Size(193, 21);
            this.txtES.TabIndex = 39;
            this.txtES.ThemeName = "Office2013Light";
            // 
            // StudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 697);
            this.Controls.Add(this.radPanel2);
            this.Controls.Add(this.radPanel1);
            this.Name = "StudentForm";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "Student";
            this.ThemeName = "Office2013Light";
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).EndInit();
            this.radPanel1.ResumeLayout(false);
            this.radPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.to)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.from)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolyear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.semester)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.collegelevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSemester)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCollegeLevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.course)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCourse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).EndInit();
            this.radPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radPanel5)).EndInit();
            this.radPanel5.ResumeLayout(false);
            this.radPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnLoadExcel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnImportExcel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSheet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPathFile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent)).EndInit();
            this.dgvStudent.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radPanel6)).EndInit();
            this.radPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel4)).EndInit();
            this.radPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtStudentNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtScholarshipStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContact)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtES)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadPanel radPanel1;
        private Telerik.WinControls.UI.RadLabel lname;
        private Telerik.WinControls.UI.RadLabel mname;
        private Telerik.WinControls.UI.RadTextBox txtLname;
        private Telerik.WinControls.UI.RadPanel radPanel3;
        private Telerik.WinControls.UI.RadTextBox txtMname;
        private Telerik.WinControls.UI.RadButton btnClear;
        private Telerik.WinControls.UI.RadLabel course;
        private Telerik.WinControls.UI.RadDropDownList txtCourse;
        private Telerik.WinControls.UI.RadLabel fname;
        private Telerik.WinControls.UI.RadTextBox txtFname;
        private Telerik.WinControls.UI.RadButton btnSaveFee;
        private Telerik.WinControls.UI.RadLabel schoolyear;
        private Telerik.WinControls.UI.RadLabel semester;
        private Telerik.WinControls.UI.RadLabel collegelevel;
        private Telerik.WinControls.UI.RadDropDownList txtSemester;
        private Telerik.WinControls.UI.RadDropDownList txtCollegeLevel;
        private Telerik.WinControls.UI.RadPanel radPanel2;
        private Telerik.WinControls.UI.RadPanel radPanel4;
        private Telerik.WinControls.UI.RadButton radButton1;
        private Telerik.WinControls.UI.RadLabel to;
        private Telerik.WinControls.UI.RadLabel from;
        private Telerik.WinControls.Themes.Office2013LightTheme office2013LightTheme1;
        private Telerik.WinControls.UI.RadGridView dgvStudent;
        private Telerik.WinControls.UI.RadPanel radPanel6;
        private Telerik.WinControls.UI.RadButton btnSaveData;
        private Telerik.WinControls.UI.RadButton btnLoadExcel;
        private Telerik.WinControls.UI.RadButton btnImportExcel;
        private Telerik.WinControls.UI.RadTextBox txtSheet;
        private Telerik.WinControls.UI.RadTextBox txtPathFile;
        private Telerik.WinControls.UI.RadPanel radPanel5;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadTextBox txtContact;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadTextBox txtHome;
        private Telerik.WinControls.UI.RadTextBox txtEmail;
        private Telerik.WinControls.UI.RadDropDownList txtScholarshipStatus;
        private Telerik.WinControls.UI.RadTextBox txtTo;
        private Telerik.WinControls.UI.RadTextBox txtFrom;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadTextBox txtStudentNo;
        private Telerik.WinControls.UI.RadDropDownList txtES;
        private Telerik.WinControls.UI.RadLabel radLabel6;
    }
}
