﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class CashieringDashboard : Telerik.WinControls.UI.RadForm
    {
        public CashieringDashboard()
        {
            InitializeComponent();
        }

        private FeeForm ff;
        private EmployeeForm ef;
        private StudentForm sf;
        private Search s;
        private AssignFeeForm aff;

        private void subMenuEmployee_Click(object sender, EventArgs e)
        {
            if (ef != null)
            {
                ef.WindowState = FormWindowState.Normal;
                ef.Focus();
            }
            else
            {
                ef = new EmployeeForm();
                ef.MdiParent = this;
                ef.FormClosed += (o, ea) => ef = null;
                ef.Show();
            }
        }

        private void subMenuStudent_Click(object sender, EventArgs e)
        {
            if (sf != null)
            {
                sf.WindowState = FormWindowState.Normal;
                sf.Focus();
            }
            else
            {
                sf = new StudentForm();
                sf.MdiParent = this;
                sf.FormClosed += (o, ea) => sf = null;
                sf.Show();
            }
        }

        private void CashieringDashboard_Load(object sender, EventArgs e)
        {

            nameL.Text = ServerConnection.fname + " " + ServerConnection.lname;
            positionL.Text = ServerConnection.userType;
            userIdTxt.Text = ServerConnection.user_id;
            
        }

        private void search_Click(object sender, EventArgs e)
        {
            if (s != null)
            {
                s.WindowState = FormWindowState.Normal;
                s.Focus();
            }
            else
            {
                s = new Search();
                s.MdiParent = this;
                s.FormClosed += (o, ea) => s = null;
                s.Show();
            }
        }

        private void subMenuAddFees_Click(object sender, EventArgs e)
        {
            if (ff != null)
            {
                ff.WindowState = FormWindowState.Normal;
                ff.Focus();
            }
            else
            {
                ff = new FeeForm();
                ff.MdiParent = this;
                ff.FormClosed += (o, ea) => ff = null;
                ff.Show();
            }
        }

        private void subMenuAssignFees_Click(object sender, EventArgs e)
        {
            if (aff != null)
            {
                aff.WindowState = FormWindowState.Normal;
                aff.Focus();
            }
            else
            {
                aff = new AssignFeeForm();
                aff.MdiParent = this;
                aff.FormClosed += (o, ea) => aff = null;
                aff.Show();
            }
        }
    }

}
