﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class FeeForm : Telerik.WinControls.UI.RadForm
    {
        public FeeForm()
        {
            InitializeComponent();
        }

        Payment payment = new Payment();

        private void radDropDownList1_SelectedIndexChanged(object sender, Telerik.WinControls.UI.Data.PositionChangedEventArgs e)
        {
            if (this.txtItemType.SelectedIndex > -1)
            {
                string appliedTo = this.txtItemType.SelectedItem.Text;
            }
        }

        private void btnSaveFee_Click(object sender, EventArgs e)
        {
            
            try
            {

                string n = txtName.Text;
                decimal amnt = decimal.Parse(txtAmount.Text);
                string it = txtItemType.Text;
                string at = txtAppliedTo.Text;
                string asst = txtAssignTo.Text;
                int stocks;

                if (txtNoOfStocks.Text == "")
                {

                    stocks = 0;

                    payment.AddPayment(n, amnt, it, at, asst, stocks);

                    if (txtAssignTo.Text == "")
                    {

                        stocks = 0;

                        payment.AddPayment(n, amnt, it, at, asst, stocks);

                    }

                }
                else
                {

                    stocks = Convert.ToInt32(txtNoOfStocks.Text);
                    payment.AddPayment(n, amnt, it, at, asst, stocks);

                }

                dgvFee.DataSource = payment.ViewAllFees();
                txtAmount.Text = null;
                txtItemType.Text = null;
                txtNoOfStocks.Text = null;
                txtName.Text = null;

            }

            catch {}
            
        }

        private void FeeForm_Load(object sender, EventArgs e)
        {
            dgvFee.DataSource = payment.ViewAllFees();
            dgvFee.Columns[0].HeaderText = "ID";
            dgvFee.Columns[1].HeaderText = "DESCRIPTION";
            dgvFee.Columns[2].HeaderText = "AMOUNT";
            dgvFee.Columns[3].HeaderText = "ITEM TYPE";
            dgvFee.Columns[4].HeaderText = "APPLY TO";
            dgvFee.Columns[5].HeaderText = "ASSIGN TO";
            dgvFee.Columns[6].HeaderText = "NO. OF STOCKS";
           
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            payment.ClearFields(txtName, txtAmount, txtItemType, txtAppliedTo, txtNoOfStocks); 
        }

        private void dgvFee_CellDoubleClick(object sender, Telerik.WinControls.UI.GridViewCellEventArgs e)
        {
            txtName.Text = this.dgvFee.CurrentRow.Cells[1].Value.ToString();
            txtAmount.Text = this.dgvFee.CurrentRow.Cells[2].Value.ToString();
            txtItemType.Text = this.dgvFee.CurrentRow.Cells[3].Value.ToString();
            txtAppliedTo.Text = this.dgvFee.CurrentRow.Cells[4].Value.ToString();
            txtAssignTo.Text = this.dgvFee.CurrentRow.Cells[5].Value.ToString();
            txtNoOfStocks.Text = this.dgvFee.CurrentRow.Cells[6].Value.ToString();
            txtID.Text = this.dgvFee.CurrentRow.Cells[0].Value.ToString();
         
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch !=8)
            {
                e.Handled = true;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {

                int id = Convert.ToInt32(txtID.Text);
                payment.DeletePayment(id);
                dgvFee.DataSource = payment.ViewAllFees();
                txtAmount.Text = null;
                txtItemType.Text = null;
                txtNoOfStocks.Text = null;
                txtAppliedTo.Text = null;
                txtName.Text = null;
                txtID.Text = null;

            }
            catch {}
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            
            try 
            {

                decimal amount = decimal.Parse(txtAmount.Text);
                int id = Convert.ToInt32(txtID.Text);
                int stocks;

                if (txtNoOfStocks.Text == "")
                {

                    stocks = 0;
                    payment.UpdatePayment(txtName.Text, amount, txtItemType.Text, txtAppliedTo.Text, txtAssignTo.Text, stocks, id);

                    if (txtAssignTo.Text == "")
                    {

                        stocks = 0;
                        payment.UpdatePayment(txtName.Text, amount, txtItemType.Text, txtAppliedTo.Text, txtAssignTo.Text, stocks, id);

                    }

                }
                else
                {

                    stocks = Convert.ToInt32(txtNoOfStocks.Text);
                    payment.UpdatePayment(txtName.Text, amount, txtItemType.Text, txtAppliedTo.Text, txtAssignTo.Text, stocks, id);

                }


                dgvFee.DataSource = payment.ViewAllFees();
                txtAmount.Text = null;
                txtItemType.Text = null;
                txtNoOfStocks.Text = null;
                txtAppliedTo.Text = null;
                txtName.Text = null;
                txtID.Text = null;
            
            }

            catch {}
            
        }
    }
}
