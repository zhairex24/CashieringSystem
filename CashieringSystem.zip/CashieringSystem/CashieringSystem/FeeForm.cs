﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class FeeForm : Telerik.WinControls.UI.RadForm
    {
        public FeeForm()
        {
            InitializeComponent();
        }

        Payment payment = new Payment();

        private void radDropDownList1_SelectedIndexChanged(object sender, Telerik.WinControls.UI.Data.PositionChangedEventArgs e)
        {
            if (this.txtAppliedTo.SelectedIndex > -1)
            {
                string appliedTo = this.txtAppliedTo.SelectedItem.Text;
            }
        }

        private void btnSaveFee_Click(object sender, EventArgs e)
        {
            string fn = txtNameOfFee.Text;
            decimal amnt = decimal.Parse(txtAmount.Text);
            string at = txtAppliedTo.Text;
            string dept = txtDepartment.Text;

            payment.AddFee(fn, amnt, at, dept);
            dgvFee.DataSource = payment.ViewAllFees();
            txtAmount.Text = null;
            txtAppliedTo.Text = null;
            txtDepartment.Text = null;
            txtNameOfFee.Text = null;
            
        }

        private void FeeForm_Load(object sender, EventArgs e)
        {
            dgvFee.DataSource = payment.ViewAllFees();
            dgvFee.Columns[0].IsVisible = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            payment.ClearFields(txtNameOfFee, txtAmount, txtAppliedTo, txtDepartment); 
        }

        private void dgvFee_CellDoubleClick(object sender, Telerik.WinControls.UI.GridViewCellEventArgs e)
        {
            UpdateFeeForm uf = new UpdateFeeForm();
            uf.txtNameOfFee.Text = this.dgvFee.CurrentRow.Cells[1].Value.ToString();
            uf.txtAmount.Text = this.dgvFee.CurrentRow.Cells[4].Value.ToString();
            uf.txtAppliedTo.Text = this.dgvFee.CurrentRow.Cells[2].Value.ToString();
            uf.txtDepartment.Text = this.dgvFee.CurrentRow.Cells[3].Value.ToString();
            uf.txtFeeID.Text = this.dgvFee.CurrentRow.Cells[0].Value.ToString();
            uf.ShowDialog();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvFee.DataSource = payment.ViewAllFees();
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch !=8)
            {
                e.Handled = true;
            }
        }
    }
}
