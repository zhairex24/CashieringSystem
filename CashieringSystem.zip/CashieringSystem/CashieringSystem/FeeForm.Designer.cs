﻿namespace CashieringSystem
{
    partial class FeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.RadListDataItem radListDataItem7 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem8 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem4 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem5 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem6 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem1 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem2 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem3 = new Telerik.WinControls.UI.RadListDataItem();
            this.radLabelElement1 = new Telerik.WinControls.UI.RadLabelElement();
            this.dgvFee = new Telerik.WinControls.UI.RadGridView();
            this.office2013LightTheme1 = new Telerik.WinControls.Themes.Office2013LightTheme();
            this.radPanel2 = new Telerik.WinControls.UI.RadPanel();
            this.radPanel4 = new Telerik.WinControls.UI.RadPanel();
            this.radButton1 = new Telerik.WinControls.UI.RadButton();
            this.radPanel5 = new Telerik.WinControls.UI.RadPanel();
            this.object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01 = new Telerik.WinControls.RootRadElement();
            this.btnSaveFee = new Telerik.WinControls.UI.RadButton();
            this.nameOfFee = new Telerik.WinControls.UI.RadLabel();
            this.amount = new Telerik.WinControls.UI.RadLabel();
            this.txtItemType = new Telerik.WinControls.UI.RadDropDownList();
            this.appliedTo = new Telerik.WinControls.UI.RadLabel();
            this.department = new Telerik.WinControls.UI.RadLabel();
            this.btnClear = new Telerik.WinControls.UI.RadButton();
            this.txtAppliedTo = new Telerik.WinControls.UI.RadDropDownList();
            this.radPanel3 = new Telerik.WinControls.UI.RadPanel();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.btnUpdate = new Telerik.WinControls.UI.RadButton();
            this.btnDelete = new Telerik.WinControls.UI.RadButton();
            this.radPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.txtName = new Telerik.WinControls.UI.RadTextBox();
            this.txtAmount = new Telerik.WinControls.UI.RadTextBox();
            this.txtID = new Telerik.WinControls.UI.RadTextBox();
            this.txtNoOfStocks = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.txtAssignTo = new Telerik.WinControls.UI.RadDropDownList();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFee.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).BeginInit();
            this.radPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel4)).BeginInit();
            this.radPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel5)).BeginInit();
            this.radPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameOfFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.amount)).BeginInit();
            this.amount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appliedTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.department)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAppliedTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).BeginInit();
            this.radPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNoOfStocks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAssignTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radLabelElement1
            // 
            this.radLabelElement1.Name = "radLabelElement1";
            this.radLabelElement1.TextWrap = true;
            this.radLabelElement1.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // dgvFee
            // 
            this.dgvFee.BackColor = System.Drawing.Color.Transparent;
            this.dgvFee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvFee.Location = new System.Drawing.Point(0, 42);
            // 
            // dgvFee
            // 
            this.dgvFee.MasterTemplate.AllowAddNewRow = false;
            this.dgvFee.MasterTemplate.AllowDeleteRow = false;
            this.dgvFee.MasterTemplate.AllowDragToGroup = false;
            this.dgvFee.MasterTemplate.AllowEditRow = false;
            this.dgvFee.MasterTemplate.AllowRowResize = false;
            this.dgvFee.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            this.dgvFee.Name = "dgvFee";
            this.dgvFee.ReadOnly = true;
            this.dgvFee.ShowGroupPanel = false;
            this.dgvFee.Size = new System.Drawing.Size(940, 686);
            this.dgvFee.TabIndex = 0;
            this.dgvFee.Text = "radGridView1";
            this.dgvFee.ThemeName = "TelerikMetroBlue";
            this.dgvFee.CellDoubleClick += new Telerik.WinControls.UI.GridViewCellEventHandler(this.dgvFee_CellDoubleClick);
            // 
            // radPanel2
            // 
            this.radPanel2.Controls.Add(this.dgvFee);
            this.radPanel2.Controls.Add(this.radPanel4);
            this.radPanel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.radPanel2.Location = new System.Drawing.Point(426, 0);
            this.radPanel2.Name = "radPanel2";
            this.radPanel2.Size = new System.Drawing.Size(940, 728);
            this.radPanel2.TabIndex = 11;
            // 
            // radPanel4
            // 
            this.radPanel4.Controls.Add(this.radButton1);
            this.radPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.radPanel4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radPanel4.Location = new System.Drawing.Point(0, 0);
            this.radPanel4.Name = "radPanel4";
            this.radPanel4.Size = new System.Drawing.Size(940, 42);
            this.radPanel4.TabIndex = 9;
            this.radPanel4.Text = "List of Payments";
            this.radPanel4.ThemeName = "Office2013Light";
            // 
            // radButton1
            // 
            this.radButton1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radButton1.Location = new System.Drawing.Point(302, 47);
            this.radButton1.Name = "radButton1";
            this.radButton1.Size = new System.Drawing.Size(65, 32);
            this.radButton1.TabIndex = 12;
            this.radButton1.Text = "Delete";
            this.radButton1.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadButtonElement)(this.radButton1.GetChildAt(0))).Text = "Delete";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.radButton1.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.radButton1.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // radPanel5
            // 
            this.radPanel5.Controls.Add(this.radPanel1);
            this.radPanel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.radPanel5.Location = new System.Drawing.Point(0, 0);
            this.radPanel5.Name = "radPanel5";
            this.radPanel5.Size = new System.Drawing.Size(402, 728);
            this.radPanel5.TabIndex = 12;
            // 
            // object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01
            // 
            this.object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01.Name = "object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01";
            this.object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01.StretchHorizontally = true;
            this.object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01.StretchVertically = true;
            this.object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // btnSaveFee
            // 
            this.btnSaveFee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnSaveFee.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnSaveFee.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveFee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnSaveFee.Location = new System.Drawing.Point(275, 288);
            this.btnSaveFee.Name = "btnSaveFee";
            this.btnSaveFee.Size = new System.Drawing.Size(65, 31);
            this.btnSaveFee.TabIndex = 4;
            this.btnSaveFee.Text = "Save";
            this.btnSaveFee.ThemeName = "Office2013Light";
            this.btnSaveFee.Click += new System.EventHandler(this.btnSaveFee_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).Text = "Save";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // nameOfFee
            // 
            this.nameOfFee.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameOfFee.Location = new System.Drawing.Point(75, 60);
            this.nameOfFee.Name = "nameOfFee";
            this.nameOfFee.Size = new System.Drawing.Size(52, 24);
            this.nameOfFee.TabIndex = 7;
            this.nameOfFee.Text = "Name:";
            this.nameOfFee.ThemeName = "Office2013Light";
            // 
            // amount
            // 
            this.amount.Controls.Add(this.txtID);
            this.amount.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amount.Location = new System.Drawing.Point(60, 98);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(92, 24);
            this.amount.TabIndex = 9;
            this.amount.Text = "Amount:    ₱";
            this.amount.ThemeName = "Office2013Light";
            // 
            // txtItemType
            // 
            this.txtItemType.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem7.Text = "Fee";
            radListDataItem7.TextWrap = true;
            radListDataItem8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem8.Text = "Other";
            radListDataItem8.TextWrap = true;
            this.txtItemType.Items.Add(radListDataItem7);
            this.txtItemType.Items.Add(radListDataItem8);
            this.txtItemType.Location = new System.Drawing.Point(157, 136);
            this.txtItemType.Name = "txtItemType";
            // 
            // 
            // 
            this.txtItemType.RootElement.StretchVertically = true;
            this.txtItemType.Size = new System.Drawing.Size(183, 23);
            this.txtItemType.TabIndex = 2;
            this.txtItemType.ThemeName = "Office2013Light";
            this.txtItemType.SelectedIndexChanged += new Telerik.WinControls.UI.Data.PositionChangedEventHandler(this.radDropDownList1_SelectedIndexChanged);
            // 
            // appliedTo
            // 
            this.appliedTo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appliedTo.Location = new System.Drawing.Point(49, 135);
            this.appliedTo.Name = "appliedTo";
            this.appliedTo.Size = new System.Drawing.Size(79, 24);
            this.appliedTo.TabIndex = 10;
            this.appliedTo.Text = "Item Type:";
            this.appliedTo.ThemeName = "Office2013Light";
            // 
            // department
            // 
            this.department.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.department.Location = new System.Drawing.Point(33, 252);
            this.department.Name = "department";
            this.department.Size = new System.Drawing.Size(101, 24);
            this.department.TabIndex = 9;
            this.department.Text = "No. of Stocks:";
            this.department.ThemeName = "Office2013Light";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(204, 288);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(65, 32);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "Clear";
            this.btnClear.ThemeName = "Office2013Light";
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnClear.GetChildAt(0))).Text = "Clear";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnClear.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // txtAppliedTo
            // 
            this.txtAppliedTo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem4.Text = "All Students";
            radListDataItem4.TextWrap = true;
            radListDataItem5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem5.Text = "Full Scholars";
            radListDataItem5.TextWrap = true;
            radListDataItem6.Text = "Partial Scholars";
            radListDataItem6.TextWrap = true;
            this.txtAppliedTo.Items.Add(radListDataItem4);
            this.txtAppliedTo.Items.Add(radListDataItem5);
            this.txtAppliedTo.Items.Add(radListDataItem6);
            this.txtAppliedTo.Location = new System.Drawing.Point(157, 175);
            this.txtAppliedTo.Name = "txtAppliedTo";
            // 
            // 
            // 
            this.txtAppliedTo.RootElement.StretchVertically = true;
            this.txtAppliedTo.Size = new System.Drawing.Size(183, 21);
            this.txtAppliedTo.TabIndex = 11;
            this.txtAppliedTo.ThemeName = "Office2013Light";
            // 
            // radPanel3
            // 
            this.radPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.radPanel3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radPanel3.Location = new System.Drawing.Point(0, 0);
            this.radPanel3.Name = "radPanel3";
            this.radPanel3.Size = new System.Drawing.Size(402, 42);
            this.radPanel3.TabIndex = 8;
            this.radPanel3.Text = "Add Fees / Items";
            this.radPanel3.ThemeName = "Office2013Light";
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.Location = new System.Drawing.Point(55, 174);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(72, 24);
            this.radLabel1.TabIndex = 12;
            this.radLabel1.Text = "Apply To:";
            this.radLabel1.ThemeName = "Office2013Light";
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnUpdate.Location = new System.Drawing.Point(275, 334);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(65, 31);
            this.btnUpdate.TabIndex = 21;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.ThemeName = "Office2013Light";
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnUpdate.GetChildAt(0))).Text = "Update";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnUpdate.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnUpdate.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdate.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdate.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdate.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdate.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdate.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdate.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdate.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdate.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(184)))), ((int)(((byte)(91)))));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnUpdate.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnUpdate.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnUpdate.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnDelete.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnDelete.Location = new System.Drawing.Point(204, 334);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(65, 31);
            this.btnDelete.TabIndex = 20;
            this.btnDelete.Text = "Delete";
            this.btnDelete.ThemeName = "Office2013Light";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnDelete.GetChildAt(0))).Text = "Delete";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnDelete.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnDelete.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(82)))), ((int)(((byte)(78)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // radPanel1
            // 
            this.radPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.radPanel1.Controls.Add(this.radLabel2);
            this.radPanel1.Controls.Add(this.btnDelete);
            this.radPanel1.Controls.Add(this.txtAssignTo);
            this.radPanel1.Controls.Add(this.btnUpdate);
            this.radPanel1.Controls.Add(this.radLabel1);
            this.radPanel1.Controls.Add(this.radPanel3);
            this.radPanel1.Controls.Add(this.txtAppliedTo);
            this.radPanel1.Controls.Add(this.btnClear);
            this.radPanel1.Controls.Add(this.department);
            this.radPanel1.Controls.Add(this.appliedTo);
            this.radPanel1.Controls.Add(this.txtNoOfStocks);
            this.radPanel1.Controls.Add(this.txtItemType);
            this.radPanel1.Controls.Add(this.amount);
            this.radPanel1.Controls.Add(this.nameOfFee);
            this.radPanel1.Controls.Add(this.txtAmount);
            this.radPanel1.Controls.Add(this.txtName);
            this.radPanel1.Controls.Add(this.btnSaveFee);
            this.radPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radPanel1.Location = new System.Drawing.Point(0, 0);
            this.radPanel1.Name = "radPanel1";
            this.radPanel1.Size = new System.Drawing.Size(402, 728);
            this.radPanel1.TabIndex = 6;
            this.radPanel1.ThemeName = "Office2013Light";
            this.radPanel1.UseCompatibleTextRendering = false;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(158, 60);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(183, 23);
            this.txtName.TabIndex = 0;
            this.txtName.ThemeName = "Office2013Light";
            // 
            // txtAmount
            // 
            this.txtAmount.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmount.Location = new System.Drawing.Point(157, 97);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(183, 23);
            this.txtAmount.TabIndex = 1;
            this.txtAmount.ThemeName = "Office2013Light";
            this.txtAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAmount_KeyPress);
            // 
            // txtID
            // 
            this.txtID.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.Location = new System.Drawing.Point(93, 1);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(25, 23);
            this.txtID.TabIndex = 13;
            this.txtID.ThemeName = "Office2013Light";
            this.txtID.Visible = false;
            // 
            // txtNoOfStocks
            // 
            this.txtNoOfStocks.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoOfStocks.Location = new System.Drawing.Point(158, 251);
            this.txtNoOfStocks.Name = "txtNoOfStocks";
            // 
            // 
            // 
            this.txtNoOfStocks.RootElement.AutoSize = false;
            this.txtNoOfStocks.Size = new System.Drawing.Size(183, 23);
            this.txtNoOfStocks.TabIndex = 3;
            this.txtNoOfStocks.ThemeName = "Office2013Light";
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtNoOfStocks.GetChildAt(0).GetChildAt(2))).LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtNoOfStocks.GetChildAt(0).GetChildAt(2))).TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtNoOfStocks.GetChildAt(0).GetChildAt(2))).RightColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtNoOfStocks.GetChildAt(0).GetChildAt(2))).BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            // 
            // radLabel2
            // 
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel2.Location = new System.Drawing.Point(55, 212);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(77, 24);
            this.radLabel2.TabIndex = 14;
            this.radLabel2.Text = "Assign To:";
            this.radLabel2.ThemeName = "Office2013Light";
            // 
            // txtAssignTo
            // 
            this.txtAssignTo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem1.Text = "Kindergarten";
            radListDataItem1.TextWrap = true;
            radListDataItem2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem2.Text = "Elementary";
            radListDataItem2.TextWrap = true;
            radListDataItem3.Text = "College";
            radListDataItem3.TextWrap = true;
            this.txtAssignTo.Items.Add(radListDataItem1);
            this.txtAssignTo.Items.Add(radListDataItem2);
            this.txtAssignTo.Items.Add(radListDataItem3);
            this.txtAssignTo.Location = new System.Drawing.Point(157, 213);
            this.txtAssignTo.Name = "txtAssignTo";
            // 
            // 
            // 
            this.txtAssignTo.RootElement.StretchVertically = true;
            this.txtAssignTo.Size = new System.Drawing.Size(183, 21);
            this.txtAssignTo.TabIndex = 13;
            this.txtAssignTo.ThemeName = "Office2013Light";
            // 
            // FeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 728);
            this.Controls.Add(this.radPanel5);
            this.Controls.Add(this.radPanel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "FeeForm";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "Fees";
            this.ThemeName = "Office2013Light";
            this.Load += new System.EventHandler(this.FeeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFee.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).EndInit();
            this.radPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radPanel4)).EndInit();
            this.radPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel5)).EndInit();
            this.radPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameOfFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.amount)).EndInit();
            this.amount.ResumeLayout(false);
            this.amount.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appliedTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.department)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAppliedTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).EndInit();
            this.radPanel1.ResumeLayout(false);
            this.radPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNoOfStocks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAssignTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadLabelElement radLabelElement1;
        private Telerik.WinControls.Themes.Office2013LightTheme office2013LightTheme1;
        private Telerik.WinControls.UI.RadGridView dgvFee;
        private Telerik.WinControls.UI.RadPanel radPanel2;
        private Telerik.WinControls.UI.RadPanel radPanel5;
        private Telerik.WinControls.UI.RadPanel radPanel4;
        private Telerik.WinControls.UI.RadButton radButton1;
        private Telerik.WinControls.RootRadElement object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01;
        private Telerik.WinControls.UI.RadPanel radPanel1;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadButton btnDelete;
        private Telerik.WinControls.UI.RadDropDownList txtAssignTo;
        private Telerik.WinControls.UI.RadButton btnUpdate;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadPanel radPanel3;
        private Telerik.WinControls.UI.RadDropDownList txtAppliedTo;
        private Telerik.WinControls.UI.RadButton btnClear;
        private Telerik.WinControls.UI.RadLabel department;
        private Telerik.WinControls.UI.RadLabel appliedTo;
        private Telerik.WinControls.UI.RadTextBox txtNoOfStocks;
        private Telerik.WinControls.UI.RadDropDownList txtItemType;
        private Telerik.WinControls.UI.RadLabel amount;
        public Telerik.WinControls.UI.RadTextBox txtID;
        private Telerik.WinControls.UI.RadLabel nameOfFee;
        private Telerik.WinControls.UI.RadTextBox txtAmount;
        private Telerik.WinControls.UI.RadTextBox txtName;
        private Telerik.WinControls.UI.RadButton btnSaveFee;

    }
}
