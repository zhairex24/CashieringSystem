﻿namespace CashieringSystem
{
    partial class FeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.RadListDataItem radListDataItem1 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem2 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem3 = new Telerik.WinControls.UI.RadListDataItem();
            this.radLabelElement1 = new Telerik.WinControls.UI.RadLabelElement();
            this.btnSaveFee = new Telerik.WinControls.UI.RadButton();
            this.nameOfFee = new Telerik.WinControls.UI.RadLabel();
            this.amount = new Telerik.WinControls.UI.RadLabel();
            this.txtAppliedTo = new Telerik.WinControls.UI.RadDropDownList();
            this.appliedTo = new Telerik.WinControls.UI.RadLabel();
            this.department = new Telerik.WinControls.UI.RadLabel();
            this.radPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.radPanel3 = new Telerik.WinControls.UI.RadPanel();
            this.btnClear = new Telerik.WinControls.UI.RadButton();
            this.txtDepartment = new Telerik.WinControls.UI.RadTextBox();
            this.txtAmount = new Telerik.WinControls.UI.RadTextBox();
            this.txtNameOfFee = new Telerik.WinControls.UI.RadTextBox();
            this.dgvFee = new Telerik.WinControls.UI.RadGridView();
            this.office2013LightTheme1 = new Telerik.WinControls.Themes.Office2013LightTheme();
            this.radPanel2 = new Telerik.WinControls.UI.RadPanel();
            this.btnRefresh = new Telerik.WinControls.UI.RadButton();
            this.radPanel4 = new Telerik.WinControls.UI.RadPanel();
            this.radButton1 = new Telerik.WinControls.UI.RadButton();
            this.radPanel5 = new Telerik.WinControls.UI.RadPanel();
            this.object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01 = new Telerik.WinControls.RootRadElement();
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameOfFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.amount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAppliedTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appliedTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.department)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).BeginInit();
            this.radPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDepartment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNameOfFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFee.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).BeginInit();
            this.radPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnRefresh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel4)).BeginInit();
            this.radPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel5)).BeginInit();
            this.radPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radLabelElement1
            // 
            this.radLabelElement1.Name = "radLabelElement1";
            this.radLabelElement1.TextWrap = true;
            this.radLabelElement1.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // btnSaveFee
            // 
            this.btnSaveFee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnSaveFee.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnSaveFee.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveFee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnSaveFee.Location = new System.Drawing.Point(275, 210);
            this.btnSaveFee.Name = "btnSaveFee";
            this.btnSaveFee.Size = new System.Drawing.Size(65, 31);
            this.btnSaveFee.TabIndex = 4;
            this.btnSaveFee.Text = "Save";
            this.btnSaveFee.ThemeName = "Office2013Light";
            this.btnSaveFee.Click += new System.EventHandler(this.btnSaveFee_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).Text = "Save";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // nameOfFee
            // 
            this.nameOfFee.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameOfFee.Location = new System.Drawing.Point(34, 60);
            this.nameOfFee.Name = "nameOfFee";
            this.nameOfFee.Size = new System.Drawing.Size(98, 24);
            this.nameOfFee.TabIndex = 7;
            this.nameOfFee.Text = "Name of Fee:";
            this.nameOfFee.ThemeName = "Office2013Light";
            // 
            // amount
            // 
            this.amount.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amount.Location = new System.Drawing.Point(33, 98);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(122, 24);
            this.amount.TabIndex = 9;
            this.amount.Text = "Amount:           ₱";
            this.amount.ThemeName = "Office2013Light";
            // 
            // txtAppliedTo
            // 
            this.txtAppliedTo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem1.Text = "All Students";
            radListDataItem1.TextWrap = true;
            radListDataItem2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem2.Text = "Partial Scholars";
            radListDataItem2.TextWrap = true;
            radListDataItem3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem3.Text = "Full Scholars";
            radListDataItem3.TextWrap = true;
            this.txtAppliedTo.Items.Add(radListDataItem1);
            this.txtAppliedTo.Items.Add(radListDataItem2);
            this.txtAppliedTo.Items.Add(radListDataItem3);
            this.txtAppliedTo.Location = new System.Drawing.Point(157, 136);
            this.txtAppliedTo.Name = "txtAppliedTo";
            // 
            // 
            // 
            this.txtAppliedTo.RootElement.StretchVertically = true;
            this.txtAppliedTo.Size = new System.Drawing.Size(183, 21);
            this.txtAppliedTo.TabIndex = 2;
            this.txtAppliedTo.ThemeName = "Office2013Light";
            this.txtAppliedTo.SelectedIndexChanged += new Telerik.WinControls.UI.Data.PositionChangedEventHandler(this.radDropDownList1_SelectedIndexChanged);
            // 
            // appliedTo
            // 
            this.appliedTo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appliedTo.Location = new System.Drawing.Point(35, 135);
            this.appliedTo.Name = "appliedTo";
            this.appliedTo.Size = new System.Drawing.Size(85, 24);
            this.appliedTo.TabIndex = 10;
            this.appliedTo.Text = "Applied To:";
            this.appliedTo.ThemeName = "Office2013Light";
            // 
            // department
            // 
            this.department.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.department.Location = new System.Drawing.Point(34, 174);
            this.department.Name = "department";
            this.department.Size = new System.Drawing.Size(93, 24);
            this.department.TabIndex = 9;
            this.department.Text = "Department:";
            this.department.ThemeName = "Office2013Light";
            // 
            // radPanel1
            // 
            this.radPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.radPanel1.Controls.Add(this.radPanel3);
            this.radPanel1.Controls.Add(this.btnClear);
            this.radPanel1.Controls.Add(this.department);
            this.radPanel1.Controls.Add(this.appliedTo);
            this.radPanel1.Controls.Add(this.txtDepartment);
            this.radPanel1.Controls.Add(this.txtAppliedTo);
            this.radPanel1.Controls.Add(this.amount);
            this.radPanel1.Controls.Add(this.nameOfFee);
            this.radPanel1.Controls.Add(this.txtAmount);
            this.radPanel1.Controls.Add(this.txtNameOfFee);
            this.radPanel1.Controls.Add(this.btnSaveFee);
            this.radPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radPanel1.Location = new System.Drawing.Point(0, 0);
            this.radPanel1.Name = "radPanel1";
            this.radPanel1.Size = new System.Drawing.Size(402, 728);
            this.radPanel1.TabIndex = 6;
            this.radPanel1.ThemeName = "Office2013Light";
            this.radPanel1.UseCompatibleTextRendering = false;
            // 
            // radPanel3
            // 
            this.radPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.radPanel3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radPanel3.Location = new System.Drawing.Point(0, 0);
            this.radPanel3.Name = "radPanel3";
            this.radPanel3.Size = new System.Drawing.Size(402, 42);
            this.radPanel3.TabIndex = 8;
            this.radPanel3.Text = "Add Fees";
            this.radPanel3.ThemeName = "Office2013Light";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(204, 210);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(65, 32);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "Clear";
            this.btnClear.ThemeName = "Office2013Light";
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnClear.GetChildAt(0))).Text = "Clear";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnClear.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // txtDepartment
            // 
            this.txtDepartment.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDepartment.Location = new System.Drawing.Point(158, 173);
            this.txtDepartment.Name = "txtDepartment";
            // 
            // 
            // 
            this.txtDepartment.RootElement.AutoSize = false;
            this.txtDepartment.Size = new System.Drawing.Size(183, 23);
            this.txtDepartment.TabIndex = 3;
            this.txtDepartment.ThemeName = "Office2013Light";
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtDepartment.GetChildAt(0).GetChildAt(2))).LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtDepartment.GetChildAt(0).GetChildAt(2))).TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtDepartment.GetChildAt(0).GetChildAt(2))).RightColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtDepartment.GetChildAt(0).GetChildAt(2))).BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            // 
            // txtAmount
            // 
            this.txtAmount.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmount.Location = new System.Drawing.Point(157, 97);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(183, 23);
            this.txtAmount.TabIndex = 1;
            this.txtAmount.ThemeName = "Office2013Light";
            this.txtAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAmount_KeyPress);
            // 
            // txtNameOfFee
            // 
            this.txtNameOfFee.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNameOfFee.Location = new System.Drawing.Point(158, 60);
            this.txtNameOfFee.Name = "txtNameOfFee";
            this.txtNameOfFee.Size = new System.Drawing.Size(183, 23);
            this.txtNameOfFee.TabIndex = 0;
            this.txtNameOfFee.ThemeName = "Office2013Light";
            // 
            // dgvFee
            // 
            this.dgvFee.BackColor = System.Drawing.Color.Transparent;
            this.dgvFee.Location = new System.Drawing.Point(0, 85);
            // 
            // dgvFee
            // 
            this.dgvFee.MasterTemplate.AllowAddNewRow = false;
            this.dgvFee.MasterTemplate.AllowDeleteRow = false;
            this.dgvFee.MasterTemplate.AllowDragToGroup = false;
            this.dgvFee.MasterTemplate.AllowEditRow = false;
            this.dgvFee.MasterTemplate.AllowRowResize = false;
            this.dgvFee.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            this.dgvFee.Name = "dgvFee";
            this.dgvFee.ReadOnly = true;
            this.dgvFee.Size = new System.Drawing.Size(940, 456);
            this.dgvFee.TabIndex = 0;
            this.dgvFee.Text = "radGridView1";
            this.dgvFee.ThemeName = "Office2013Light";
            this.dgvFee.CellDoubleClick += new Telerik.WinControls.UI.GridViewCellEventHandler(this.dgvFee_CellDoubleClick);
            // 
            // radPanel2
            // 
            this.radPanel2.Controls.Add(this.btnRefresh);
            this.radPanel2.Controls.Add(this.dgvFee);
            this.radPanel2.Controls.Add(this.radPanel4);
            this.radPanel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.radPanel2.Location = new System.Drawing.Point(426, 0);
            this.radPanel2.Name = "radPanel2";
            this.radPanel2.Size = new System.Drawing.Size(940, 728);
            this.radPanel2.TabIndex = 11;
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnRefresh.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnRefresh.Location = new System.Drawing.Point(861, 48);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(66, 31);
            this.btnRefresh.TabIndex = 5;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.ThemeName = "Office2013Light";
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnRefresh.GetChildAt(0))).Text = "Refresh";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnRefresh.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnRefresh.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(170)))), ((int)(((byte)(93)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnRefresh.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // radPanel4
            // 
            this.radPanel4.Controls.Add(this.radButton1);
            this.radPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.radPanel4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radPanel4.Location = new System.Drawing.Point(0, 0);
            this.radPanel4.Name = "radPanel4";
            this.radPanel4.Size = new System.Drawing.Size(940, 42);
            this.radPanel4.TabIndex = 9;
            this.radPanel4.Text = "Current Fees";
            this.radPanel4.ThemeName = "Office2013Light";
            // 
            // radButton1
            // 
            this.radButton1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radButton1.Location = new System.Drawing.Point(302, 47);
            this.radButton1.Name = "radButton1";
            this.radButton1.Size = new System.Drawing.Size(65, 32);
            this.radButton1.TabIndex = 12;
            this.radButton1.Text = "Delete";
            this.radButton1.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadButtonElement)(this.radButton1.GetChildAt(0))).Text = "Delete";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.radButton1.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.radButton1.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // radPanel5
            // 
            this.radPanel5.Controls.Add(this.radPanel1);
            this.radPanel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.radPanel5.Location = new System.Drawing.Point(0, 0);
            this.radPanel5.Name = "radPanel5";
            this.radPanel5.Size = new System.Drawing.Size(402, 728);
            this.radPanel5.TabIndex = 12;
            // 
            // object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01
            // 
            this.object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01.Name = "object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01";
            this.object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01.StretchHorizontally = true;
            this.object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01.StretchVertically = true;
            this.object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // FeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 728);
            this.Controls.Add(this.radPanel5);
            this.Controls.Add(this.radPanel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "FeeForm";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "Fees";
            this.ThemeName = "Office2013Light";
            this.Load += new System.EventHandler(this.FeeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameOfFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.amount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAppliedTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appliedTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.department)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).EndInit();
            this.radPanel1.ResumeLayout(false);
            this.radPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDepartment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNameOfFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFee.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).EndInit();
            this.radPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnRefresh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel4)).EndInit();
            this.radPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel5)).EndInit();
            this.radPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadLabelElement radLabelElement1;
        private Telerik.WinControls.UI.RadButton btnSaveFee;
        private Telerik.WinControls.UI.RadLabel nameOfFee;
        private Telerik.WinControls.UI.RadLabel amount;
        private Telerik.WinControls.UI.RadDropDownList txtAppliedTo;
        private Telerik.WinControls.UI.RadLabel appliedTo;
        private Telerik.WinControls.UI.RadLabel department;
        private Telerik.WinControls.UI.RadPanel radPanel1;
        private Telerik.WinControls.UI.RadTextBox txtDepartment;
        private Telerik.WinControls.UI.RadTextBox txtAmount;
        private Telerik.WinControls.UI.RadTextBox txtNameOfFee;
        private Telerik.WinControls.UI.RadPanel radPanel3;
        private Telerik.WinControls.Themes.Office2013LightTheme office2013LightTheme1;
        private Telerik.WinControls.UI.RadGridView dgvFee;
        private Telerik.WinControls.UI.RadButton btnClear;
        private Telerik.WinControls.UI.RadPanel radPanel2;
        private Telerik.WinControls.UI.RadPanel radPanel5;
        private Telerik.WinControls.UI.RadPanel radPanel4;
        private Telerik.WinControls.UI.RadButton radButton1;
        private Telerik.WinControls.RootRadElement object_5e4aeaca_49c2_4c43_ad6b_abb863a71b01;
        private Telerik.WinControls.UI.RadButton btnRefresh;

    }
}
