﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;
using CashieringSystem.Properties;
using Microsoft.Reporting.WinForms;

namespace CashieringSystem
{
    public partial class ORPrintView : Telerik.WinControls.UI.RadForm
    {
        public ORPrintView()
        {
            InitializeComponent();
        }

        Payment payment = new Payment();

        private void ORPrintView_Load(object sender, EventArgs e)
        {
          ReportParameter rp = new ReportParameter("OR", payment.GetLatestORNumber());
          this.reportViewer1.LocalReport.SetParameters(new ReportParameter[] { rp });
          this.reportViewer1.ProcessingMode = ProcessingMode.Local;
          this.reportViewer1.LocalReport.DataSources.Clear();
          this.reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("ORDataSet", payment.GetTransactionDetail(payment.GetLatestORNumber()).Tables[0]));
          this.reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("ORDataSet2", payment.GetTransaction(payment.GetLatestORNumber()).Tables[0]));
          this.reportViewer1.LocalReport.Refresh();
          this.reportViewer1.RefreshReport();
        }
     
    }
}
