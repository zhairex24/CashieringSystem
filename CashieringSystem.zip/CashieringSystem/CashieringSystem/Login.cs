﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class Login : Telerik.WinControls.UI.RadForm
    {
        public Login()
        {
            InitializeComponent();
        }

        ServerConnection serCon = new ServerConnection();
        public const string isWrong = "Your username or password is incorrect.";
        public const string authenticator = "User Authenticator";

        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
                txtPassword.Focus();
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
                btnLogin.PerformClick();
        }

        private void btnConnectToServer_Click(object sender, EventArgs e)
        {
            ConnectToServer serverForm = new ConnectToServer();
            serverForm.Show();
            Hide();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string user = txtUsername.Text;
            string pass = txtPassword.Text;
            if (string.IsNullOrEmpty(user))
            {
                MessageBox.Show("Please enter your username.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUsername.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Please enter your password.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPassword.Focus();
                return;
            }
            else 
            {
                bool r = serCon.validate_login(user, pass);
                if (r)
                {
                    this.Hide();
                    CashieringDashboard cd = new CashieringDashboard();
                    cd.Show();
                    
                }
                else
                { 
                    MessageBox.Show(isWrong, authenticator, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

    }
}
