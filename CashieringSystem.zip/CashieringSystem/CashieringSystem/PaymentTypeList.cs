﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using Telerik.WinControls.UI;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class PaymentTypeList : Telerik.WinControls.UI.RadForm
    {
        Transaction tr;
        public PaymentTypeList(Transaction t)
        {
            InitializeComponent();
            tr = t;
        }

        PaymentForm payment = new PaymentForm();

        private void PaymentTypeList_Load(object sender, EventArgs e)
        {
            //dgvItemsToPay.DataSource = payment.PaymentType(transac.txtPaymentType.Text);

           for (int i = 0; i < dgvItemsToPay.Rows.Count; i++)
            {
     
                dgvItemsToPay.Rows[i].Cells[0].Value = true;

            }

            for (int i = 1; i <= dgvItemsToPay.ColumnCount - 1; i++)
            {
                dgvItemsToPay.Columns[i].ReadOnly = true;
            }

            dgvItemsToPay.Columns[3].HeaderText = "Fee Name";
            dgvItemsToPay.Columns[4].HeaderText = "Amount";
            dgvItemsToPay.Columns[1].Width = 800;          
            
        }

        private void dgvItemsToPay_MouseClick(object sender, MouseEventArgs e)
        {
            if ((bool)dgvItemsToPay.SelectedRows[0].Cells[0].Value == false)
            {
                dgvItemsToPay.SelectedRows[0].Cells[0].Value = true;
            }
            else
            {
                dgvItemsToPay.SelectedRows[0].Cells[0].Value = false;
            }
        }

        private void btnAddTransaction_Click(object sender, EventArgs e)
        {
            
            DataTable table = new DataTable();


            table.Columns.Add("Fee Name");
            table.Columns.Add("Quantity");
            table.Columns.Add("Amount");

            for (int i = 0; i < dgvItemsToPay.Rows.Count; i++)
            {
                GridViewRowInfo row = dgvItemsToPay.Rows[i];
                if (Convert.ToBoolean(row.Cells[0].Value))
                {
                    DataRow wr = table.NewRow();
                    wr[0] = row.Cells[1].Value.ToString();
                    wr[1] = row.Cells[0].Value = null;
                    wr[2] = row.Cells[2].Value.ToString();
                    table.Rows.Add(wr);
                }
            }
            

         //   Payment.items_to_pay = table;

            for (int i = 0; i < table.Rows.Count ; i++)
            {
                tr.dgvTransacList.Rows.Add(table.Rows[i][0].ToString(),
                    table.Rows[i][1].ToString(),
                    table.Rows[i][2].ToString());
            }
            tr.dgvTransacList.Update();
            tr.dgvTransacList.Refresh();

            decimal sum = 0;
            for (int i = 0; i < tr.dgvTransacList.Rows.Count; i++)
            {
                sum += Convert.ToDecimal(tr.dgvTransacList.Rows[i].Cells[2].Value);
            }
            tr.txtTotal.Text = sum.ToString();
            Hide();


        }
    }
}
