﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;

namespace CashieringSystem
{
    public partial class PaymentForm : Telerik.WinControls.UI.RadForm
    {
        public PaymentForm()
        {
            InitializeComponent();
        }

        private void txtAmountTendered_TextChanged(object sender, EventArgs e)
        {
            try
            {
                decimal at = Convert.ToDecimal(txtAmountTendered.Text);
                decimal ta = Convert.ToDecimal(txtTotalAmount.Text);
                decimal change = at -= ta;
                txtChange.Text = Convert.ToString(change);
            }
            catch 
            {
            
            }
            
        }

    }
}
