﻿namespace CashieringSystem
{
    partial class PaymentTypeList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn1 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn2 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn3 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn4 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn5 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn6 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn7 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn8 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn9 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn10 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn11 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn12 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewComboBoxColumn gridViewComboBoxColumn13 = new Telerik.WinControls.UI.GridViewComboBoxColumn();
            Telerik.WinControls.UI.GridViewCheckBoxColumn gridViewCheckBoxColumn1 = new Telerik.WinControls.UI.GridViewCheckBoxColumn();
            this.enumBinder1 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder2 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder3 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder4 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder5 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder6 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder7 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder8 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder9 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder10 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder11 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder12 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.enumBinder13 = new Telerik.WinControls.UI.Data.EnumBinder();
            this.radPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.btnAddTransaction = new Telerik.WinControls.UI.RadButton();
            this.paymentTypeListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dgvItemsToPay = new Telerik.WinControls.UI.RadGridView();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).BeginInit();
            this.radPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddTransaction)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentTypeListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemsToPay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemsToPay.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // enumBinder1
            // 
            this.enumBinder1.Source = typeof(Telerik.WinControls.Enumerations.ImageScaling);
            gridViewComboBoxColumn1.DataSource = this.enumBinder1;
            gridViewComboBoxColumn1.DisplayMember = "Description";
            gridViewComboBoxColumn1.ValueMember = "Value";
            this.enumBinder1.Target = gridViewComboBoxColumn1;
            // 
            // enumBinder2
            // 
            this.enumBinder2.Source = typeof(System.Windows.Forms.FormBorderStyle);
            gridViewComboBoxColumn2.DataSource = this.enumBinder2;
            gridViewComboBoxColumn2.DisplayMember = "Description";
            gridViewComboBoxColumn2.ValueMember = "Value";
            this.enumBinder2.Target = gridViewComboBoxColumn2;
            // 
            // enumBinder3
            // 
            this.enumBinder3.Source = typeof(System.Windows.Forms.AutoSizeMode);
            gridViewComboBoxColumn3.DataSource = this.enumBinder3;
            gridViewComboBoxColumn3.DisplayMember = "Description";
            gridViewComboBoxColumn3.ValueMember = "Value";
            this.enumBinder3.Target = gridViewComboBoxColumn3;
            // 
            // enumBinder4
            // 
            this.enumBinder4.Source = typeof(System.Windows.Forms.AutoValidate);
            gridViewComboBoxColumn4.DataSource = this.enumBinder4;
            gridViewComboBoxColumn4.DisplayMember = "Description";
            gridViewComboBoxColumn4.ValueMember = "Value";
            this.enumBinder4.Target = gridViewComboBoxColumn4;
            // 
            // enumBinder5
            // 
            this.enumBinder5.Source = typeof(System.Windows.Forms.SizeGripStyle);
            gridViewComboBoxColumn5.DataSource = this.enumBinder5;
            gridViewComboBoxColumn5.DisplayMember = "Description";
            gridViewComboBoxColumn5.ValueMember = "Value";
            this.enumBinder5.Target = gridViewComboBoxColumn5;
            // 
            // enumBinder6
            // 
            this.enumBinder6.Source = typeof(System.Windows.Forms.FormStartPosition);
            gridViewComboBoxColumn6.DataSource = this.enumBinder6;
            gridViewComboBoxColumn6.DisplayMember = "Description";
            gridViewComboBoxColumn6.ValueMember = "Value";
            this.enumBinder6.Target = gridViewComboBoxColumn6;
            // 
            // enumBinder7
            // 
            this.enumBinder7.Source = typeof(System.Windows.Forms.FormWindowState);
            gridViewComboBoxColumn7.DataSource = this.enumBinder7;
            gridViewComboBoxColumn7.DisplayMember = "Description";
            gridViewComboBoxColumn7.ValueMember = "Value";
            this.enumBinder7.Target = gridViewComboBoxColumn7;
            // 
            // enumBinder8
            // 
            this.enumBinder8.Source = typeof(System.Windows.Forms.AccessibleRole);
            gridViewComboBoxColumn8.DataSource = this.enumBinder8;
            gridViewComboBoxColumn8.DisplayMember = "Description";
            gridViewComboBoxColumn8.ValueMember = "Value";
            this.enumBinder8.Target = gridViewComboBoxColumn8;
            // 
            // enumBinder9
            // 
            this.enumBinder9.Source = typeof(System.Windows.Forms.AnchorStyles);
            gridViewComboBoxColumn9.DataSource = this.enumBinder9;
            gridViewComboBoxColumn9.DisplayMember = "Description";
            gridViewComboBoxColumn9.ValueMember = "Value";
            this.enumBinder9.Target = gridViewComboBoxColumn9;
            // 
            // enumBinder10
            // 
            this.enumBinder10.Source = typeof(System.Windows.Forms.ImageLayout);
            gridViewComboBoxColumn10.DataSource = this.enumBinder10;
            gridViewComboBoxColumn10.DisplayMember = "Description";
            gridViewComboBoxColumn10.ValueMember = "Value";
            this.enumBinder10.Target = gridViewComboBoxColumn10;
            // 
            // enumBinder11
            // 
            this.enumBinder11.Source = typeof(System.Windows.Forms.DockStyle);
            gridViewComboBoxColumn11.DataSource = this.enumBinder11;
            gridViewComboBoxColumn11.DisplayMember = "Description";
            gridViewComboBoxColumn11.ValueMember = "Value";
            this.enumBinder11.Target = gridViewComboBoxColumn11;
            // 
            // enumBinder12
            // 
            this.enumBinder12.Source = typeof(System.Windows.Forms.RightToLeft);
            gridViewComboBoxColumn12.DataSource = this.enumBinder12;
            gridViewComboBoxColumn12.DisplayMember = "Description";
            gridViewComboBoxColumn12.ValueMember = "Value";
            this.enumBinder12.Target = gridViewComboBoxColumn12;
            // 
            // enumBinder13
            // 
            this.enumBinder13.Source = typeof(System.Windows.Forms.ImeMode);
            gridViewComboBoxColumn13.DataSource = this.enumBinder13;
            gridViewComboBoxColumn13.DisplayMember = "Description";
            gridViewComboBoxColumn13.ValueMember = "Value";
            this.enumBinder13.Target = gridViewComboBoxColumn13;
            // 
            // radPanel1
            // 
            this.radPanel1.Controls.Add(this.btnAddTransaction);
            this.radPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.radPanel1.Location = new System.Drawing.Point(0, 233);
            this.radPanel1.Name = "radPanel1";
            this.radPanel1.Size = new System.Drawing.Size(571, 56);
            this.radPanel1.TabIndex = 1;
            this.radPanel1.ThemeName = "Office2013Light";
            // 
            // btnAddTransaction
            // 
            this.btnAddTransaction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.btnAddTransaction.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTransaction.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnAddTransaction.Location = new System.Drawing.Point(451, 11);
            this.btnAddTransaction.Name = "btnAddTransaction";
            this.btnAddTransaction.Size = new System.Drawing.Size(108, 33);
            this.btnAddTransaction.TabIndex = 1;
            this.btnAddTransaction.Text = "Add Transaction";
            this.btnAddTransaction.ThemeName = "Office2013Light";
            this.btnAddTransaction.Click += new System.EventHandler(this.btnAddTransaction_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnAddTransaction.GetChildAt(0))).Text = "Add Transaction";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnAddTransaction.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddTransaction.GetChildAt(0).GetChildAt(0))).ForeColor = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddTransaction.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(139)))), ((int)(((byte)(203)))));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnAddTransaction.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnAddTransaction.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // paymentTypeListBindingSource
            // 
            this.paymentTypeListBindingSource.DataSource = typeof(CashieringSystem.PaymentTypeList);
            // 
            // dgvItemsToPay
            // 
            this.dgvItemsToPay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(173)))), ((int)(((byte)(78)))));
            this.dgvItemsToPay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvItemsToPay.Location = new System.Drawing.Point(0, 0);
            // 
            // dgvItemsToPay
            // 
            this.dgvItemsToPay.MasterTemplate.AllowAddNewRow = false;
            this.dgvItemsToPay.MasterTemplate.AllowCellContextMenu = false;
            this.dgvItemsToPay.MasterTemplate.AllowColumnChooser = false;
            this.dgvItemsToPay.MasterTemplate.AllowColumnHeaderContextMenu = false;
            this.dgvItemsToPay.MasterTemplate.AllowColumnReorder = false;
            this.dgvItemsToPay.MasterTemplate.AllowColumnResize = false;
            this.dgvItemsToPay.MasterTemplate.AllowDeleteRow = false;
            this.dgvItemsToPay.MasterTemplate.AllowDragToGroup = false;
            this.dgvItemsToPay.MasterTemplate.AllowRowResize = false;
            this.dgvItemsToPay.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            gridViewCheckBoxColumn1.AllowFiltering = false;
            gridViewCheckBoxColumn1.AllowGroup = false;
            gridViewCheckBoxColumn1.AllowHide = false;
            gridViewCheckBoxColumn1.AllowReorder = false;
            gridViewCheckBoxColumn1.AllowResize = false;
            gridViewCheckBoxColumn1.AllowSort = false;
            gridViewCheckBoxColumn1.HeaderText = "Select";
            gridViewCheckBoxColumn1.Name = "column1";
            this.dgvItemsToPay.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewCheckBoxColumn1});
            this.dgvItemsToPay.MasterTemplate.EnableGrouping = false;
            this.dgvItemsToPay.MasterTemplate.MultiSelect = true;
            this.dgvItemsToPay.Name = "dgvItemsToPay";
            this.dgvItemsToPay.Size = new System.Drawing.Size(571, 233);
            this.dgvItemsToPay.TabIndex = 3;
            this.dgvItemsToPay.Text = "radGridView1";
            this.dgvItemsToPay.ThemeName = "Office2013Light";
            // 
            // PaymentTypeList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(571, 289);
            this.Controls.Add(this.dgvItemsToPay);
            this.Controls.Add(this.radPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PaymentTypeList";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Item to Pay";
            this.ThemeName = "Office2013Light";
            this.Load += new System.EventHandler(this.PaymentTypeList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).EndInit();
            this.radPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAddTransaction)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentTypeListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemsToPay.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemsToPay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadPanel radPanel1;
        private Telerik.WinControls.UI.RadButton btnAddTransaction;
        private System.Windows.Forms.BindingSource paymentTypeListBindingSource;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder1;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder2;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder3;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder4;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder5;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder6;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder7;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder8;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder9;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder10;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder11;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder12;
        private Telerik.WinControls.UI.Data.EnumBinder enumBinder13;
        public Telerik.WinControls.UI.RadGridView dgvItemsToPay;


    }
}
