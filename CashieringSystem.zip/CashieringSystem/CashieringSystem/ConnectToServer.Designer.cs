﻿namespace CashieringSystem
{
    partial class ConnectToServer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.btnShowCurrent = new Telerik.WinControls.UI.RadButton();
            this.passwordTxt = new Telerik.WinControls.UI.RadTextBox();
            this.btnExit = new Telerik.WinControls.UI.RadButton();
            this.user_idTxt = new Telerik.WinControls.UI.RadTextBox();
            this.btnClear = new Telerik.WinControls.UI.RadButton();
            this.database_nameTxt = new Telerik.WinControls.UI.RadTextBox();
            this.btnTest = new Telerik.WinControls.UI.RadButton();
            this.server_nameTxt = new Telerik.WinControls.UI.RadTextBox();
            this.password = new Telerik.WinControls.UI.RadLabel();
            this.database_name = new Telerik.WinControls.UI.RadLabel();
            this.username = new Telerik.WinControls.UI.RadLabel();
            this.server = new Telerik.WinControls.UI.RadLabel();
            this.btnSave = new Telerik.WinControls.UI.RadButton();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).BeginInit();
            this.radPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnShowCurrent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordTxt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.user_idTxt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database_nameTxt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.server_nameTxt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.password)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database_name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.username)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.server)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radPanel1
            // 
            this.radPanel1.Controls.Add(this.btnShowCurrent);
            this.radPanel1.Controls.Add(this.passwordTxt);
            this.radPanel1.Controls.Add(this.btnExit);
            this.radPanel1.Controls.Add(this.user_idTxt);
            this.radPanel1.Controls.Add(this.btnClear);
            this.radPanel1.Controls.Add(this.database_nameTxt);
            this.radPanel1.Controls.Add(this.btnTest);
            this.radPanel1.Controls.Add(this.server_nameTxt);
            this.radPanel1.Controls.Add(this.password);
            this.radPanel1.Controls.Add(this.database_name);
            this.radPanel1.Controls.Add(this.username);
            this.radPanel1.Controls.Add(this.server);
            this.radPanel1.Controls.Add(this.btnSave);
            this.radPanel1.Location = new System.Drawing.Point(12, 12);
            this.radPanel1.Name = "radPanel1";
            this.radPanel1.Size = new System.Drawing.Size(348, 255);
            this.radPanel1.TabIndex = 0;
            // 
            // btnShowCurrent
            // 
            this.btnShowCurrent.Location = new System.Drawing.Point(203, 208);
            this.btnShowCurrent.Name = "btnShowCurrent";
            this.btnShowCurrent.Size = new System.Drawing.Size(117, 32);
            this.btnShowCurrent.TabIndex = 8;
            this.btnShowCurrent.Text = "Show Current";
            this.btnShowCurrent.ThemeName = "Office2013Light";
            this.btnShowCurrent.Click += new System.EventHandler(this.btnShowCurrent_Click);
            // 
            // passwordTxt
            // 
            this.passwordTxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordTxt.Location = new System.Drawing.Point(159, 123);
            this.passwordTxt.Name = "passwordTxt";
            this.passwordTxt.PasswordChar = '*';
            this.passwordTxt.Size = new System.Drawing.Size(151, 23);
            this.passwordTxt.TabIndex = 3;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(255, 170);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(65, 32);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.ThemeName = "Office2013Light";
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // user_idTxt
            // 
            this.user_idTxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_idTxt.Location = new System.Drawing.Point(159, 94);
            this.user_idTxt.Name = "user_idTxt";
            this.user_idTxt.Size = new System.Drawing.Size(151, 23);
            this.user_idTxt.TabIndex = 2;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(179, 170);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(65, 32);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear";
            this.btnClear.ThemeName = "Office2013Light";
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // database_nameTxt
            // 
            this.database_nameTxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.database_nameTxt.Location = new System.Drawing.Point(159, 65);
            this.database_nameTxt.Name = "database_nameTxt";
            this.database_nameTxt.Size = new System.Drawing.Size(151, 23);
            this.database_nameTxt.TabIndex = 1;
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(104, 170);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(65, 32);
            this.btnTest.TabIndex = 5;
            this.btnTest.Text = "Test";
            this.btnTest.ThemeName = "Office2013Light";
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // server_nameTxt
            // 
            this.server_nameTxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.server_nameTxt.Location = new System.Drawing.Point(159, 36);
            this.server_nameTxt.Name = "server_nameTxt";
            this.server_nameTxt.Size = new System.Drawing.Size(151, 23);
            this.server_nameTxt.TabIndex = 0;
            // 
            // password
            // 
            this.password.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.password.Location = new System.Drawing.Point(34, 119);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(65, 21);
            this.password.TabIndex = 12;
            this.password.Text = "Password:";
            this.password.ThemeName = "Office2013Light";
            // 
            // database_name
            // 
            this.database_name.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.database_name.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.database_name.Location = new System.Drawing.Point(34, 65);
            this.database_name.Name = "database_name";
            this.database_name.Size = new System.Drawing.Size(104, 21);
            this.database_name.TabIndex = 10;
            this.database_name.Text = "Database Name:";
            this.database_name.ThemeName = "Office2013Light";
            // 
            // username
            // 
            this.username.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.username.Location = new System.Drawing.Point(34, 92);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(69, 21);
            this.username.TabIndex = 11;
            this.username.Text = "Username:";
            this.username.ThemeName = "Office2013Light";
            // 
            // server
            // 
            this.server.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.server.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.server.Location = new System.Drawing.Point(34, 38);
            this.server.Name = "server";
            this.server.Size = new System.Drawing.Size(86, 21);
            this.server.TabIndex = 9;
            this.server.Text = "Server Name:";
            this.server.ThemeName = "Office2013Light";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(27, 170);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(65, 32);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Save";
            this.btnSave.ThemeName = "Office2013Light";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // ConnectToServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(372, 279);
            this.Controls.Add(this.radPanel1);
            this.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ConnectToServer";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Connect to Server";
            this.ThemeName = "Office2013Light";
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).EndInit();
            this.radPanel1.ResumeLayout(false);
            this.radPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnShowCurrent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordTxt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.user_idTxt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database_nameTxt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.server_nameTxt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.password)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database_name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.username)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.server)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadPanel radPanel1;
        private Telerik.WinControls.UI.RadLabel password;
        private Telerik.WinControls.UI.RadLabel database_name;
        private Telerik.WinControls.UI.RadLabel username;
        private Telerik.WinControls.UI.RadLabel server;
        private Telerik.WinControls.UI.RadButton btnShowCurrent;
        private Telerik.WinControls.UI.RadTextBox passwordTxt;
        private Telerik.WinControls.UI.RadButton btnExit;
        private Telerik.WinControls.UI.RadTextBox user_idTxt;
        private Telerik.WinControls.UI.RadButton btnClear;
        private Telerik.WinControls.UI.RadTextBox database_nameTxt;
        private Telerik.WinControls.UI.RadButton btnTest;
        private Telerik.WinControls.UI.RadTextBox server_nameTxt;
        private Telerik.WinControls.UI.RadButton btnSave;

    }
}
