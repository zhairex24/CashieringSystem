﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class UpdateFeeForm : Telerik.WinControls.UI.RadForm
    {
        public UpdateFeeForm()
        {
            InitializeComponent();
        }

        Payment payment = new Payment();
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            decimal amount = decimal.Parse(txtAmount.Text);
            int feeID = Convert.ToInt32(txtFeeID.Text);
            payment.UpdateFee(txtNameOfFee.Text, amount, txtAppliedTo.Text, txtDepartment.Text, feeID);
            
           
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int feeID = Convert.ToInt32(txtFeeID.Text);
            payment.DeleteFee(feeID);
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
        }
    }
}
