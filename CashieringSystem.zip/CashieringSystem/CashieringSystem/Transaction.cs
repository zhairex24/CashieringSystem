﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using Telerik.WinControls.UI;
using CashieringSystem.Classes;
using MySql.Data.MySqlClient;
using CashieringSystem.Properties;

namespace CashieringSystem
{
    public partial class Transaction : Telerik.WinControls.UI.RadForm
    {
        public Transaction()
        {
            InitializeComponent();
            
        }
        
        Payment payment = new Payment();
        private string conString = Settings.Default.constring;

        private void Transaction_Load(object sender, EventArgs e)
        {
            
            dgvBalance.DataSource = payment.GetFeesByStudentId(txtPayorId.Text);
            dgvBalance.Columns[0].HeaderText = "Particular";
            dgvBalance.Columns[1].HeaderText = "Amount";
            dgvBalance.Columns[2].HeaderText = "Balance";

            btnRightArrowFee.TabStop = false;
            btnRightArrowFee.FlatStyle = FlatStyle.Flat;
            btnRightArrowFee.FlatAppearance.BorderSize = 0;
            btnRightArrowFee.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);

            btnRightArrowOther.TabStop = false;
            btnRightArrowOther.FlatStyle = FlatStyle.Flat;
            btnRightArrowOther.FlatAppearance.BorderSize = 0;
            btnRightArrowOther.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
           

           decimal sum = 0;
           for (int i = 0; i < dgv.Rows.Count; ++i)
           {
               sum += Convert.ToDecimal(dgv.Rows[i].Cells[2].Value);
           }
            
        }

        private void btnNewTransac_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Transactions cannot be reverted. Do you want to proceed?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(dr == DialogResult.Yes)
            {
                radPageView1.Enabled = true;
                txtTransacID.Enabled = true;
                txtORNo.Enabled = true;
                txtPaymentType.Enabled = true;
                btnPrint.Enabled = true;
                dgvFees.Enabled = true;
                dgvOthers.Enabled = true;
                lTransacID.Enabled = true;
                lOrNo.Enabled = true;
                lPaymentType.Enabled = true;
                btnRightArrowFee.Enabled = true;
                btnRightArrowOther.Enabled = true;
                btnRightArrowOther.Enabled = true;
                balance.Enabled = true;
                due.Enabled = true;
                txtBalance.Enabled = true;
                txtAmountTendered.Enabled = true;
                txtChange.Enabled = true;
                dgvItemsToPay.Enabled = true;
                btnDelete.Enabled = true;
                radLabel2.Enabled = true;
                radLabel3.Enabled = true;
                radLabel1.Enabled = true;
                change.Enabled = true;
                radPanel1.Enabled = true;
                radPanel2.Enabled = true;
                txtBalance.Enabled = true;
                txtTransacID.Text = payment.GetTransactionID();
                txtORNo.Text = payment.GenerateOR();
                btnNewTransac.Enabled = false;
                
            }
        }

        private void txtPaymentType_SelectedIndexChanged(object sender, Telerik.WinControls.UI.Data.PositionChangedEventArgs e)
        {
            try
            {

                dgvFees.DataSource = payment.GetAllItemByFee();
                dgvOthers.DataSource = payment.GetAllItemByOther();
                   
                dgvFees.Columns[1].HeaderText = "Fee ID";
                dgvFees.Columns[2].HeaderText = "Name of Fee";
                dgvFees.Columns[3].HeaderText = "Amount";
                dgvFees.Columns[4].HeaderText = "Assign To";
                dgvFees.Columns[2].Width = 150;
                dgvFees.Columns[3].Width = 100;
                dgvFees.Columns[4].Width = 150;

                dgvOthers.Columns[2].HeaderText = "Item ID";
                dgvOthers.Columns[3].HeaderText = "Item Name";
                dgvOthers.Columns[4].HeaderText = "No. of Available";
                dgvOthers.Columns[5].HeaderText = "Amount";
                dgvOthers.Columns[2].Width = 60;
                dgvOthers.Columns[3].Width = 150;
                dgvOthers.Columns[4].Width = 110;
                dgvOthers.Columns[5].Width = 90;

                

            }
            catch { }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvItemsToPay.RowCount != 0)
            {
                int rowIndex = dgvItemsToPay.CurrentCell.RowIndex;
                dgvItemsToPay.Rows.RemoveAt(rowIndex);

                decimal sum = 0;
                for (int i = 0; i < dgvItemsToPay.Rows.Count; i++)
                {
                    sum += Convert.ToDecimal(dgvItemsToPay.Rows[i].Cells[3].Value);
                }
                txtBalance.Text = sum.ToString();
            }
        }
       
        private void btnPrint_Click(object sender, EventArgs e)
        {

            int pay_item_id;
            decimal item_amount;
            string payment_type = txtPaymentType.Text;
            decimal amount_paid = Convert.ToDecimal(txtBalance.Text);
            decimal amount_tendered = Convert.ToDecimal(txtAmountTendered.Text);
            decimal amount_change = Convert.ToDecimal(txtChange.Text);
            string student_id = txtPayorId.Text;
            string user_id = ServerConnection.user_id;
            string or = txtORNo.Text;

            for (int i = 0; i < dgvItemsToPay.Rows.Count; i++)
            {
             
               int item_quantity;
               
               pay_item_id = Convert.ToInt32(dgvItemsToPay.Rows[i].Cells[0].Value.ToString());
              // item_name = dgvItemsToPay.Rows[i].Cells[1].Value.ToString();
               item_quantity = Convert.ToInt32(dgvItemsToPay.Rows[i].Cells[2].Value.ToString());
               item_amount = Convert.ToDecimal(dgvItemsToPay.Rows[i].Cells[3].Value.ToString());
               payment.SaveTransactionDetail(item_quantity, item_amount, or, pay_item_id, student_id);
            }

            payment.SaveTransaction(payment_type, amount_paid, amount_tendered, amount_change, or, user_id, student_id);

            this.Close();
            
            ORPrintView orp = new ORPrintView();
            orp.ShowDialog();
        }


        private void btnRightArrowFee_Click(object sender, EventArgs e)
        {
            DataTable table = new DataTable();

            table.Columns.Add("Fee ID");
            table.Columns.Add("Fee Name");
            table.Columns.Add("");
            table.Columns.Add("Amount");

            for (int i = 0; i < dgvFees.Rows.Count; i++)
            {
                GridViewRowInfo row = dgvFees.Rows[i];
                if (Convert.ToBoolean(row.Cells[0].Value))
                {
                    DataRow wr = table.NewRow();
                    wr[0] = row.Cells[1].Value.ToString();
                    wr[1] = row.Cells[2].Value.ToString();
                    wr[2] = row.Cells[0].Value = 0;
                    wr[3] = row.Cells[3].Value.ToString();
                    table.Rows.Add(wr);
                }
            }


            for (int i = 0; i < table.Rows.Count; i++)
            {
                dgvItemsToPay.Rows.Add(table.Rows[i][0].ToString(),
                table.Rows[i][1].ToString(),
                table.Rows[i][2].ToString(),
                table.Rows[i][3].ToString());
            }


            decimal sum = 0;
            for (int i = 0; i < dgvItemsToPay.Rows.Count; i++)
            {
                sum += Convert.ToDecimal(dgvItemsToPay.Rows[i].Cells[3].Value);
            }
            txtBalance.Text = sum.ToString();
        }


        private void btnRightArrowOther_Click(object sender, EventArgs e)
        {
            DataTable table = new DataTable();

            table.Columns.Add("Fee ID");
            table.Columns.Add("Fee Name");
            table.Columns.Add("Quantity");
            table.Columns.Add("Amount");

            for (int i = 0; i < dgvOthers.Rows.Count; i++)
            {

                if (dgvOthers.Rows[i].Cells[1].Value != null)
                {
                   
                    GridViewRowInfo row = dgvOthers.Rows[i];
                    if (Convert.ToBoolean(row.Cells[0].Value))
                    {
                       
                        DataRow wr = table.NewRow();
                        wr[0] = row.Cells[2].Value.ToString();
                        wr[1] = row.Cells[3].Value.ToString();
                        wr[2] = row.Cells[1].Value.ToString();
                        wr[3] = Convert.ToString(Convert.ToDecimal(row.Cells[5].Value.ToString()) * Convert.ToDecimal(row.Cells[1].Value.ToString()));
                        table.Rows.Add(wr);

                    }

                }
                
            }


            for (int i = 0; i < table.Rows.Count; i++)
            {
                dgvItemsToPay.Rows.Add(table.Rows[i][0].ToString(),
                table.Rows[i][1].ToString(),
                table.Rows[i][2].ToString(),
                table.Rows[i][3].ToString());
            }


            decimal sum = 0;
            for (int i = 0; i < dgvItemsToPay.Rows.Count; i++)
            {
                sum += Convert.ToDecimal(dgvItemsToPay.Rows[i].Cells[3].Value);
            }
            txtBalance.Text = sum.ToString();
        }

        private void txtAmountTendered_TextChanged(object sender, EventArgs e)
        {
            try
            {
                decimal at = Convert.ToDecimal(txtAmountTendered.Text);
                decimal ta = Convert.ToDecimal(txtBalance.Text);
                decimal change = at -= ta;
                txtChange.Text = Convert.ToString(change);

                if (txtAmountTendered.Text == null)
                {
                    txtChange.Text = null;
                }
            }
            catch {}
        }

    }
}

