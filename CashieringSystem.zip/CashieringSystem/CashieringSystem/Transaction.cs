﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;
using MySql.Data.MySqlClient;
using CashieringSystem.Properties;

namespace CashieringSystem
{
    public partial class Transaction : Telerik.WinControls.UI.RadForm
    {
        public Transaction()
        {
            InitializeComponent();
            
        }
        
        Payment payment = new Payment();
        private string conString = Settings.Default.constring;

        private void Transaction_Load(object sender, EventArgs e)
        {
            txtORNo.Text = payment.GenerateOR();
 
           

           decimal sum = 0;
           for (int i = 0; i < dgvTransacList.Rows.Count; ++i)
           {
               sum += Convert.ToDecimal(dgvTransacList.Rows[i].Cells[2].Value);
           }
           txtTotal.Text = sum.ToString() + ".00";

           //this.reportViewer1.RefreshReport();
        }

        private void btnNewTransac_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Transactions cannot be reverted. Do you want to proceed?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(dr == DialogResult.Yes)
            {
                radPageView1.Enabled = true;
                txtTransacID.Enabled = true;
                txtPaymentType.Enabled = true;
                btnPayment.Enabled = true;
                dgvTransacList.Enabled = true;
                lTransacID.Enabled = true;
                lItems.Enabled = true;
                lPaymentType.Enabled = true;
                lQuantity.Enabled = true;
                dgvTransacList.Enabled = true;
                btnDelete.Enabled = true;
                txtTotal.Enabled = true;
                lAmount2.Enabled = true;
                txtTransacID.Text = payment.GetTransactionID();
                btnNewTransac.Enabled = false;
                
            }
        }

        private void txtPaymentType_SelectedIndexChanged(object sender, Telerik.WinControls.UI.Data.PositionChangedEventArgs e)
        {

            PaymentTypeList ptl = new PaymentTypeList(this);
            if (txtPaymentType.Text == "Down Payment")
            {
              ptl.dgvItemsToPay.DataSource = payment.PaymentType("Down payment");
              payment.PaymentType("Down payment");

              ptl.Show();
              txtNameOfItems.Enabled = false;
              txtQuantity.Enabled = false;
              txtAmount2.Enabled = false;
            }
            else if (txtPaymentType.Text == "Final Payment")
            {
                ptl.dgvItemsToPay.DataSource = payment.PaymentType("Final payment");
                ptl.Show();

                payment.PaymentType("Final payment");
                txtNameOfItems.Enabled = false;
                txtQuantity.Enabled = false;
                txtAmount2.Enabled = false;
            }
            else if (txtPaymentType.Text == "Other Charges")
            {
                txtNameOfItems.Enabled = true;
                txtQuantity.Enabled = true;
                txtAmount2.Enabled = true;
                btnAddTransaction.Enabled = true;
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            if (dgvTransacList.RowCount != 0)
            {
                int rowIndex = dgvTransacList.CurrentCell.RowIndex;
                dgvTransacList.Rows.RemoveAt(rowIndex);

                decimal sum = 0;
                for (int i = 0; i < dgvTransacList.Rows.Count; i++)
                {
                    sum += Convert.ToDecimal(dgvTransacList.Rows[i].Cells[2].Value);
                }
                txtTotal.Text = sum.ToString();
            }

        }

        private void btnPayment_Click(object sender, EventArgs e)
        {

            PaymentForm pf = new PaymentForm();
            pf.txtTotalAmount.Text = txtTotal.Text;
            
            pf.ShowDialog();

        }

        private void btnAddTransaction_Click(object sender, EventArgs e)
        {   
  
            string items = txtNameOfItems.Text;
            decimal quantity = Convert.ToDecimal(txtQuantity.Text);
            decimal amount = Convert.ToDecimal(txtAmount2.Text);
            string total = Convert.ToString(amount * quantity);
        
            string[] row = { items, txtQuantity.Text, total };
            dgvTransacList.Rows.Add(row);

            decimal sum = 0;
            for (int i = 0; i < dgvTransacList.Rows.Count; i++)
            {
                sum += Convert.ToDecimal(dgvTransacList.Rows[i].Cells[2].Value);
            }
            txtTotal.Text = sum.ToString();
        
        }

    }
}

