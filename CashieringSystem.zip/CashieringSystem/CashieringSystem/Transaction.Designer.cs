﻿namespace CashieringSystem
{
    partial class Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn5 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn6 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn7 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn8 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.RadListDataItem radListDataItem6 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem7 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem8 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem9 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem10 = new Telerik.WinControls.UI.RadListDataItem();
            this.office2013LightTheme1 = new Telerik.WinControls.Themes.Office2013LightTheme();
            this.txtradPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.btnNewTransac = new Telerik.WinControls.UI.RadButton();
            this.orDate = new Telerik.WinControls.UI.RadLabel();
            this.txtORDate = new Telerik.WinControls.UI.RadDateTimePicker();
            this.txtORNo = new Telerik.WinControls.UI.RadTextBox();
            this.orNo = new Telerik.WinControls.UI.RadLabel();
            this.txtPayorId = new Telerik.WinControls.UI.RadTextBox();
            this.course = new Telerik.WinControls.UI.RadLabel();
            this.txtCourse = new Telerik.WinControls.UI.RadTextBox();
            this.eadd = new Telerik.WinControls.UI.RadLabel();
            this.txtHomeasdasd = new Telerik.WinControls.UI.RadTextBox();
            this.name = new Telerik.WinControls.UI.RadLabel();
            this.txtName = new Telerik.WinControls.UI.RadTextBox();
            this.payorID = new Telerik.WinControls.UI.RadLabel();
            this.labelStatus = new Telerik.WinControls.UI.RadLabel();
            this.radPanel2 = new Telerik.WinControls.UI.RadPanel();
            this.radPageView1 = new Telerik.WinControls.UI.RadPageView();
            this.radPageViewPage1 = new Telerik.WinControls.UI.RadPageViewPage();
            this.btnAddTransaction = new Telerik.WinControls.UI.RadButton();
            this.txtTotal = new Telerik.WinControls.UI.RadTextBox();
            this.btnDelete = new Telerik.WinControls.UI.RadButton();
            this.dgvTransacList = new Telerik.WinControls.UI.RadGridView();
            this.btnPayment = new Telerik.WinControls.UI.RadButton();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.lQuantity = new Telerik.WinControls.UI.RadLabel();
            this.txtQuantity = new Telerik.WinControls.UI.RadTextBox();
            this.txtPaymentType = new Telerik.WinControls.UI.RadDropDownList();
            this.txtNameOfItems = new Telerik.WinControls.UI.RadTextBox();
            this.lItems = new Telerik.WinControls.UI.RadLabel();
            this.txtTransacID = new Telerik.WinControls.UI.RadTextBox();
            this.lPaymentType = new Telerik.WinControls.UI.RadLabel();
            this.lTransacID = new Telerik.WinControls.UI.RadLabel();
            this.radPageViewPage2 = new Telerik.WinControls.UI.RadPageViewPage();
            this.object_6abf47d5_399e_4556_83a3_75736eb69fa9 = new Telerik.WinControls.RootRadElement();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.lAmount2 = new Telerik.WinControls.UI.RadLabel();
            this.txtAmount2 = new Telerik.WinControls.UI.RadTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.txtradPanel1)).BeginInit();
            this.txtradPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnNewTransac)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtORDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtORNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayorId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.course)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCourse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eadd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHomeasdasd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.payorID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).BeginInit();
            this.radPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPageView1)).BeginInit();
            this.radPageView1.SuspendLayout();
            this.radPageViewPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddTransaction)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransacList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransacList.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnPayment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaymentType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNameOfItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTransacID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lPaymentType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lTransacID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lAmount2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAmount2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // txtradPanel1
            // 
            this.txtradPanel1.Controls.Add(this.btnNewTransac);
            this.txtradPanel1.Controls.Add(this.orDate);
            this.txtradPanel1.Controls.Add(this.txtORDate);
            this.txtradPanel1.Controls.Add(this.txtORNo);
            this.txtradPanel1.Controls.Add(this.orNo);
            this.txtradPanel1.Controls.Add(this.txtPayorId);
            this.txtradPanel1.Controls.Add(this.course);
            this.txtradPanel1.Controls.Add(this.txtCourse);
            this.txtradPanel1.Controls.Add(this.eadd);
            this.txtradPanel1.Controls.Add(this.txtHomeasdasd);
            this.txtradPanel1.Controls.Add(this.name);
            this.txtradPanel1.Controls.Add(this.txtName);
            this.txtradPanel1.Controls.Add(this.payorID);
            this.txtradPanel1.Controls.Add(this.labelStatus);
            this.txtradPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtradPanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.txtradPanel1.Location = new System.Drawing.Point(0, 0);
            this.txtradPanel1.Name = "txtradPanel1";
            this.txtradPanel1.Size = new System.Drawing.Size(1132, 198);
            this.txtradPanel1.TabIndex = 0;
            // 
            // btnNewTransac
            // 
            this.btnNewTransac.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnNewTransac.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnNewTransac.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewTransac.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnNewTransac.Location = new System.Drawing.Point(835, 130);
            this.btnNewTransac.Name = "btnNewTransac";
            this.btnNewTransac.Size = new System.Drawing.Size(111, 25);
            this.btnNewTransac.TabIndex = 40;
            this.btnNewTransac.Text = "New Transaction";
            this.btnNewTransac.ThemeName = "Office2013Light";
            this.btnNewTransac.Click += new System.EventHandler(this.btnNewTransac_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnNewTransac.GetChildAt(0))).Text = "New Transaction";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnNewTransac.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnNewTransac.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(184)))), ((int)(((byte)(91)))));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // orDate
            // 
            this.orDate.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orDate.Location = new System.Drawing.Point(503, 130);
            this.orDate.Name = "orDate";
            this.orDate.Size = new System.Drawing.Size(75, 24);
            this.orDate.TabIndex = 38;
            this.orDate.Text = "O.R. Date:";
            this.orDate.ThemeName = "Office2013Light";
            // 
            // txtORDate
            // 
            this.txtORDate.AccessibleName = "";
            this.txtORDate.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtORDate.Location = new System.Drawing.Point(624, 130);
            this.txtORDate.Name = "txtORDate";
            this.txtORDate.Size = new System.Drawing.Size(186, 25);
            this.txtORDate.TabIndex = 39;
            this.txtORDate.TabStop = false;
            this.txtORDate.Text = "Wednesday, December 13, 2017";
            this.txtORDate.ThemeName = "Office2013Light";
            this.txtORDate.Value = new System.DateTime(2017, 12, 13, 15, 45, 1, 255);
            // 
            // txtORNo
            // 
            this.txtORNo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtORNo.Location = new System.Drawing.Point(147, 130);
            this.txtORNo.Name = "txtORNo";
            this.txtORNo.Size = new System.Drawing.Size(135, 25);
            this.txtORNo.TabIndex = 38;
            this.txtORNo.ThemeName = "Office2013Light";
            // 
            // orNo
            // 
            this.orNo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orNo.Location = new System.Drawing.Point(26, 129);
            this.orNo.Name = "orNo";
            this.orNo.Size = new System.Drawing.Size(67, 24);
            this.orNo.TabIndex = 37;
            this.orNo.Text = "O.R. No.:";
            this.orNo.ThemeName = "Office2013Light";
            // 
            // txtPayorId
            // 
            this.txtPayorId.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayorId.Location = new System.Drawing.Point(147, 12);
            this.txtPayorId.Name = "txtPayorId";
            this.txtPayorId.Size = new System.Drawing.Size(135, 25);
            this.txtPayorId.TabIndex = 36;
            this.txtPayorId.ThemeName = "Office2013Light";
            // 
            // course
            // 
            this.course.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course.Location = new System.Drawing.Point(26, 81);
            this.course.Name = "course";
            this.course.Size = new System.Drawing.Size(58, 24);
            this.course.TabIndex = 35;
            this.course.Text = "Course:";
            this.course.ThemeName = "Office2013Light";
            // 
            // txtCourse
            // 
            this.txtCourse.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCourse.Location = new System.Drawing.Point(147, 81);
            this.txtCourse.Name = "txtCourse";
            this.txtCourse.Size = new System.Drawing.Size(289, 25);
            this.txtCourse.TabIndex = 34;
            this.txtCourse.ThemeName = "Office2013Light";
            // 
            // eadd
            // 
            this.eadd.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eadd.Location = new System.Drawing.Point(503, 81);
            this.eadd.Name = "eadd";
            this.eadd.Size = new System.Drawing.Size(111, 24);
            this.eadd.TabIndex = 33;
            this.eadd.Text = "Home Address:";
            this.eadd.ThemeName = "Office2013Light";
            // 
            // txtHomeasdasd
            // 
            this.txtHomeasdasd.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHomeasdasd.Location = new System.Drawing.Point(624, 81);
            this.txtHomeasdasd.Name = "txtHomeasdasd";
            this.txtHomeasdasd.Size = new System.Drawing.Size(480, 25);
            this.txtHomeasdasd.TabIndex = 32;
            this.txtHomeasdasd.ThemeName = "Office2013Light";
            // 
            // name
            // 
            this.name.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(26, 46);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(52, 24);
            this.name.TabIndex = 31;
            this.name.Text = "Name:";
            this.name.ThemeName = "Office2013Light";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(147, 46);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(289, 25);
            this.txtName.TabIndex = 30;
            this.txtName.ThemeName = "Office2013Light";
            // 
            // payorID
            // 
            this.payorID.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payorID.Location = new System.Drawing.Point(26, 11);
            this.payorID.Name = "payorID";
            this.payorID.Size = new System.Drawing.Size(79, 24);
            this.payorID.TabIndex = 29;
            this.payorID.Text = "Payor\'s ID:";
            this.payorID.ThemeName = "Office2013Light";
            // 
            // labelStatus
            // 
            this.labelStatus.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStatus.Location = new System.Drawing.Point(879, 21);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(2, 2);
            this.labelStatus.TabIndex = 27;
            this.labelStatus.ThemeName = "Office2013Light";
            // 
            // radPanel2
            // 
            this.radPanel2.Controls.Add(this.radPageView1);
            this.radPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.radPanel2.Location = new System.Drawing.Point(0, 195);
            this.radPanel2.Name = "radPanel2";
            this.radPanel2.Size = new System.Drawing.Size(1132, 449);
            this.radPanel2.TabIndex = 1;
            this.radPanel2.Text = "radPanel2";
            // 
            // radPageView1
            // 
            this.radPageView1.Controls.Add(this.radPageViewPage1);
            this.radPageView1.Controls.Add(this.radPageViewPage2);
            this.radPageView1.Location = new System.Drawing.Point(3, 0);
            this.radPageView1.Name = "radPageView1";
            this.radPageView1.SelectedPage = this.radPageViewPage1;
            this.radPageView1.Size = new System.Drawing.Size(1126, 446);
            this.radPageView1.TabIndex = 0;
            this.radPageView1.ThemeName = "Office2013Light";
            // 
            // radPageViewPage1
            // 
            this.radPageViewPage1.Controls.Add(this.lAmount2);
            this.radPageViewPage1.Controls.Add(this.btnAddTransaction);
            this.radPageViewPage1.Controls.Add(this.txtAmount2);
            this.radPageViewPage1.Controls.Add(this.txtTotal);
            this.radPageViewPage1.Controls.Add(this.btnDelete);
            this.radPageViewPage1.Controls.Add(this.dgvTransacList);
            this.radPageViewPage1.Controls.Add(this.btnPayment);
            this.radPageViewPage1.Controls.Add(this.radLabel1);
            this.radPageViewPage1.Controls.Add(this.lQuantity);
            this.radPageViewPage1.Controls.Add(this.txtQuantity);
            this.radPageViewPage1.Controls.Add(this.txtPaymentType);
            this.radPageViewPage1.Controls.Add(this.txtNameOfItems);
            this.radPageViewPage1.Controls.Add(this.lItems);
            this.radPageViewPage1.Controls.Add(this.txtTransacID);
            this.radPageViewPage1.Controls.Add(this.lPaymentType);
            this.radPageViewPage1.Controls.Add(this.lTransacID);
            this.radPageViewPage1.ForeColor = System.Drawing.Color.Black;
            this.radPageViewPage1.Location = new System.Drawing.Point(5, 31);
            this.radPageViewPage1.Name = "radPageViewPage1";
            this.radPageViewPage1.Size = new System.Drawing.Size(1116, 410);
            this.radPageViewPage1.Text = "Current Transaction";
            // 
            // btnAddTransaction
            // 
            this.btnAddTransaction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.btnAddTransaction.Enabled = false;
            this.btnAddTransaction.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTransaction.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnAddTransaction.Location = new System.Drawing.Point(820, 50);
            this.btnAddTransaction.Name = "btnAddTransaction";
            this.btnAddTransaction.Size = new System.Drawing.Size(71, 25);
            this.btnAddTransaction.TabIndex = 66;
            this.btnAddTransaction.Text = "Add Items";
            this.btnAddTransaction.ThemeName = "Office2013Light";
            this.btnAddTransaction.Click += new System.EventHandler(this.btnAddTransaction_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnAddTransaction.GetChildAt(0))).Text = "Add Items";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnAddTransaction.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddTransaction.GetChildAt(0).GetChildAt(0))).ForeColor = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddTransaction.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(139)))), ((int)(((byte)(203)))));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnAddTransaction.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnAddTransaction.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTotal
            // 
            this.txtTotal.Enabled = false;
            this.txtTotal.Location = new System.Drawing.Point(1003, 302);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(91, 25);
            this.txtTotal.TabIndex = 65;
            this.txtTotal.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadTextBoxItem)(this.txtTotal.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnDelete
            // 
            this.btnDelete.Enabled = false;
            this.btnDelete.Location = new System.Drawing.Point(22, 293);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(63, 25);
            this.btnDelete.TabIndex = 64;
            this.btnDelete.Text = "Remove";
            this.btnDelete.ThemeName = "Office2013Light";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnDelete.GetChildAt(0))).Text = "Remove";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(82)))), ((int)(((byte)(78)))));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(1).GetChildAt(1))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvTransacList
            // 
            this.dgvTransacList.Enabled = false;
            this.dgvTransacList.EnableTheming = false;
            this.dgvTransacList.Location = new System.Drawing.Point(22, 89);
            // 
            // dgvTransacList
            // 
            this.dgvTransacList.MasterTemplate.AllowAddNewRow = false;
            this.dgvTransacList.MasterTemplate.AllowCellContextMenu = false;
            this.dgvTransacList.MasterTemplate.AllowColumnChooser = false;
            this.dgvTransacList.MasterTemplate.AllowColumnHeaderContextMenu = false;
            this.dgvTransacList.MasterTemplate.AllowColumnReorder = false;
            this.dgvTransacList.MasterTemplate.AllowColumnResize = false;
            this.dgvTransacList.MasterTemplate.AllowDragToGroup = false;
            this.dgvTransacList.MasterTemplate.AllowEditRow = false;
            gridViewTextBoxColumn5.HeaderText = "Items";
            gridViewTextBoxColumn5.MaxWidth = 600;
            gridViewTextBoxColumn5.Name = "nameOfFee";
            gridViewTextBoxColumn5.Width = 600;
            gridViewTextBoxColumn6.HeaderText = "Quantity";
            gridViewTextBoxColumn6.MaxWidth = 150;
            gridViewTextBoxColumn6.Name = "quantity";
            gridViewTextBoxColumn6.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            gridViewTextBoxColumn6.Width = 150;
            gridViewTextBoxColumn7.HeaderText = "Amount";
            gridViewTextBoxColumn7.MaxWidth = 150;
            gridViewTextBoxColumn7.Name = "amount";
            gridViewTextBoxColumn7.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            gridViewTextBoxColumn7.Width = 150;
            gridViewTextBoxColumn8.HeaderText = "Date";
            gridViewTextBoxColumn8.MaxWidth = 150;
            gridViewTextBoxColumn8.Name = "date";
            gridViewTextBoxColumn8.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            gridViewTextBoxColumn8.Width = 150;
            this.dgvTransacList.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewTextBoxColumn5,
            gridViewTextBoxColumn6,
            gridViewTextBoxColumn7,
            gridViewTextBoxColumn8});
            this.dgvTransacList.MasterTemplate.EnableSorting = false;
            this.dgvTransacList.Name = "dgvTransacList";
            this.dgvTransacList.ReadOnly = true;
            this.dgvTransacList.ShowItemToolTips = false;
            this.dgvTransacList.Size = new System.Drawing.Size(1072, 198);
            this.dgvTransacList.TabIndex = 63;
            this.dgvTransacList.Text = "radGridView1";
            this.dgvTransacList.ThemeName = "Office2013Light";
            // 
            // btnPayment
            // 
            this.btnPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.btnPayment.Enabled = false;
            this.btnPayment.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPayment.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnPayment.Location = new System.Drawing.Point(1003, 332);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(91, 34);
            this.btnPayment.TabIndex = 0;
            this.btnPayment.Text = "Payment";
            this.btnPayment.ThemeName = "Office2013Light";
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnPayment.GetChildAt(0))).Text = "Payment";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnPayment.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnPayment.GetChildAt(0).GetChildAt(0))).ForeColor = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnPayment.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(184)))), ((int)(((byte)(91)))));
            // 
            // radLabel1
            // 
            this.radLabel1.Enabled = false;
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.Location = new System.Drawing.Point(937, 303);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(66, 27);
            this.radLabel1.TabIndex = 62;
            this.radLabel1.Text = "Total: ₱";
            this.radLabel1.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadLabelElement)(this.radLabel1.GetChildAt(0))).Text = "Total: ₱";
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel1.GetChildAt(0).GetChildAt(2).GetChildAt(1))).TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel1.GetChildAt(0).GetChildAt(2).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lQuantity
            // 
            this.lQuantity.Enabled = false;
            this.lQuantity.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lQuantity.Location = new System.Drawing.Point(346, 52);
            this.lQuantity.Name = "lQuantity";
            this.lQuantity.Size = new System.Drawing.Size(70, 24);
            this.lQuantity.TabIndex = 56;
            this.lQuantity.Text = "Quantity:";
            this.lQuantity.ThemeName = "Office2013Light";
            // 
            // txtQuantity
            // 
            this.txtQuantity.Enabled = false;
            this.txtQuantity.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantity.Location = new System.Drawing.Point(418, 50);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(135, 25);
            this.txtQuantity.TabIndex = 54;
            this.txtQuantity.ThemeName = "Office2013Light";
            // 
            // txtPaymentType
            // 
            this.txtPaymentType.Enabled = false;
            this.txtPaymentType.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem6.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            radListDataItem6.Text = "Down Payment";
            radListDataItem6.TextWrap = true;
            radListDataItem7.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem7.Text = "Midterm Payment";
            radListDataItem7.TextWrap = true;
            radListDataItem8.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem8.Text = "Final Payment";
            radListDataItem8.TextWrap = true;
            radListDataItem9.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem9.Text = "Other Charges";
            radListDataItem9.TextWrap = true;
            radListDataItem10.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem10.Text = "Miscellaneous Balance Payment";
            radListDataItem10.TextWrap = true;
            this.txtPaymentType.Items.Add(radListDataItem6);
            this.txtPaymentType.Items.Add(radListDataItem7);
            this.txtPaymentType.Items.Add(radListDataItem8);
            this.txtPaymentType.Items.Add(radListDataItem9);
            this.txtPaymentType.Items.Add(radListDataItem10);
            this.txtPaymentType.Location = new System.Drawing.Point(679, 11);
            this.txtPaymentType.Name = "txtPaymentType";
            this.txtPaymentType.Size = new System.Drawing.Size(212, 25);
            this.txtPaymentType.TabIndex = 59;
            this.txtPaymentType.ThemeName = "Office2013Light";
            this.txtPaymentType.SelectedIndexChanged += new Telerik.WinControls.UI.Data.PositionChangedEventHandler(this.txtPaymentType_SelectedIndexChanged);
            // 
            // txtNameOfItems
            // 
            this.txtNameOfItems.Enabled = false;
            this.txtNameOfItems.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNameOfItems.Location = new System.Drawing.Point(131, 50);
            this.txtNameOfItems.Name = "txtNameOfItems";
            this.txtNameOfItems.Size = new System.Drawing.Size(181, 25);
            this.txtNameOfItems.TabIndex = 58;
            this.txtNameOfItems.ThemeName = "Office2013Light";
            // 
            // lItems
            // 
            this.lItems.Enabled = false;
            this.lItems.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lItems.Location = new System.Drawing.Point(82, 52);
            this.lItems.Name = "lItems";
            this.lItems.Size = new System.Drawing.Size(48, 24);
            this.lItems.TabIndex = 57;
            this.lItems.Text = "Items:";
            this.lItems.ThemeName = "Office2013Light";
            // 
            // txtTransacID
            // 
            this.txtTransacID.Enabled = false;
            this.txtTransacID.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTransacID.Location = new System.Drawing.Point(141, 11);
            this.txtTransacID.Name = "txtTransacID";
            this.txtTransacID.Size = new System.Drawing.Size(135, 25);
            this.txtTransacID.TabIndex = 55;
            this.txtTransacID.ThemeName = "Office2013Light";
            // 
            // lPaymentType
            // 
            this.lPaymentType.Enabled = false;
            this.lPaymentType.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lPaymentType.Location = new System.Drawing.Point(558, 13);
            this.lPaymentType.Name = "lPaymentType";
            this.lPaymentType.Size = new System.Drawing.Size(107, 24);
            this.lPaymentType.TabIndex = 51;
            this.lPaymentType.Text = "Payment Type:";
            this.lPaymentType.ThemeName = "Office2013Light";
            // 
            // lTransacID
            // 
            this.lTransacID.Enabled = false;
            this.lTransacID.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lTransacID.Location = new System.Drawing.Point(22, 12);
            this.lTransacID.Name = "lTransacID";
            this.lTransacID.Size = new System.Drawing.Size(108, 24);
            this.lTransacID.TabIndex = 49;
            this.lTransacID.Text = "Transaction ID:";
            this.lTransacID.ThemeName = "Office2013Light";
            // 
            // radPageViewPage2
            // 
            this.radPageViewPage2.Location = new System.Drawing.Point(5, 31);
            this.radPageViewPage2.Name = "radPageViewPage2";
            this.radPageViewPage2.Size = new System.Drawing.Size(1116, 410);
            this.radPageViewPage2.Text = "radPageViewPage2";
            // 
            // object_6abf47d5_399e_4556_83a3_75736eb69fa9
            // 
            this.object_6abf47d5_399e_4556_83a3_75736eb69fa9.Name = "object_6abf47d5_399e_4556_83a3_75736eb69fa9";
            this.object_6abf47d5_399e_4556_83a3_75736eb69fa9.StretchHorizontally = true;
            this.object_6abf47d5_399e_4556_83a3_75736eb69fa9.StretchVertically = true;
            this.object_6abf47d5_399e_4556_83a3_75736eb69fa9.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(396, 246);
            this.reportViewer1.TabIndex = 0;
            // 
            // lAmount2
            // 
            this.lAmount2.Enabled = false;
            this.lAmount2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lAmount2.Location = new System.Drawing.Point(595, 52);
            this.lAmount2.Name = "lAmount2";
            this.lAmount2.Size = new System.Drawing.Size(83, 24);
            this.lAmount2.TabIndex = 58;
            this.lAmount2.Text = "Amount:  ₱";
            this.lAmount2.ThemeName = "Office2013Light";
            // 
            // txtAmount2
            // 
            this.txtAmount2.Enabled = false;
            this.txtAmount2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmount2.Location = new System.Drawing.Point(678, 50);
            this.txtAmount2.Name = "txtAmount2";
            this.txtAmount2.Size = new System.Drawing.Size(135, 25);
            this.txtAmount2.TabIndex = 57;
            this.txtAmount2.ThemeName = "Office2013Light";
            // 
            // Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1132, 644);
            this.Controls.Add(this.radPanel2);
            this.Controls.Add(this.txtradPanel1);
            this.Name = "Transaction";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transaction";
            this.ThemeName = "Office2013Light";
            this.Load += new System.EventHandler(this.Transaction_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtradPanel1)).EndInit();
            this.txtradPanel1.ResumeLayout(false);
            this.txtradPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnNewTransac)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtORDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtORNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayorId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.course)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCourse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eadd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHomeasdasd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.payorID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).EndInit();
            this.radPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radPageView1)).EndInit();
            this.radPageView1.ResumeLayout(false);
            this.radPageViewPage1.ResumeLayout(false);
            this.radPageViewPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddTransaction)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransacList.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransacList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnPayment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaymentType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNameOfItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTransacID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lPaymentType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lTransacID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lAmount2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAmount2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.Themes.Office2013LightTheme office2013LightTheme1;
        private Telerik.WinControls.UI.RadPanel txtradPanel1;
        public Telerik.WinControls.UI.RadLabel labelStatus;
        public Telerik.WinControls.UI.RadTextBox txtPayorId;
        private Telerik.WinControls.UI.RadLabel course;
        public Telerik.WinControls.UI.RadTextBox txtCourse;
        private Telerik.WinControls.UI.RadLabel eadd;
        public Telerik.WinControls.UI.RadTextBox txtHomeasdasd;
        private Telerik.WinControls.UI.RadLabel name;
        public Telerik.WinControls.UI.RadTextBox txtName;
        private Telerik.WinControls.UI.RadLabel payorID;
        private Telerik.WinControls.UI.RadPanel radPanel2;
        private Telerik.WinControls.UI.RadLabel orDate;
        public Telerik.WinControls.UI.RadTextBox txtORNo;
        private Telerik.WinControls.UI.RadLabel orNo;
        private Telerik.WinControls.UI.RadButton btnNewTransac;
        public Telerik.WinControls.UI.RadDateTimePicker txtORDate;
        private Telerik.WinControls.UI.RadPageViewPage radPageViewPage1;
        private Telerik.WinControls.UI.RadLabel lQuantity;
        public Telerik.WinControls.UI.RadTextBox txtQuantity;
        public Telerik.WinControls.UI.RadTextBox txtNameOfItems;
        private Telerik.WinControls.UI.RadLabel lItems;
        public Telerik.WinControls.UI.RadTextBox txtTransacID;
        private Telerik.WinControls.UI.RadLabel lPaymentType;
        private Telerik.WinControls.UI.RadLabel lTransacID;
        public Telerik.WinControls.UI.RadPageView radPageView1;
        private Telerik.WinControls.UI.RadPageViewPage radPageViewPage2;
        public Telerik.WinControls.UI.RadDropDownList txtPaymentType;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadButton btnPayment;
        private Telerik.WinControls.RootRadElement object_6abf47d5_399e_4556_83a3_75736eb69fa9;
        public Telerik.WinControls.UI.RadGridView dgvTransacList;
        private Telerik.WinControls.UI.RadButton btnDelete;
        public Telerik.WinControls.UI.RadTextBox txtTotal;
        private Telerik.WinControls.UI.RadButton btnAddTransaction;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private Telerik.WinControls.UI.RadLabel lAmount2;
        public Telerik.WinControls.UI.RadTextBox txtAmount2;
    }
}
