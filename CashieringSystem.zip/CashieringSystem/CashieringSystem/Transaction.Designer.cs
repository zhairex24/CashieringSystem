﻿namespace CashieringSystem
{
    partial class Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn1 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn2 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn3 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn4 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Transaction));
            Telerik.WinControls.UI.GridViewCheckBoxColumn gridViewCheckBoxColumn1 = new Telerik.WinControls.UI.GridViewCheckBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn5 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewCheckBoxColumn gridViewCheckBoxColumn2 = new Telerik.WinControls.UI.GridViewCheckBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn6 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn7 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn8 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn9 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.RadListDataItem radListDataItem1 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem2 = new Telerik.WinControls.UI.RadListDataItem();
            this.office2013LightTheme1 = new Telerik.WinControls.Themes.Office2013LightTheme();
            this.object_6abf47d5_399e_4556_83a3_75736eb69fa9 = new Telerik.WinControls.RootRadElement();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.dgv = new Telerik.WinControls.UI.MasterGridViewTemplate();
            this.labelStatus = new Telerik.WinControls.UI.RadLabel();
            this.payorID = new Telerik.WinControls.UI.RadLabel();
            this.name = new Telerik.WinControls.UI.RadLabel();
            this.eadd = new Telerik.WinControls.UI.RadLabel();
            this.course = new Telerik.WinControls.UI.RadLabel();
            this.lOrNo = new Telerik.WinControls.UI.RadLabel();
            this.orDate = new Telerik.WinControls.UI.RadLabel();
            this.btnNewTransac = new Telerik.WinControls.UI.RadButton();
            this.txtradPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.radPageView1 = new Telerik.WinControls.UI.RadPageView();
            this.radPageViewPage1 = new Telerik.WinControls.UI.RadPageViewPage();
            this.btnRightArrowOther = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.ImageList(this.components);
            this.radPanel3 = new Telerik.WinControls.UI.RadPanel();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.dgvOthers = new Telerik.WinControls.UI.RadGridView();
            this.radPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.txtORNo = new Telerik.WinControls.UI.RadTextBox();
            this.radPanel2 = new Telerik.WinControls.UI.RadPanel();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.btnRightArrowFee = new System.Windows.Forms.Button();
            this.change = new Telerik.WinControls.UI.RadLabel();
            this.txtChange = new Telerik.WinControls.UI.RadTextBox();
            this.due = new Telerik.WinControls.UI.RadLabel();
            this.balance = new Telerik.WinControls.UI.RadLabel();
            this.txtAmountTendered = new Telerik.WinControls.UI.RadTextBox();
            this.txtBalance = new Telerik.WinControls.UI.RadTextBox();
            this.dgvFees = new Telerik.WinControls.UI.RadGridView();
            this.dgvItemsToPay = new Telerik.WinControls.UI.RadGridView();
            this.btnDelete = new Telerik.WinControls.UI.RadButton();
            this.btnPrint = new Telerik.WinControls.UI.RadButton();
            this.txtPaymentType = new Telerik.WinControls.UI.RadDropDownList();
            this.txtTransacID = new Telerik.WinControls.UI.RadTextBox();
            this.lPaymentType = new Telerik.WinControls.UI.RadLabel();
            this.lTransacID = new Telerik.WinControls.UI.RadLabel();
            this.radPageViewPage2 = new Telerik.WinControls.UI.RadPageViewPage();
            this.radPanel4 = new Telerik.WinControls.UI.RadPanel();
            this.radLabel8 = new Telerik.WinControls.UI.RadLabel();
            this.radGridView1 = new Telerik.WinControls.UI.RadGridView();
            this.txtLevel = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.radPanel5 = new Telerik.WinControls.UI.RadPanel();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.dgvBalance = new Telerik.WinControls.UI.RadGridView();
            this.radTextBox2 = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.radTextBox1 = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.txtORDate = new Telerik.WinControls.UI.RadDateTimePicker();
            this.txtPayorId = new Telerik.WinControls.UI.RadTextBox();
            this.txtCourse = new Telerik.WinControls.UI.RadTextBox();
            this.txtHome = new Telerik.WinControls.UI.RadTextBox();
            this.txtName = new Telerik.WinControls.UI.RadTextBox();
            this.btnRight2 = new System.Windows.Forms.ImageList(this.components);
            this.telerikMetroBlueTheme1 = new Telerik.WinControls.Themes.TelerikMetroBlueTheme();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.payorID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eadd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.course)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lOrNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNewTransac)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtradPanel1)).BeginInit();
            this.txtradPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPageView1)).BeginInit();
            this.radPageView1.SuspendLayout();
            this.radPageViewPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel3)).BeginInit();
            this.radPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOthers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOthers.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).BeginInit();
            this.radPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtORNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).BeginInit();
            this.radPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.change)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtChange)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.due)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.balance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAmountTendered)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBalance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFees)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFees.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemsToPay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemsToPay.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnPrint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaymentType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTransacID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lPaymentType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lTransacID)).BeginInit();
            this.radPageViewPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel4)).BeginInit();
            this.radPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel5)).BeginInit();
            this.radPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBalance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBalance.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtORDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayorId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCourse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // object_6abf47d5_399e_4556_83a3_75736eb69fa9
            // 
            this.object_6abf47d5_399e_4556_83a3_75736eb69fa9.Name = "object_6abf47d5_399e_4556_83a3_75736eb69fa9";
            this.object_6abf47d5_399e_4556_83a3_75736eb69fa9.StretchHorizontally = true;
            this.object_6abf47d5_399e_4556_83a3_75736eb69fa9.StretchVertically = true;
            this.object_6abf47d5_399e_4556_83a3_75736eb69fa9.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(396, 246);
            this.reportViewer1.TabIndex = 0;
            // 
            // dgv
            // 
            this.dgv.AllowAddNewRow = false;
            this.dgv.AllowCellContextMenu = false;
            this.dgv.AllowColumnChooser = false;
            this.dgv.AllowColumnHeaderContextMenu = false;
            this.dgv.AllowColumnReorder = false;
            this.dgv.AllowColumnResize = false;
            this.dgv.AllowDragToGroup = false;
            this.dgv.AllowEditRow = false;
            gridViewTextBoxColumn1.HeaderText = "Items";
            gridViewTextBoxColumn1.MaxWidth = 600;
            gridViewTextBoxColumn1.Name = "nameOfFee";
            gridViewTextBoxColumn1.Width = 600;
            gridViewTextBoxColumn2.HeaderText = "Quantity";
            gridViewTextBoxColumn2.MaxWidth = 150;
            gridViewTextBoxColumn2.Name = "quantity";
            gridViewTextBoxColumn2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            gridViewTextBoxColumn2.Width = 150;
            gridViewTextBoxColumn3.HeaderText = "Amount";
            gridViewTextBoxColumn3.MaxWidth = 150;
            gridViewTextBoxColumn3.Name = "amount";
            gridViewTextBoxColumn3.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            gridViewTextBoxColumn3.Width = 150;
            gridViewTextBoxColumn4.HeaderText = "Date";
            gridViewTextBoxColumn4.MaxWidth = 150;
            gridViewTextBoxColumn4.Name = "date";
            gridViewTextBoxColumn4.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            gridViewTextBoxColumn4.Width = 150;
            this.dgv.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewTextBoxColumn1,
            gridViewTextBoxColumn2,
            gridViewTextBoxColumn3,
            gridViewTextBoxColumn4});
            this.dgv.EnableSorting = false;
            // 
            // labelStatus
            // 
            this.labelStatus.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStatus.Location = new System.Drawing.Point(288, 12);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(2, 2);
            this.labelStatus.TabIndex = 27;
            this.labelStatus.ThemeName = "Office2013Light";
            // 
            // payorID
            // 
            this.payorID.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payorID.Location = new System.Drawing.Point(36, 11);
            this.payorID.Name = "payorID";
            this.payorID.Size = new System.Drawing.Size(90, 24);
            this.payorID.TabIndex = 29;
            this.payorID.Text = "Students ID:";
            this.payorID.ThemeName = "Office2013Light";
            // 
            // name
            // 
            this.name.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(74, 43);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(52, 24);
            this.name.TabIndex = 31;
            this.name.Text = "Name:";
            this.name.ThemeName = "Office2013Light";
            // 
            // eadd
            // 
            this.eadd.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eadd.Location = new System.Drawing.Point(489, 43);
            this.eadd.Name = "eadd";
            this.eadd.Size = new System.Drawing.Size(111, 24);
            this.eadd.TabIndex = 33;
            this.eadd.Text = "Home Address:";
            this.eadd.ThemeName = "Office2013Light";
            // 
            // course
            // 
            this.course.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course.Location = new System.Drawing.Point(67, 74);
            this.course.Name = "course";
            this.course.Size = new System.Drawing.Size(58, 24);
            this.course.TabIndex = 35;
            this.course.Text = "Course:";
            this.course.ThemeName = "Office2013Light";
            // 
            // lOrNo
            // 
            this.lOrNo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lOrNo.Location = new System.Drawing.Point(391, 12);
            this.lOrNo.Name = "lOrNo";
            this.lOrNo.Size = new System.Drawing.Size(67, 24);
            this.lOrNo.TabIndex = 37;
            this.lOrNo.Text = "O.R. No.:";
            this.lOrNo.ThemeName = "Office2013Light";
            // 
            // orDate
            // 
            this.orDate.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orDate.Location = new System.Drawing.Point(525, 76);
            this.orDate.Name = "orDate";
            this.orDate.Size = new System.Drawing.Size(75, 24);
            this.orDate.TabIndex = 38;
            this.orDate.Text = "O.R. Date:";
            this.orDate.ThemeName = "Office2013Light";
            // 
            // btnNewTransac
            // 
            this.btnNewTransac.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnNewTransac.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnNewTransac.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewTransac.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnNewTransac.Location = new System.Drawing.Point(830, 76);
            this.btnNewTransac.Name = "btnNewTransac";
            this.btnNewTransac.Size = new System.Drawing.Size(111, 25);
            this.btnNewTransac.TabIndex = 40;
            this.btnNewTransac.Text = "New Transaction";
            this.btnNewTransac.ThemeName = "Office2013Light";
            this.btnNewTransac.Click += new System.EventHandler(this.btnNewTransac_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnNewTransac.GetChildAt(0))).Text = "New Transaction";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnNewTransac.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnNewTransac.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(184)))), ((int)(((byte)(91)))));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnNewTransac.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // txtradPanel1
            // 
            this.txtradPanel1.Controls.Add(this.radPageView1);
            this.txtradPanel1.Controls.Add(this.btnNewTransac);
            this.txtradPanel1.Controls.Add(this.orDate);
            this.txtradPanel1.Controls.Add(this.txtORDate);
            this.txtradPanel1.Controls.Add(this.txtPayorId);
            this.txtradPanel1.Controls.Add(this.course);
            this.txtradPanel1.Controls.Add(this.txtCourse);
            this.txtradPanel1.Controls.Add(this.eadd);
            this.txtradPanel1.Controls.Add(this.txtHome);
            this.txtradPanel1.Controls.Add(this.name);
            this.txtradPanel1.Controls.Add(this.txtName);
            this.txtradPanel1.Controls.Add(this.payorID);
            this.txtradPanel1.Controls.Add(this.labelStatus);
            this.txtradPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtradPanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.txtradPanel1.Location = new System.Drawing.Point(0, 0);
            this.txtradPanel1.Name = "txtradPanel1";
            this.txtradPanel1.Size = new System.Drawing.Size(1132, 644);
            this.txtradPanel1.TabIndex = 0;
            // 
            // radPageView1
            // 
            this.radPageView1.Controls.Add(this.radPageViewPage1);
            this.radPageView1.Controls.Add(this.radPageViewPage2);
            this.radPageView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.radPageView1.Location = new System.Drawing.Point(0, 123);
            this.radPageView1.Name = "radPageView1";
            this.radPageView1.SelectedPage = this.radPageViewPage1;
            this.radPageView1.Size = new System.Drawing.Size(1132, 521);
            this.radPageView1.TabIndex = 41;
            this.radPageView1.ThemeName = "Office2013Light";
            // 
            // radPageViewPage1
            // 
            this.radPageViewPage1.Controls.Add(this.btnRightArrowOther);
            this.radPageViewPage1.Controls.Add(this.radPanel3);
            this.radPageViewPage1.Controls.Add(this.dgvOthers);
            this.radPageViewPage1.Controls.Add(this.radPanel1);
            this.radPageViewPage1.Controls.Add(this.txtORNo);
            this.radPageViewPage1.Controls.Add(this.radPanel2);
            this.radPageViewPage1.Controls.Add(this.lOrNo);
            this.radPageViewPage1.Controls.Add(this.btnRightArrowFee);
            this.radPageViewPage1.Controls.Add(this.change);
            this.radPageViewPage1.Controls.Add(this.txtChange);
            this.radPageViewPage1.Controls.Add(this.due);
            this.radPageViewPage1.Controls.Add(this.balance);
            this.radPageViewPage1.Controls.Add(this.txtAmountTendered);
            this.radPageViewPage1.Controls.Add(this.txtBalance);
            this.radPageViewPage1.Controls.Add(this.dgvFees);
            this.radPageViewPage1.Controls.Add(this.dgvItemsToPay);
            this.radPageViewPage1.Controls.Add(this.btnDelete);
            this.radPageViewPage1.Controls.Add(this.btnPrint);
            this.radPageViewPage1.Controls.Add(this.txtPaymentType);
            this.radPageViewPage1.Controls.Add(this.txtTransacID);
            this.radPageViewPage1.Controls.Add(this.lPaymentType);
            this.radPageViewPage1.Controls.Add(this.lTransacID);
            this.radPageViewPage1.ForeColor = System.Drawing.Color.Black;
            this.radPageViewPage1.Location = new System.Drawing.Point(5, 31);
            this.radPageViewPage1.Name = "radPageViewPage1";
            this.radPageViewPage1.Size = new System.Drawing.Size(1122, 485);
            this.radPageViewPage1.Text = "Current Transaction";
            // 
            // btnRightArrowOther
            // 
            this.btnRightArrowOther.Enabled = false;
            this.btnRightArrowOther.ImageIndex = 0;
            this.btnRightArrowOther.ImageList = this.btnRight;
            this.btnRightArrowOther.Location = new System.Drawing.Point(521, 244);
            this.btnRightArrowOther.Name = "btnRightArrowOther";
            this.btnRightArrowOther.Size = new System.Drawing.Size(57, 40);
            this.btnRightArrowOther.TabIndex = 83;
            this.btnRightArrowOther.UseVisualStyleBackColor = true;
            this.btnRightArrowOther.Click += new System.EventHandler(this.btnRightArrowOther_Click);
            // 
            // btnRight
            // 
            this.btnRight.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("btnRight.ImageStream")));
            this.btnRight.TransparentColor = System.Drawing.Color.Transparent;
            this.btnRight.Images.SetKeyName(0, "arrow_6bX_icon.ico");
            // 
            // radPanel3
            // 
            this.radPanel3.Controls.Add(this.radLabel1);
            this.radPanel3.Enabled = false;
            this.radPanel3.Location = new System.Drawing.Point(7, 177);
            this.radPanel3.Name = "radPanel3";
            this.radPanel3.Size = new System.Drawing.Size(123, 27);
            this.radPanel3.TabIndex = 81;
            this.radPanel3.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel1
            // 
            this.radLabel1.Enabled = false;
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.Location = new System.Drawing.Point(3, 1);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(59, 25);
            this.radLabel1.TabIndex = 69;
            this.radLabel1.Text = "Others";
            this.radLabel1.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadLabelElement)(this.radLabel1.GetChildAt(0))).Text = "Others";
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel1.GetChildAt(0).GetChildAt(2).GetChildAt(1))).TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel1.GetChildAt(0).GetChildAt(2).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dgvOthers
            // 
            this.dgvOthers.Enabled = false;
            this.dgvOthers.Location = new System.Drawing.Point(7, 203);
            // 
            // dgvOthers
            // 
            this.dgvOthers.MasterTemplate.AllowAddNewRow = false;
            this.dgvOthers.MasterTemplate.AllowDragToGroup = false;
            gridViewCheckBoxColumn1.HeaderText = "Select";
            gridViewCheckBoxColumn1.MaxWidth = 45;
            gridViewCheckBoxColumn1.Name = "column1";
            gridViewCheckBoxColumn1.Width = 45;
            gridViewTextBoxColumn5.HeaderText = "No. of Order";
            gridViewTextBoxColumn5.MaxWidth = 150;
            gridViewTextBoxColumn5.Name = "column2";
            gridViewTextBoxColumn5.Width = 90;
            this.dgvOthers.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewCheckBoxColumn1,
            gridViewTextBoxColumn5});
            this.dgvOthers.MasterTemplate.EnableGrouping = false;
            this.dgvOthers.Name = "dgvOthers";
            this.dgvOthers.Size = new System.Drawing.Size(493, 144);
            this.dgvOthers.TabIndex = 82;
            this.dgvOthers.Text = "radGridView2";
            this.dgvOthers.ThemeName = "TelerikMetroBlue";
            // 
            // radPanel1
            // 
            this.radPanel1.Controls.Add(this.radLabel2);
            this.radPanel1.Enabled = false;
            this.radPanel1.Location = new System.Drawing.Point(595, 53);
            this.radPanel1.Name = "radPanel1";
            this.radPanel1.Size = new System.Drawing.Size(123, 27);
            this.radPanel1.TabIndex = 70;
            this.radPanel1.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel2
            // 
            this.radLabel2.Enabled = false;
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel2.Location = new System.Drawing.Point(3, 1);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(104, 25);
            this.radLabel2.TabIndex = 69;
            this.radLabel2.Text = "Items to pay";
            this.radLabel2.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadLabelElement)(this.radLabel2.GetChildAt(0))).Text = "Items to pay";
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel2.GetChildAt(0).GetChildAt(2).GetChildAt(1))).TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel2.GetChildAt(0).GetChildAt(2).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // txtORNo
            // 
            this.txtORNo.Enabled = false;
            this.txtORNo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtORNo.Location = new System.Drawing.Point(472, 13);
            this.txtORNo.Name = "txtORNo";
            this.txtORNo.Size = new System.Drawing.Size(135, 25);
            this.txtORNo.TabIndex = 38;
            this.txtORNo.ThemeName = "Office2013Light";
            // 
            // radPanel2
            // 
            this.radPanel2.Controls.Add(this.radLabel3);
            this.radPanel2.Enabled = false;
            this.radPanel2.Location = new System.Drawing.Point(7, 52);
            this.radPanel2.Name = "radPanel2";
            this.radPanel2.Size = new System.Drawing.Size(123, 27);
            this.radPanel2.TabIndex = 72;
            this.radPanel2.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel3
            // 
            this.radLabel3.Enabled = false;
            this.radLabel3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel3.Location = new System.Drawing.Point(3, 1);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(41, 25);
            this.radLabel3.TabIndex = 69;
            this.radLabel3.Text = "Fees";
            this.radLabel3.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadLabelElement)(this.radLabel3.GetChildAt(0))).Text = "Fees";
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel3.GetChildAt(0).GetChildAt(2).GetChildAt(1))).TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel3.GetChildAt(0).GetChildAt(2).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnRightArrowFee
            // 
            this.btnRightArrowFee.Enabled = false;
            this.btnRightArrowFee.ImageIndex = 0;
            this.btnRightArrowFee.ImageList = this.btnRight;
            this.btnRightArrowFee.Location = new System.Drawing.Point(521, 101);
            this.btnRightArrowFee.Name = "btnRightArrowFee";
            this.btnRightArrowFee.Size = new System.Drawing.Size(57, 40);
            this.btnRightArrowFee.TabIndex = 80;
            this.btnRightArrowFee.UseVisualStyleBackColor = true;
            this.btnRightArrowFee.Click += new System.EventHandler(this.btnRightArrowFee_Click);
            // 
            // change
            // 
            this.change.Enabled = false;
            this.change.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.change.Location = new System.Drawing.Point(809, 414);
            this.change.Name = "change";
            this.change.Size = new System.Drawing.Size(157, 24);
            this.change.TabIndex = 79;
            this.change.Text = "                 Change:   ₱";
            this.change.ThemeName = "Office2013Light";
            // 
            // txtChange
            // 
            this.txtChange.Enabled = false;
            this.txtChange.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChange.Location = new System.Drawing.Point(969, 414);
            this.txtChange.Name = "txtChange";
            this.txtChange.Size = new System.Drawing.Size(145, 23);
            this.txtChange.TabIndex = 78;
            this.txtChange.ThemeName = "Office2013Light";
            // 
            // due
            // 
            this.due.Enabled = false;
            this.due.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.due.Location = new System.Drawing.Point(808, 385);
            this.due.Name = "due";
            this.due.Size = new System.Drawing.Size(157, 24);
            this.due.TabIndex = 77;
            this.due.Text = "Amount Tendered:   ₱";
            this.due.ThemeName = "Office2013Light";
            // 
            // balance
            // 
            this.balance.Enabled = false;
            this.balance.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balance.Location = new System.Drawing.Point(810, 355);
            this.balance.Name = "balance";
            this.balance.Size = new System.Drawing.Size(148, 24);
            this.balance.TabIndex = 76;
            this.balance.Text = "                Balance:  ₱";
            this.balance.ThemeName = "Office2013Light";
            // 
            // txtAmountTendered
            // 
            this.txtAmountTendered.Enabled = false;
            this.txtAmountTendered.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmountTendered.Location = new System.Drawing.Point(968, 384);
            this.txtAmountTendered.Name = "txtAmountTendered";
            this.txtAmountTendered.Size = new System.Drawing.Size(146, 23);
            this.txtAmountTendered.TabIndex = 75;
            this.txtAmountTendered.ThemeName = "Office2013Light";
            this.txtAmountTendered.TextChanged += new System.EventHandler(this.txtAmountTendered_TextChanged);
            // 
            // txtBalance
            // 
            this.txtBalance.Enabled = false;
            this.txtBalance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBalance.Location = new System.Drawing.Point(969, 355);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.Size = new System.Drawing.Size(145, 23);
            this.txtBalance.TabIndex = 74;
            this.txtBalance.ThemeName = "Office2013Light";
            // 
            // dgvFees
            // 
            this.dgvFees.Enabled = false;
            this.dgvFees.Location = new System.Drawing.Point(7, 78);
            // 
            // dgvFees
            // 
            this.dgvFees.MasterTemplate.AllowAddNewRow = false;
            this.dgvFees.MasterTemplate.AllowDragToGroup = false;
            gridViewCheckBoxColumn2.HeaderText = "Select";
            gridViewCheckBoxColumn2.MaxWidth = 45;
            gridViewCheckBoxColumn2.Name = "column1";
            gridViewCheckBoxColumn2.Width = 45;
            this.dgvFees.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewCheckBoxColumn2});
            this.dgvFees.MasterTemplate.EnableGrouping = false;
            this.dgvFees.Name = "dgvFees";
            this.dgvFees.Size = new System.Drawing.Size(493, 93);
            this.dgvFees.TabIndex = 73;
            this.dgvFees.Text = "radGridView2";
            this.dgvFees.ThemeName = "TelerikMetroBlue";
            // 
            // dgvItemsToPay
            // 
            this.dgvItemsToPay.Enabled = false;
            this.dgvItemsToPay.Location = new System.Drawing.Point(595, 78);
            // 
            // dgvItemsToPay
            // 
            this.dgvItemsToPay.MasterTemplate.AllowDeleteRow = false;
            this.dgvItemsToPay.MasterTemplate.AllowDragToGroup = false;
            gridViewTextBoxColumn6.HeaderText = "Fee ID";
            gridViewTextBoxColumn6.Name = "column4";
            gridViewTextBoxColumn7.HeaderText = "Items";
            gridViewTextBoxColumn7.MaxWidth = 321;
            gridViewTextBoxColumn7.Name = "column1";
            gridViewTextBoxColumn7.Width = 273;
            gridViewTextBoxColumn8.HeaderText = "Quantity";
            gridViewTextBoxColumn8.MaxWidth = 90;
            gridViewTextBoxColumn8.Name = "column2";
            gridViewTextBoxColumn8.Width = 90;
            gridViewTextBoxColumn9.HeaderText = "Amount";
            gridViewTextBoxColumn9.MaxWidth = 90;
            gridViewTextBoxColumn9.Name = "column3";
            gridViewTextBoxColumn9.Width = 90;
            this.dgvItemsToPay.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewTextBoxColumn6,
            gridViewTextBoxColumn7,
            gridViewTextBoxColumn8,
            gridViewTextBoxColumn9});
            this.dgvItemsToPay.MasterTemplate.EnableGrouping = false;
            this.dgvItemsToPay.Name = "dgvItemsToPay";
            this.dgvItemsToPay.ReadOnly = true;
            this.dgvItemsToPay.Size = new System.Drawing.Size(520, 269);
            this.dgvItemsToPay.TabIndex = 71;
            this.dgvItemsToPay.Text = "radGridView1";
            this.dgvItemsToPay.ThemeName = "TelerikMetroBlue";
            // 
            // btnDelete
            // 
            this.btnDelete.Enabled = false;
            this.btnDelete.Location = new System.Drawing.Point(595, 353);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(63, 25);
            this.btnDelete.TabIndex = 64;
            this.btnDelete.Text = "Remove";
            this.btnDelete.ThemeName = "Office2013Light";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnDelete.GetChildAt(0))).Text = "Remove";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(82)))), ((int)(((byte)(78)))));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(1).GetChildAt(1))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDelete.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.btnPrint.Enabled = false;
            this.btnPrint.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnPrint.Location = new System.Drawing.Point(1048, 445);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(65, 30);
            this.btnPrint.TabIndex = 0;
            this.btnPrint.Text = "Print";
            this.btnPrint.ThemeName = "Office2013Light";
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnPrint.GetChildAt(0))).Text = "Print";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnPrint.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnPrint.GetChildAt(0).GetChildAt(0))).ForeColor = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnPrint.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(184)))), ((int)(((byte)(91)))));
            // 
            // txtPaymentType
            // 
            this.txtPaymentType.Enabled = false;
            this.txtPaymentType.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem1.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            radListDataItem1.Text = "Cash";
            radListDataItem1.TextWrap = true;
            radListDataItem2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem2.Text = "Cheque";
            radListDataItem2.TextWrap = true;
            this.txtPaymentType.Items.Add(radListDataItem1);
            this.txtPaymentType.Items.Add(radListDataItem2);
            this.txtPaymentType.Location = new System.Drawing.Point(843, 12);
            this.txtPaymentType.Name = "txtPaymentType";
            // 
            // 
            // 
            this.txtPaymentType.RootElement.StretchVertically = true;
            this.txtPaymentType.Size = new System.Drawing.Size(212, 25);
            this.txtPaymentType.TabIndex = 59;
            this.txtPaymentType.ThemeName = "Office2013Light";
            this.txtPaymentType.SelectedIndexChanged += new Telerik.WinControls.UI.Data.PositionChangedEventHandler(this.txtPaymentType_SelectedIndexChanged);
            // 
            // txtTransacID
            // 
            this.txtTransacID.Enabled = false;
            this.txtTransacID.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTransacID.Location = new System.Drawing.Point(162, 12);
            this.txtTransacID.Name = "txtTransacID";
            this.txtTransacID.Size = new System.Drawing.Size(135, 25);
            this.txtTransacID.TabIndex = 55;
            this.txtTransacID.ThemeName = "Office2013Light";
            // 
            // lPaymentType
            // 
            this.lPaymentType.Enabled = false;
            this.lPaymentType.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lPaymentType.Location = new System.Drawing.Point(693, 14);
            this.lPaymentType.Name = "lPaymentType";
            this.lPaymentType.Size = new System.Drawing.Size(133, 24);
            this.lPaymentType.TabIndex = 51;
            this.lPaymentType.Text = "Mode of Payment:";
            this.lPaymentType.ThemeName = "Office2013Light";
            // 
            // lTransacID
            // 
            this.lTransacID.Enabled = false;
            this.lTransacID.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lTransacID.Location = new System.Drawing.Point(53, 13);
            this.lTransacID.Name = "lTransacID";
            this.lTransacID.Size = new System.Drawing.Size(108, 24);
            this.lTransacID.TabIndex = 49;
            this.lTransacID.Text = "Transaction ID:";
            this.lTransacID.ThemeName = "Office2013Light";
            // 
            // radPageViewPage2
            // 
            this.radPageViewPage2.Controls.Add(this.radPanel4);
            this.radPageViewPage2.Controls.Add(this.radGridView1);
            this.radPageViewPage2.Controls.Add(this.txtLevel);
            this.radPageViewPage2.Controls.Add(this.radLabel6);
            this.radPageViewPage2.Controls.Add(this.radPanel5);
            this.radPageViewPage2.Controls.Add(this.dgvBalance);
            this.radPageViewPage2.Controls.Add(this.radTextBox2);
            this.radPageViewPage2.Controls.Add(this.radLabel4);
            this.radPageViewPage2.Controls.Add(this.radTextBox1);
            this.radPageViewPage2.Controls.Add(this.radLabel5);
            this.radPageViewPage2.Location = new System.Drawing.Point(5, 31);
            this.radPageViewPage2.Name = "radPageViewPage2";
            this.radPageViewPage2.Size = new System.Drawing.Size(1122, 485);
            this.radPageViewPage2.Text = "Balance";
            // 
            // radPanel4
            // 
            this.radPanel4.Controls.Add(this.radLabel8);
            this.radPanel4.Location = new System.Drawing.Point(591, 129);
            this.radPanel4.Name = "radPanel4";
            this.radPanel4.Size = new System.Drawing.Size(171, 27);
            this.radPanel4.TabIndex = 90;
            this.radPanel4.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel8
            // 
            this.radLabel8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel8.Location = new System.Drawing.Point(3, 1);
            this.radLabel8.Name = "radLabel8";
            this.radLabel8.Size = new System.Drawing.Size(146, 25);
            this.radLabel8.TabIndex = 69;
            this.radLabel8.Text = "Transaction Made";
            this.radLabel8.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadLabelElement)(this.radLabel8.GetChildAt(0))).Text = "Transaction Made";
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel8.GetChildAt(0).GetChildAt(2).GetChildAt(1))).TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel8.GetChildAt(0).GetChildAt(2).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // radGridView1
            // 
            this.radGridView1.Location = new System.Drawing.Point(591, 155);
            // 
            // radGridView1
            // 
            this.radGridView1.MasterTemplate.AllowAddNewRow = false;
            this.radGridView1.MasterTemplate.AllowDragToGroup = false;
            this.radGridView1.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            this.radGridView1.MasterTemplate.EnableGrouping = false;
            this.radGridView1.Name = "radGridView1";
            this.radGridView1.Size = new System.Drawing.Size(493, 144);
            this.radGridView1.TabIndex = 91;
            this.radGridView1.Text = "radGridView1";
            this.radGridView1.ThemeName = "TelerikMetroBlue";
            // 
            // txtLevel
            // 
            this.txtLevel.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.txtLevel.Location = new System.Drawing.Point(611, 27);
            this.txtLevel.Name = "txtLevel";
            this.txtLevel.Size = new System.Drawing.Size(197, 25);
            this.txtLevel.TabIndex = 89;
            this.txtLevel.ThemeName = "Office2013Light";
            // 
            // radLabel6
            // 
            this.radLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel6.Location = new System.Drawing.Point(539, 28);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(52, 22);
            this.radLabel6.TabIndex = 88;
            this.radLabel6.Text = "Level:";
            this.radLabel6.ThemeName = "Office2013Light";
            // 
            // radPanel5
            // 
            this.radPanel5.Controls.Add(this.radLabel7);
            this.radPanel5.Location = new System.Drawing.Point(44, 128);
            this.radPanel5.Name = "radPanel5";
            this.radPanel5.Size = new System.Drawing.Size(171, 27);
            this.radPanel5.TabIndex = 85;
            this.radPanel5.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel7
            // 
            this.radLabel7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel7.Location = new System.Drawing.Point(3, 1);
            this.radLabel7.Name = "radLabel7";
            this.radLabel7.Size = new System.Drawing.Size(68, 25);
            this.radLabel7.TabIndex = 69;
            this.radLabel7.Text = "Balance";
            this.radLabel7.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadLabelElement)(this.radLabel7.GetChildAt(0))).Text = "Balance";
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel7.GetChildAt(0).GetChildAt(2).GetChildAt(1))).TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel7.GetChildAt(0).GetChildAt(2).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dgvBalance
            // 
            this.dgvBalance.Location = new System.Drawing.Point(44, 154);
            // 
            // dgvBalance
            // 
            this.dgvBalance.MasterTemplate.AllowAddNewRow = false;
            this.dgvBalance.MasterTemplate.AllowDragToGroup = false;
            this.dgvBalance.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            this.dgvBalance.MasterTemplate.EnableGrouping = false;
            this.dgvBalance.Name = "dgvBalance";
            this.dgvBalance.Size = new System.Drawing.Size(493, 144);
            this.dgvBalance.TabIndex = 86;
            this.dgvBalance.Text = "radGridView2";
            this.dgvBalance.ThemeName = "TelerikMetroBlue";
            // 
            // radTextBox2
            // 
            this.radTextBox2.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.radTextBox2.Location = new System.Drawing.Point(411, 25);
            this.radTextBox2.Name = "radTextBox2";
            this.radTextBox2.Size = new System.Drawing.Size(82, 25);
            this.radTextBox2.TabIndex = 74;
            this.radTextBox2.ThemeName = "Office2013Light";
            // 
            // radLabel4
            // 
            this.radLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel4.Location = new System.Drawing.Point(318, 26);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(83, 22);
            this.radLabel4.TabIndex = 73;
            this.radLabel4.Text = "Semester:";
            this.radLabel4.ThemeName = "Office2013Light";
            // 
            // radTextBox1
            // 
            this.radTextBox1.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.radTextBox1.Location = new System.Drawing.Point(97, 25);
            this.radTextBox1.Name = "radTextBox1";
            this.radTextBox1.Size = new System.Drawing.Size(197, 25);
            this.radTextBox1.TabIndex = 72;
            this.radTextBox1.ThemeName = "Office2013Light";
            // 
            // radLabel5
            // 
            this.radLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel5.Location = new System.Drawing.Point(44, 26);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(47, 22);
            this.radLabel5.TabIndex = 71;
            this.radLabel5.Text = "Year:";
            this.radLabel5.ThemeName = "Office2013Light";
            // 
            // txtORDate
            // 
            this.txtORDate.AccessibleName = "";
            this.txtORDate.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtORDate.Location = new System.Drawing.Point(619, 76);
            this.txtORDate.Name = "txtORDate";
            this.txtORDate.Size = new System.Drawing.Size(186, 25);
            this.txtORDate.TabIndex = 39;
            this.txtORDate.TabStop = false;
            this.txtORDate.Text = "Wednesday, 13 December 2017";
            this.txtORDate.ThemeName = "Office2013Light";
            this.txtORDate.Value = new System.DateTime(2017, 12, 13, 15, 45, 1, 255);
            // 
            // txtPayorId
            // 
            this.txtPayorId.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayorId.Location = new System.Drawing.Point(147, 12);
            this.txtPayorId.Name = "txtPayorId";
            this.txtPayorId.Size = new System.Drawing.Size(143, 25);
            this.txtPayorId.TabIndex = 36;
            this.txtPayorId.ThemeName = "Office2013Light";
            // 
            // txtCourse
            // 
            this.txtCourse.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCourse.Location = new System.Drawing.Point(147, 74);
            this.txtCourse.Name = "txtCourse";
            this.txtCourse.Size = new System.Drawing.Size(289, 25);
            this.txtCourse.TabIndex = 34;
            this.txtCourse.ThemeName = "Office2013Light";
            // 
            // txtHome
            // 
            this.txtHome.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHome.Location = new System.Drawing.Point(619, 43);
            this.txtHome.Name = "txtHome";
            this.txtHome.Size = new System.Drawing.Size(480, 25);
            this.txtHome.TabIndex = 32;
            this.txtHome.ThemeName = "Office2013Light";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(147, 43);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(289, 25);
            this.txtName.TabIndex = 30;
            this.txtName.ThemeName = "Office2013Light";
            // 
            // btnRight2
            // 
            this.btnRight2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("btnRight2.ImageStream")));
            this.btnRight2.TransparentColor = System.Drawing.Color.Transparent;
            this.btnRight2.Images.SetKeyName(0, "arrow_6bX_icon.ico");
            // 
            // Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1132, 644);
            this.Controls.Add(this.txtradPanel1);
            this.Name = "Transaction";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transaction";
            this.ThemeName = "Office2013Light";
            this.Load += new System.EventHandler(this.Transaction_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.payorID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eadd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.course)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lOrNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNewTransac)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtradPanel1)).EndInit();
            this.txtradPanel1.ResumeLayout(false);
            this.txtradPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPageView1)).EndInit();
            this.radPageView1.ResumeLayout(false);
            this.radPageViewPage1.ResumeLayout(false);
            this.radPageViewPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel3)).EndInit();
            this.radPanel3.ResumeLayout(false);
            this.radPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOthers.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOthers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).EndInit();
            this.radPanel1.ResumeLayout(false);
            this.radPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtORNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).EndInit();
            this.radPanel2.ResumeLayout(false);
            this.radPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.change)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtChange)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.due)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.balance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAmountTendered)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBalance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFees.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFees)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemsToPay.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemsToPay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnPrint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaymentType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTransacID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lPaymentType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lTransacID)).EndInit();
            this.radPageViewPage2.ResumeLayout(false);
            this.radPageViewPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel4)).EndInit();
            this.radPanel4.ResumeLayout(false);
            this.radPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel5)).EndInit();
            this.radPanel5.ResumeLayout(false);
            this.radPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBalance.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBalance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtORDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayorId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCourse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.Themes.Office2013LightTheme office2013LightTheme1;
        private Telerik.WinControls.RootRadElement object_6abf47d5_399e_4556_83a3_75736eb69fa9;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        public Telerik.WinControls.UI.MasterGridViewTemplate dgv;
        public Telerik.WinControls.UI.RadLabel labelStatus;
        private Telerik.WinControls.UI.RadLabel payorID;
        private Telerik.WinControls.UI.RadLabel name;
        private Telerik.WinControls.UI.RadLabel eadd;
        private Telerik.WinControls.UI.RadLabel course;
        private Telerik.WinControls.UI.RadLabel lOrNo;
        private Telerik.WinControls.UI.RadLabel orDate;
        private Telerik.WinControls.UI.RadButton btnNewTransac;
        private Telerik.WinControls.UI.RadPanel txtradPanel1;
        public Telerik.WinControls.UI.RadDateTimePicker txtORDate;
        public Telerik.WinControls.UI.RadTextBox txtORNo;
        public Telerik.WinControls.UI.RadTextBox txtPayorId;
        public Telerik.WinControls.UI.RadTextBox txtCourse;
        public Telerik.WinControls.UI.RadTextBox txtHome;
        public Telerik.WinControls.UI.RadTextBox txtName;
        public Telerik.WinControls.UI.RadPageView radPageView1;
        private Telerik.WinControls.UI.RadPageViewPage radPageViewPage1;
        private Telerik.WinControls.UI.RadButton btnDelete;
        private Telerik.WinControls.UI.RadButton btnPrint;
        public Telerik.WinControls.UI.RadDropDownList txtPaymentType;
        public Telerik.WinControls.UI.RadTextBox txtTransacID;
        private Telerik.WinControls.UI.RadLabel lPaymentType;
        private Telerik.WinControls.UI.RadLabel lTransacID;
        private Telerik.WinControls.UI.RadPageViewPage radPageViewPage2;
        private Telerik.WinControls.UI.RadGridView dgvFees;
        private Telerik.WinControls.UI.RadPanel radPanel2;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadGridView dgvItemsToPay;
        private Telerik.WinControls.UI.RadPanel radPanel1;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadLabel change;
        public Telerik.WinControls.UI.RadTextBox txtChange;
        private Telerik.WinControls.UI.RadLabel due;
        private Telerik.WinControls.UI.RadLabel balance;
        public Telerik.WinControls.UI.RadTextBox txtAmountTendered;
        public Telerik.WinControls.UI.RadTextBox txtBalance;
        private System.Windows.Forms.ImageList btnRight;
        private System.Windows.Forms.Button btnRightArrowFee;
        private Telerik.WinControls.UI.RadPanel radPanel3;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadGridView dgvOthers;
        private System.Windows.Forms.ImageList btnRight2;
        private System.Windows.Forms.Button btnRightArrowOther;
        private Telerik.WinControls.UI.RadPanel radPanel5;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadGridView dgvBalance;
        private Telerik.WinControls.UI.RadTextBox radTextBox2;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadTextBox radTextBox1;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        public Telerik.WinControls.UI.RadTextBox txtLevel;
        private Telerik.WinControls.UI.RadPanel radPanel4;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        private Telerik.WinControls.UI.RadGridView radGridView1;
        private Telerik.WinControls.Themes.TelerikMetroBlueTheme telerikMetroBlueTheme1;
    }
}
