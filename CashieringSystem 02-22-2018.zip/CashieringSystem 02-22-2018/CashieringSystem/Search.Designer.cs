﻿namespace CashieringSystem
{
    partial class Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.dgvStudInfo = new Telerik.WinControls.UI.RadGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtSearch = new Telerik.WinControls.UI.RadTextBox();
            this.telerikMetroBlueTheme1 = new Telerik.WinControls.Themes.TelerikMetroBlueTheme();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).BeginInit();
            this.radPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudInfo.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radPanel1
            // 
            this.radPanel1.Controls.Add(this.pictureBox1);
            this.radPanel1.Controls.Add(this.txtSearch);
            this.radPanel1.Controls.Add(this.radLabel1);
            this.radPanel1.Controls.Add(this.dgvStudInfo);
            this.radPanel1.Location = new System.Drawing.Point(0, 0);
            this.radPanel1.Name = "radPanel1";
            this.radPanel1.Size = new System.Drawing.Size(1366, 601);
            this.radPanel1.TabIndex = 0;
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.Location = new System.Drawing.Point(5, 10);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(183, 30);
            this.radLabel1.TabIndex = 0;
            this.radLabel1.Text = "Student Information";
            // 
            // dgvStudInfo
            // 
            this.dgvStudInfo.BackColor = System.Drawing.Color.Transparent;
            this.dgvStudInfo.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvStudInfo.Location = new System.Drawing.Point(0, 46);
            // 
            // dgvStudInfo
            // 
            this.dgvStudInfo.MasterTemplate.AllowAddNewRow = false;
            this.dgvStudInfo.MasterTemplate.AllowColumnResize = false;
            this.dgvStudInfo.MasterTemplate.AllowDeleteRow = false;
            this.dgvStudInfo.MasterTemplate.AllowDragToGroup = false;
            this.dgvStudInfo.MasterTemplate.AllowEditRow = false;
            this.dgvStudInfo.MasterTemplate.AllowRowResize = false;
            this.dgvStudInfo.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            this.dgvStudInfo.MasterTemplate.ShowHeaderCellButtons = true;
            this.dgvStudInfo.Name = "dgvStudInfo";
            this.dgvStudInfo.ShowGroupPanel = false;
            this.dgvStudInfo.ShowHeaderCellButtons = true;
            this.dgvStudInfo.Size = new System.Drawing.Size(1366, 555);
            this.dgvStudInfo.TabIndex = 4;
            this.dgvStudInfo.Text = "radGridView1";
            this.dgvStudInfo.ThemeName = "TelerikMetroBlue";
            this.dgvStudInfo.CellDoubleClick += new Telerik.WinControls.UI.GridViewCellEventHandler(this.dgvStudInfo_CellDoubleClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CashieringSystem.Properties.Resources.search_icon;
            this.pictureBox1.Location = new System.Drawing.Point(1293, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 18);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 86;
            this.pictureBox1.TabStop = false;
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(1132, 15);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(191, 23);
            this.txtSearch.TabIndex = 85;
            this.txtSearch.ThemeName = "Office2013Light";
            // 
            // Search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 728);
            this.Controls.Add(this.radPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "Search";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "Search";
            this.ThemeName = "Office2013Light";
            this.Load += new System.EventHandler(this.Search_Load);
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).EndInit();
            this.radPanel1.ResumeLayout(false);
            this.radPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudInfo.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadPanel radPanel1;
        private Telerik.WinControls.UI.RadGridView dgvStudInfo;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        public Telerik.WinControls.UI.RadTextBox txtSearch;
        private Telerik.WinControls.Themes.TelerikMetroBlueTheme telerikMetroBlueTheme1;

    }
}
