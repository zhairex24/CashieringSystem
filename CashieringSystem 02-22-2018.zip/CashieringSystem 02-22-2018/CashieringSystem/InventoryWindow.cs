﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class InventoryWindow : Telerik.WinControls.UI.RadForm
    {
        public InventoryWindow()
        {
            InitializeComponent();
        }

        Payment p = new Payment();
        Inventory i = new Inventory();

        private void Inventory_Load(object sender, EventArgs e)
        {
            DataTable dt_itemCode = new DataTable();
            dt_itemCode = i.GetItemCode();

            txtItemCodeList.DataSource = dt_itemCode;
            txtItemCodeList.DisplayMember = "item_code";
            txtItemCodeList.ValueMember = "item_code";

            DataRow dr = dt_itemCode.NewRow();
            dr[0] = "--Select--";
            dt_itemCode.Rows.Add(dr);

            dgvInventoryHistory.DataSource = i.GetAllItemHistory();
            
        }

        private void txtItemCodeList_SelectedValueChanged(object sender, EventArgs e)
        {
            if (txtItemCodeList.Text == "--Select--")
            {

                dgvInventoryHistory.DataSource = i.GetAllItemHistory();

            }
            else
            {

                dgvInventoryHistory.DataSource = i.GetAllItemHistoryByItemCode(txtItemCodeList.Text);
            
            }
        }
    }
}
