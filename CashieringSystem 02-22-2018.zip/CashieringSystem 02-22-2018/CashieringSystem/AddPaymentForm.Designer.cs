﻿namespace CashieringSystem
{
    partial class AddPaymentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.RadListDataItem radListDataItem8 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem9 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem10 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem11 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem12 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem13 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem14 = new Telerik.WinControls.UI.RadListDataItem();
            this.radSplitContainer1 = new Telerik.WinControls.UI.RadSplitContainer();
            this.splitPanel1 = new Telerik.WinControls.UI.SplitPanel();
            this.txtAssignTo = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel8 = new Telerik.WinControls.UI.RadLabel();
            this.dgvFees = new Telerik.WinControls.UI.RadGridView();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.btnDeleteFee = new Telerik.WinControls.UI.RadButton();
            this.btnUpdateFee = new Telerik.WinControls.UI.RadButton();
            this.btnClearFee = new Telerik.WinControls.UI.RadButton();
            this.amount = new Telerik.WinControls.UI.RadLabel();
            this.txtID = new Telerik.WinControls.UI.RadTextBox();
            this.nameOfFee = new Telerik.WinControls.UI.RadLabel();
            this.txtFeeAmount = new Telerik.WinControls.UI.RadTextBox();
            this.txtFeeName = new Telerik.WinControls.UI.RadTextBox();
            this.btnSaveFee = new Telerik.WinControls.UI.RadButton();
            this.txtFeeId = new Telerik.WinControls.UI.RadTextBox();
            this.splitPanel2 = new Telerik.WinControls.UI.SplitPanel();
            this.radSplitContainer2 = new Telerik.WinControls.UI.RadSplitContainer();
            this.splitPanel3 = new Telerik.WinControls.UI.SplitPanel();
            this.btnAddQuantity = new Telerik.WinControls.UI.RadButton();
            this.txtQuantityToAdd = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel13 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel12 = new Telerik.WinControls.UI.RadLabel();
            this.radTextBox2 = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel9 = new Telerik.WinControls.UI.RadLabel();
            this.txtItemCode2 = new Telerik.WinControls.UI.RadTextBox();
            this.txtItemName2 = new Telerik.WinControls.UI.RadTextBox();
            this.txtQuantity2 = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel11 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel10 = new Telerik.WinControls.UI.RadLabel();
            this.dgvItems = new Telerik.WinControls.UI.RadGridView();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.txtColor = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.txtSize = new Telerik.WinControls.UI.RadDropDownList();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.txtItemCode = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.txtItemId = new Telerik.WinControls.UI.RadTextBox();
            this.btnDeleteItem = new Telerik.WinControls.UI.RadButton();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.btnSaveItem = new Telerik.WinControls.UI.RadButton();
            this.btnUpdateItem = new Telerik.WinControls.UI.RadButton();
            this.txtItemName = new Telerik.WinControls.UI.RadTextBox();
            this.txtItemAmount = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.radTextBox1 = new Telerik.WinControls.UI.RadTextBox();
            this.btnClearItem = new Telerik.WinControls.UI.RadButton();
            this.department = new Telerik.WinControls.UI.RadLabel();
            this.txtQuantity = new Telerik.WinControls.UI.RadTextBox();
            this.office2013LightTheme1 = new Telerik.WinControls.Themes.Office2013LightTheme();
            this.telerikMetroBlueTheme1 = new Telerik.WinControls.Themes.TelerikMetroBlueTheme();
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer1)).BeginInit();
            this.radSplitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel1)).BeginInit();
            this.splitPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtAssignTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFees)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFees.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDeleteFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnUpdateFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClearFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.amount)).BeginInit();
            this.amount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameOfFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFeeAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFeeName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveFee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFeeId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel2)).BeginInit();
            this.splitPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer2)).BeginInit();
            this.radSplitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel3)).BeginInit();
            this.splitPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuantityToAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).BeginInit();
            this.radLabel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemCode2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemName2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuantity2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            this.radLabel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDeleteItem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveItem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnUpdateItem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            this.radLabel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClearItem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.department)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radSplitContainer1
            // 
            this.radSplitContainer1.Controls.Add(this.splitPanel1);
            this.radSplitContainer1.Controls.Add(this.splitPanel2);
            this.radSplitContainer1.Location = new System.Drawing.Point(0, 0);
            this.radSplitContainer1.Name = "radSplitContainer1";
            this.radSplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // 
            // 
            this.radSplitContainer1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.radSplitContainer1.Size = new System.Drawing.Size(1358, 697);
            this.radSplitContainer1.TabIndex = 0;
            this.radSplitContainer1.TabStop = false;
            this.radSplitContainer1.Text = "radSplitContainer1";
            this.radSplitContainer1.ThemeName = "Office2013Light";
            // 
            // splitPanel1
            // 
            this.splitPanel1.Controls.Add(this.txtAssignTo);
            this.splitPanel1.Controls.Add(this.radLabel8);
            this.splitPanel1.Controls.Add(this.dgvFees);
            this.splitPanel1.Controls.Add(this.radLabel6);
            this.splitPanel1.Controls.Add(this.btnDeleteFee);
            this.splitPanel1.Controls.Add(this.btnUpdateFee);
            this.splitPanel1.Controls.Add(this.btnClearFee);
            this.splitPanel1.Controls.Add(this.amount);
            this.splitPanel1.Controls.Add(this.nameOfFee);
            this.splitPanel1.Controls.Add(this.txtFeeAmount);
            this.splitPanel1.Controls.Add(this.txtFeeName);
            this.splitPanel1.Controls.Add(this.btnSaveFee);
            this.splitPanel1.Controls.Add(this.txtFeeId);
            this.splitPanel1.Location = new System.Drawing.Point(0, 0);
            this.splitPanel1.Name = "splitPanel1";
            // 
            // 
            // 
            this.splitPanel1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel1.Size = new System.Drawing.Size(1358, 243);
            this.splitPanel1.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(0F, -0.1498559F);
            this.splitPanel1.SizeInfo.SplitterCorrection = new System.Drawing.Size(0, -105);
            this.splitPanel1.TabIndex = 0;
            this.splitPanel1.TabStop = false;
            this.splitPanel1.Text = "splitPanel1";
            this.splitPanel1.ThemeName = "Office2013Light";
            // 
            // txtAssignTo
            // 
            this.txtAssignTo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAssignTo.Location = new System.Drawing.Point(129, 117);
            this.txtAssignTo.Name = "txtAssignTo";
            // 
            // 
            // 
            this.txtAssignTo.RootElement.StretchVertically = true;
            this.txtAssignTo.Size = new System.Drawing.Size(183, 23);
            this.txtAssignTo.TabIndex = 73;
            this.txtAssignTo.ThemeName = "Office2013Light";
            // 
            // radLabel8
            // 
            this.radLabel8.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel8.Location = new System.Drawing.Point(26, 116);
            this.radLabel8.Name = "radLabel8";
            this.radLabel8.Size = new System.Drawing.Size(77, 24);
            this.radLabel8.TabIndex = 28;
            this.radLabel8.Text = "Assign To:";
            this.radLabel8.ThemeName = "Office2013Light";
            // 
            // dgvFees
            // 
            this.dgvFees.Dock = System.Windows.Forms.DockStyle.Right;
            this.dgvFees.Location = new System.Drawing.Point(333, 0);
            // 
            // dgvFees
            // 
            this.dgvFees.MasterTemplate.AllowAddNewRow = false;
            this.dgvFees.MasterTemplate.AllowDeleteRow = false;
            this.dgvFees.MasterTemplate.AllowDragToGroup = false;
            this.dgvFees.MasterTemplate.AllowEditRow = false;
            this.dgvFees.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            this.dgvFees.MasterTemplate.EnableGrouping = false;
            this.dgvFees.Name = "dgvFees";
            this.dgvFees.Size = new System.Drawing.Size(1025, 243);
            this.dgvFees.TabIndex = 72;
            this.dgvFees.Text = "radGridView1";
            this.dgvFees.ThemeName = "TelerikMetroBlue";
            this.dgvFees.CellDoubleClick += new Telerik.WinControls.UI.GridViewCellEventHandler(this.dgvFees_CellDoubleClick);
            // 
            // radLabel6
            // 
            this.radLabel6.Font = new System.Drawing.Font("Segoe UI", 20F);
            this.radLabel6.Location = new System.Drawing.Point(13, 6);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(97, 31);
            this.radLabel6.TabIndex = 71;
            this.radLabel6.Text = "Add Fees";
            this.radLabel6.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadLabelElement)(this.radLabel6.GetChildAt(0))).Text = "Add Fees";
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel6.GetChildAt(0).GetChildAt(2).GetChildAt(1))).TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel6.GetChildAt(0).GetChildAt(2).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            // 
            // btnDeleteFee
            // 
            this.btnDeleteFee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnDeleteFee.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnDeleteFee.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteFee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnDeleteFee.Location = new System.Drawing.Point(176, 189);
            this.btnDeleteFee.Name = "btnDeleteFee";
            this.btnDeleteFee.Size = new System.Drawing.Size(65, 31);
            this.btnDeleteFee.TabIndex = 36;
            this.btnDeleteFee.Text = "Delete";
            this.btnDeleteFee.ThemeName = "Office2013Light";
            this.btnDeleteFee.Click += new System.EventHandler(this.btnDeleteFee_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnDeleteFee.GetChildAt(0))).Text = "Delete";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnDeleteFee.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnDeleteFee.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(82)))), ((int)(((byte)(78)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnDeleteFee.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // btnUpdateFee
            // 
            this.btnUpdateFee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnUpdateFee.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnUpdateFee.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateFee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnUpdateFee.Location = new System.Drawing.Point(247, 189);
            this.btnUpdateFee.Name = "btnUpdateFee";
            this.btnUpdateFee.Size = new System.Drawing.Size(65, 31);
            this.btnUpdateFee.TabIndex = 37;
            this.btnUpdateFee.Text = "Update";
            this.btnUpdateFee.ThemeName = "Office2013Light";
            this.btnUpdateFee.Click += new System.EventHandler(this.btnUpdateFee_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnUpdateFee.GetChildAt(0))).Text = "Update";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnUpdateFee.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnUpdateFee.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateFee.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateFee.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateFee.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateFee.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateFee.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateFee.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateFee.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateFee.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(184)))), ((int)(((byte)(91)))));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnUpdateFee.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnUpdateFee.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnUpdateFee.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // btnClearFee
            // 
            this.btnClearFee.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearFee.Location = new System.Drawing.Point(176, 150);
            this.btnClearFee.Name = "btnClearFee";
            this.btnClearFee.Size = new System.Drawing.Size(65, 32);
            this.btnClearFee.TabIndex = 32;
            this.btnClearFee.Text = "Clear";
            this.btnClearFee.ThemeName = "Office2013Light";
            this.btnClearFee.Click += new System.EventHandler(this.btnClearFee_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnClearFee.GetChildAt(0))).Text = "Clear";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnClearFee.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // amount
            // 
            this.amount.Controls.Add(this.txtID);
            this.amount.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amount.Location = new System.Drawing.Point(36, 83);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(92, 24);
            this.amount.TabIndex = 29;
            this.amount.Text = "Amount:    ₱";
            this.amount.ThemeName = "Office2013Light";
            // 
            // txtID
            // 
            this.txtID.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.Location = new System.Drawing.Point(93, 1);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(25, 23);
            this.txtID.TabIndex = 13;
            this.txtID.ThemeName = "Office2013Light";
            this.txtID.Visible = false;
            // 
            // nameOfFee
            // 
            this.nameOfFee.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameOfFee.Location = new System.Drawing.Point(24, 48);
            this.nameOfFee.Name = "nameOfFee";
            this.nameOfFee.Size = new System.Drawing.Size(80, 24);
            this.nameOfFee.TabIndex = 27;
            this.nameOfFee.Text = "Fee Name:";
            this.nameOfFee.ThemeName = "Office2013Light";
            // 
            // txtFeeAmount
            // 
            this.txtFeeAmount.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFeeAmount.Location = new System.Drawing.Point(130, 82);
            this.txtFeeAmount.Name = "txtFeeAmount";
            this.txtFeeAmount.Size = new System.Drawing.Size(183, 23);
            this.txtFeeAmount.TabIndex = 23;
            this.txtFeeAmount.ThemeName = "Office2013Light";
            this.txtFeeAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFeeAmount_KeyPress);
            // 
            // txtFeeName
            // 
            this.txtFeeName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFeeName.Location = new System.Drawing.Point(130, 48);
            this.txtFeeName.Name = "txtFeeName";
            this.txtFeeName.Size = new System.Drawing.Size(183, 23);
            this.txtFeeName.TabIndex = 22;
            this.txtFeeName.ThemeName = "Office2013Light";
            // 
            // btnSaveFee
            // 
            this.btnSaveFee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnSaveFee.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnSaveFee.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveFee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnSaveFee.Location = new System.Drawing.Point(247, 150);
            this.btnSaveFee.Name = "btnSaveFee";
            this.btnSaveFee.Size = new System.Drawing.Size(65, 31);
            this.btnSaveFee.TabIndex = 26;
            this.btnSaveFee.Text = "Save";
            this.btnSaveFee.ThemeName = "Office2013Light";
            this.btnSaveFee.Click += new System.EventHandler(this.btnSaveFee_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).Text = "Save";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveFee.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnSaveFee.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // txtFeeId
            // 
            this.txtFeeId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFeeId.Location = new System.Drawing.Point(131, 48);
            this.txtFeeId.Name = "txtFeeId";
            this.txtFeeId.Size = new System.Drawing.Size(18, 23);
            this.txtFeeId.TabIndex = 74;
            this.txtFeeId.ThemeName = "Office2013Light";
            // 
            // splitPanel2
            // 
            this.splitPanel2.Controls.Add(this.radSplitContainer2);
            this.splitPanel2.Controls.Add(this.dgvItems);
            this.splitPanel2.Controls.Add(this.radLabel7);
            this.splitPanel2.Controls.Add(this.txtColor);
            this.splitPanel2.Controls.Add(this.radLabel2);
            this.splitPanel2.Controls.Add(this.txtSize);
            this.splitPanel2.Controls.Add(this.radLabel1);
            this.splitPanel2.Controls.Add(this.txtItemCode);
            this.splitPanel2.Controls.Add(this.radLabel5);
            this.splitPanel2.Controls.Add(this.btnDeleteItem);
            this.splitPanel2.Controls.Add(this.radLabel4);
            this.splitPanel2.Controls.Add(this.btnSaveItem);
            this.splitPanel2.Controls.Add(this.btnUpdateItem);
            this.splitPanel2.Controls.Add(this.txtItemName);
            this.splitPanel2.Controls.Add(this.txtItemAmount);
            this.splitPanel2.Controls.Add(this.radLabel3);
            this.splitPanel2.Controls.Add(this.btnClearItem);
            this.splitPanel2.Controls.Add(this.department);
            this.splitPanel2.Controls.Add(this.txtQuantity);
            this.splitPanel2.Location = new System.Drawing.Point(0, 246);
            this.splitPanel2.Name = "splitPanel2";
            // 
            // 
            // 
            this.splitPanel2.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel2.Size = new System.Drawing.Size(1358, 451);
            this.splitPanel2.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(0F, 0.1498559F);
            this.splitPanel2.SizeInfo.SplitterCorrection = new System.Drawing.Size(0, 105);
            this.splitPanel2.TabIndex = 1;
            this.splitPanel2.TabStop = false;
            this.splitPanel2.Text = "splitPanel2";
            this.splitPanel2.ThemeName = "Office2013Light";
            // 
            // radSplitContainer2
            // 
            this.radSplitContainer2.Controls.Add(this.splitPanel3);
            this.radSplitContainer2.Dock = System.Windows.Forms.DockStyle.Right;
            this.radSplitContainer2.Location = new System.Drawing.Point(1145, 0);
            this.radSplitContainer2.Name = "radSplitContainer2";
            // 
            // 
            // 
            this.radSplitContainer2.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.radSplitContainer2.Size = new System.Drawing.Size(213, 451);
            this.radSplitContainer2.TabIndex = 0;
            this.radSplitContainer2.TabStop = false;
            this.radSplitContainer2.Text = "radSplitContainer2";
            this.radSplitContainer2.ThemeName = "TelerikMetroBlue";
            // 
            // splitPanel3
            // 
            this.splitPanel3.Controls.Add(this.btnAddQuantity);
            this.splitPanel3.Controls.Add(this.txtQuantityToAdd);
            this.splitPanel3.Controls.Add(this.radLabel13);
            this.splitPanel3.Controls.Add(this.radLabel12);
            this.splitPanel3.Controls.Add(this.radLabel9);
            this.splitPanel3.Controls.Add(this.txtItemCode2);
            this.splitPanel3.Controls.Add(this.txtItemName2);
            this.splitPanel3.Controls.Add(this.txtQuantity2);
            this.splitPanel3.Controls.Add(this.radLabel11);
            this.splitPanel3.Controls.Add(this.radLabel10);
            this.splitPanel3.Location = new System.Drawing.Point(0, 0);
            this.splitPanel3.Name = "splitPanel3";
            // 
            // 
            // 
            this.splitPanel3.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel3.Size = new System.Drawing.Size(213, 451);
            this.splitPanel3.TabIndex = 0;
            this.splitPanel3.TabStop = false;
            this.splitPanel3.Text = "splitPanel3";
            this.splitPanel3.ThemeName = "TelerikMetroBlue";
            // 
            // btnAddQuantity
            // 
            this.btnAddQuantity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnAddQuantity.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnAddQuantity.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddQuantity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnAddQuantity.Location = new System.Drawing.Point(136, 201);
            this.btnAddQuantity.Name = "btnAddQuantity";
            this.btnAddQuantity.Size = new System.Drawing.Size(65, 31);
            this.btnAddQuantity.TabIndex = 82;
            this.btnAddQuantity.Text = "Add";
            this.btnAddQuantity.ThemeName = "Office2013Light";
            this.btnAddQuantity.Click += new System.EventHandler(this.btnAddQuantity_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnAddQuantity.GetChildAt(0))).Text = "Add";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnAddQuantity.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnAddQuantity.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnAddQuantity.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // txtQuantityToAdd
            // 
            this.txtQuantityToAdd.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantityToAdd.Location = new System.Drawing.Point(98, 171);
            this.txtQuantityToAdd.Name = "txtQuantityToAdd";
            // 
            // 
            // 
            this.txtQuantityToAdd.RootElement.AutoSize = false;
            this.txtQuantityToAdd.Size = new System.Drawing.Size(103, 23);
            this.txtQuantityToAdd.TabIndex = 80;
            this.txtQuantityToAdd.ThemeName = "Office2013Light";
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantityToAdd.GetChildAt(0).GetChildAt(2))).LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantityToAdd.GetChildAt(0).GetChildAt(2))).TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantityToAdd.GetChildAt(0).GetChildAt(2))).RightColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantityToAdd.GetChildAt(0).GetChildAt(2))).BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            // 
            // radLabel13
            // 
            this.radLabel13.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel13.Location = new System.Drawing.Point(9, 171);
            this.radLabel13.Name = "radLabel13";
            this.radLabel13.Size = new System.Drawing.Size(86, 24);
            this.radLabel13.TabIndex = 81;
            this.radLabel13.Text = "Qty to Add:";
            this.radLabel13.ThemeName = "Office2013Light";
            // 
            // radLabel12
            // 
            this.radLabel12.Controls.Add(this.radTextBox2);
            this.radLabel12.Font = new System.Drawing.Font("Segoe UI", 20F);
            this.radLabel12.Location = new System.Drawing.Point(15, 18);
            this.radLabel12.Name = "radLabel12";
            this.radLabel12.Size = new System.Drawing.Size(108, 31);
            this.radLabel12.TabIndex = 79;
            this.radLabel12.Text = "Add Items";
            this.radLabel12.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadLabelElement)(this.radLabel12.GetChildAt(0))).Text = "Add Items";
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel12.GetChildAt(0).GetChildAt(2).GetChildAt(1))).TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel12.GetChildAt(0).GetChildAt(2).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            // 
            // radTextBox2
            // 
            this.radTextBox2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radTextBox2.Location = new System.Drawing.Point(115, 43);
            this.radTextBox2.Name = "radTextBox2";
            this.radTextBox2.Size = new System.Drawing.Size(30, 23);
            this.radTextBox2.TabIndex = 72;
            this.radTextBox2.ThemeName = "Office2013Light";
            // 
            // radLabel9
            // 
            this.radLabel9.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel9.Location = new System.Drawing.Point(15, 65);
            this.radLabel9.Name = "radLabel9";
            this.radLabel9.Size = new System.Drawing.Size(82, 24);
            this.radLabel9.TabIndex = 78;
            this.radLabel9.Text = "Item Code:";
            this.radLabel9.ThemeName = "Office2013Light";
            // 
            // txtItemCode2
            // 
            this.txtItemCode2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemCode2.Location = new System.Drawing.Point(98, 65);
            this.txtItemCode2.Name = "txtItemCode2";
            this.txtItemCode2.Size = new System.Drawing.Size(103, 23);
            this.txtItemCode2.TabIndex = 77;
            this.txtItemCode2.ThemeName = "Office2013Light";
            // 
            // txtItemName2
            // 
            this.txtItemName2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemName2.Location = new System.Drawing.Point(98, 100);
            this.txtItemName2.Name = "txtItemName2";
            this.txtItemName2.Size = new System.Drawing.Size(103, 23);
            this.txtItemName2.TabIndex = 73;
            this.txtItemName2.ThemeName = "Office2013Light";
            // 
            // txtQuantity2
            // 
            this.txtQuantity2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantity2.Location = new System.Drawing.Point(98, 136);
            this.txtQuantity2.Name = "txtQuantity2";
            // 
            // 
            // 
            this.txtQuantity2.RootElement.AutoSize = false;
            this.txtQuantity2.Size = new System.Drawing.Size(103, 23);
            this.txtQuantity2.TabIndex = 74;
            this.txtQuantity2.ThemeName = "Office2013Light";
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantity2.GetChildAt(0).GetChildAt(2))).LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantity2.GetChildAt(0).GetChildAt(2))).TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantity2.GetChildAt(0).GetChildAt(2))).RightColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantity2.GetChildAt(0).GetChildAt(2))).BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            // 
            // radLabel11
            // 
            this.radLabel11.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel11.Location = new System.Drawing.Point(7, 136);
            this.radLabel11.Name = "radLabel11";
            this.radLabel11.Size = new System.Drawing.Size(91, 24);
            this.radLabel11.TabIndex = 76;
            this.radLabel11.Text = "Current Qty:";
            this.radLabel11.ThemeName = "Office2013Light";
            // 
            // radLabel10
            // 
            this.radLabel10.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel10.Location = new System.Drawing.Point(10, 100);
            this.radLabel10.Name = "radLabel10";
            this.radLabel10.Size = new System.Drawing.Size(87, 24);
            this.radLabel10.TabIndex = 75;
            this.radLabel10.Text = "Item Name:";
            this.radLabel10.ThemeName = "Office2013Light";
            // 
            // dgvItems
            // 
            this.dgvItems.Location = new System.Drawing.Point(333, 0);
            // 
            // dgvItems
            // 
            this.dgvItems.MasterTemplate.AllowAddNewRow = false;
            this.dgvItems.MasterTemplate.AllowCellContextMenu = false;
            this.dgvItems.MasterTemplate.AllowColumnHeaderContextMenu = false;
            this.dgvItems.MasterTemplate.AllowColumnResize = false;
            this.dgvItems.MasterTemplate.AllowDeleteRow = false;
            this.dgvItems.MasterTemplate.AllowDragToGroup = false;
            this.dgvItems.MasterTemplate.AllowEditRow = false;
            this.dgvItems.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            this.dgvItems.MasterTemplate.EnableGrouping = false;
            this.dgvItems.Name = "dgvItems";
            this.dgvItems.Size = new System.Drawing.Size(809, 420);
            this.dgvItems.TabIndex = 77;
            this.dgvItems.Text = "radGridView1";
            this.dgvItems.ThemeName = "TelerikMetroBlue";
            this.dgvItems.CellDoubleClick += new Telerik.WinControls.UI.GridViewCellEventHandler(this.dgvItems_CellDoubleClick);
            // 
            // radLabel7
            // 
            this.radLabel7.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel7.Location = new System.Drawing.Point(53, 201);
            this.radLabel7.Name = "radLabel7";
            this.radLabel7.Size = new System.Drawing.Size(48, 24);
            this.radLabel7.TabIndex = 76;
            this.radLabel7.Text = "Color:";
            this.radLabel7.ThemeName = "Office2013Light";
            // 
            // txtColor
            // 
            this.txtColor.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtColor.Location = new System.Drawing.Point(126, 200);
            this.txtColor.Name = "txtColor";
            // 
            // 
            // 
            this.txtColor.RootElement.AutoSize = false;
            this.txtColor.Size = new System.Drawing.Size(183, 23);
            this.txtColor.TabIndex = 75;
            this.txtColor.ThemeName = "Office2013Light";
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtColor.GetChildAt(0).GetChildAt(2))).LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtColor.GetChildAt(0).GetChildAt(2))).TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtColor.GetChildAt(0).GetChildAt(2))).RightColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtColor.GetChildAt(0).GetChildAt(2))).BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            // 
            // radLabel2
            // 
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel2.Location = new System.Drawing.Point(61, 235);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(38, 24);
            this.radLabel2.TabIndex = 74;
            this.radLabel2.Text = "Size:";
            this.radLabel2.ThemeName = "Office2013Light";
            // 
            // txtSize
            // 
            this.txtSize.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem8.Text = "XXS";
            radListDataItem8.TextWrap = true;
            radListDataItem9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem9.Text = "XS";
            radListDataItem9.TextWrap = true;
            radListDataItem10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            radListDataItem10.Text = "S";
            radListDataItem10.TextWrap = true;
            radListDataItem11.Text = "M";
            radListDataItem11.TextWrap = true;
            radListDataItem12.Text = "L";
            radListDataItem12.TextWrap = true;
            radListDataItem13.Text = "XL";
            radListDataItem13.TextWrap = true;
            radListDataItem14.Text = "XXL";
            radListDataItem14.TextWrap = true;
            this.txtSize.Items.Add(radListDataItem8);
            this.txtSize.Items.Add(radListDataItem9);
            this.txtSize.Items.Add(radListDataItem10);
            this.txtSize.Items.Add(radListDataItem11);
            this.txtSize.Items.Add(radListDataItem12);
            this.txtSize.Items.Add(radListDataItem13);
            this.txtSize.Items.Add(radListDataItem14);
            this.txtSize.Location = new System.Drawing.Point(126, 235);
            this.txtSize.Name = "txtSize";
            this.txtSize.Size = new System.Drawing.Size(183, 23);
            this.txtSize.TabIndex = 73;
            this.txtSize.ThemeName = "Office2013Light";
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.Location = new System.Drawing.Point(23, 61);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(82, 24);
            this.radLabel1.TabIndex = 72;
            this.radLabel1.Text = "Item Code:";
            this.radLabel1.ThemeName = "Office2013Light";
            // 
            // txtItemCode
            // 
            this.txtItemCode.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemCode.Location = new System.Drawing.Point(129, 61);
            this.txtItemCode.Name = "txtItemCode";
            this.txtItemCode.Size = new System.Drawing.Size(183, 23);
            this.txtItemCode.TabIndex = 71;
            this.txtItemCode.ThemeName = "Office2013Light";
            // 
            // radLabel5
            // 
            this.radLabel5.Controls.Add(this.txtItemId);
            this.radLabel5.Font = new System.Drawing.Font("Segoe UI", 20F);
            this.radLabel5.Location = new System.Drawing.Point(14, 18);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(158, 31);
            this.radLabel5.TabIndex = 70;
            this.radLabel5.Text = "Add New Items";
            this.radLabel5.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadLabelElement)(this.radLabel5.GetChildAt(0))).Text = "Add New Items";
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel5.GetChildAt(0).GetChildAt(2).GetChildAt(1))).TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel5.GetChildAt(0).GetChildAt(2).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            // 
            // txtItemId
            // 
            this.txtItemId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemId.Location = new System.Drawing.Point(115, 43);
            this.txtItemId.Name = "txtItemId";
            this.txtItemId.Size = new System.Drawing.Size(30, 23);
            this.txtItemId.TabIndex = 72;
            this.txtItemId.ThemeName = "Office2013Light";
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnDeleteItem.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnDeleteItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnDeleteItem.Location = new System.Drawing.Point(173, 305);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(65, 31);
            this.btnDeleteItem.TabIndex = 52;
            this.btnDeleteItem.Text = "Delete";
            this.btnDeleteItem.ThemeName = "Office2013Light";
            this.btnDeleteItem.Click += new System.EventHandler(this.btnDeleteItem_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnDeleteItem.GetChildAt(0))).Text = "Delete";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnDeleteItem.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnDeleteItem.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(82)))), ((int)(((byte)(78)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnDeleteItem.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // radLabel4
            // 
            this.radLabel4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel4.Location = new System.Drawing.Point(18, 96);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(87, 24);
            this.radLabel4.TabIndex = 43;
            this.radLabel4.Text = "Item Name:";
            this.radLabel4.ThemeName = "Office2013Light";
            // 
            // btnSaveItem
            // 
            this.btnSaveItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnSaveItem.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnSaveItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnSaveItem.Location = new System.Drawing.Point(244, 266);
            this.btnSaveItem.Name = "btnSaveItem";
            this.btnSaveItem.Size = new System.Drawing.Size(65, 31);
            this.btnSaveItem.TabIndex = 42;
            this.btnSaveItem.Text = "Save";
            this.btnSaveItem.ThemeName = "Office2013Light";
            this.btnSaveItem.Click += new System.EventHandler(this.btnSaveItem_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveItem.GetChildAt(0))).Text = "Save";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveItem.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnSaveItem.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnSaveItem.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // btnUpdateItem
            // 
            this.btnUpdateItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(182)))), ((int)(((byte)(251)))));
            this.btnUpdateItem.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btnUpdateItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btnUpdateItem.Location = new System.Drawing.Point(244, 305);
            this.btnUpdateItem.Name = "btnUpdateItem";
            this.btnUpdateItem.Size = new System.Drawing.Size(65, 31);
            this.btnUpdateItem.TabIndex = 53;
            this.btnUpdateItem.Text = "Update";
            this.btnUpdateItem.ThemeName = "Office2013Light";
            this.btnUpdateItem.Click += new System.EventHandler(this.btnUpdateItem_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnUpdateItem.GetChildAt(0))).Text = "Update";
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnUpdateItem.GetChildAt(0))).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnUpdateItem.GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateItem.GetChildAt(0).GetChildAt(0))).BackColor2 = System.Drawing.SystemColors.Control;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateItem.GetChildAt(0).GetChildAt(0))).BackColor3 = System.Drawing.SystemColors.ControlDark;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateItem.GetChildAt(0).GetChildAt(0))).BackColor4 = System.Drawing.SystemColors.ControlLightLight;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateItem.GetChildAt(0).GetChildAt(0))).GradientStyle = Telerik.WinControls.GradientStyles.Solid;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateItem.GetChildAt(0).GetChildAt(0))).GradientAngle = 90F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateItem.GetChildAt(0).GetChildAt(0))).GradientPercentage = 0.5F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateItem.GetChildAt(0).GetChildAt(0))).GradientPercentage2 = 0.666F;
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnUpdateItem.GetChildAt(0).GetChildAt(0))).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(184)))), ((int)(((byte)(91)))));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnUpdateItem.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.btnUpdateItem.GetChildAt(0).GetChildAt(1).GetChildAt(1))).Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.btnUpdateItem.GetChildAt(0).GetChildAt(2))).AngleTransform = 0F;
            // 
            // txtItemName
            // 
            this.txtItemName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemName.Location = new System.Drawing.Point(129, 96);
            this.txtItemName.Name = "txtItemName";
            this.txtItemName.Size = new System.Drawing.Size(183, 23);
            this.txtItemName.TabIndex = 38;
            this.txtItemName.ThemeName = "Office2013Light";
            // 
            // txtItemAmount
            // 
            this.txtItemAmount.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemAmount.Location = new System.Drawing.Point(128, 131);
            this.txtItemAmount.Name = "txtItemAmount";
            this.txtItemAmount.Size = new System.Drawing.Size(183, 23);
            this.txtItemAmount.TabIndex = 39;
            this.txtItemAmount.ThemeName = "Office2013Light";
            // 
            // radLabel3
            // 
            this.radLabel3.Controls.Add(this.radTextBox1);
            this.radLabel3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel3.Location = new System.Drawing.Point(36, 131);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(92, 24);
            this.radLabel3.TabIndex = 45;
            this.radLabel3.Text = "Amount:    ₱";
            this.radLabel3.ThemeName = "Office2013Light";
            // 
            // radTextBox1
            // 
            this.radTextBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radTextBox1.Location = new System.Drawing.Point(93, 1);
            this.radTextBox1.Name = "radTextBox1";
            this.radTextBox1.Size = new System.Drawing.Size(25, 23);
            this.radTextBox1.TabIndex = 13;
            this.radTextBox1.ThemeName = "Office2013Light";
            this.radTextBox1.Visible = false;
            // 
            // btnClearItem
            // 
            this.btnClearItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearItem.Location = new System.Drawing.Point(173, 266);
            this.btnClearItem.Name = "btnClearItem";
            this.btnClearItem.Size = new System.Drawing.Size(65, 32);
            this.btnClearItem.TabIndex = 48;
            this.btnClearItem.Text = "Clear";
            this.btnClearItem.ThemeName = "Office2013Light";
            this.btnClearItem.Click += new System.EventHandler(this.btnClearItem_Click);
            ((Telerik.WinControls.UI.RadButtonElement)(this.btnClearItem.GetChildAt(0))).Text = "Clear";
            ((Telerik.WinControls.Primitives.FillPrimitive)(this.btnClearItem.GetChildAt(0).GetChildAt(0))).Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // department
            // 
            this.department.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.department.Location = new System.Drawing.Point(32, 165);
            this.department.Name = "department";
            this.department.Size = new System.Drawing.Size(70, 24);
            this.department.TabIndex = 44;
            this.department.Text = "Quantity:";
            this.department.ThemeName = "Office2013Light";
            // 
            // txtQuantity
            // 
            this.txtQuantity.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantity.Location = new System.Drawing.Point(127, 165);
            this.txtQuantity.Name = "txtQuantity";
            // 
            // 
            // 
            this.txtQuantity.RootElement.AutoSize = false;
            this.txtQuantity.Size = new System.Drawing.Size(183, 23);
            this.txtQuantity.TabIndex = 41;
            this.txtQuantity.ThemeName = "Office2013Light";
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantity.GetChildAt(0).GetChildAt(2))).LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantity.GetChildAt(0).GetChildAt(2))).TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantity.GetChildAt(0).GetChildAt(2))).RightColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            ((Telerik.WinControls.Primitives.BorderPrimitive)(this.txtQuantity.GetChildAt(0).GetChildAt(2))).BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
         
            // 
            // AddPaymentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 697);
            this.Controls.Add(this.radSplitContainer1);
            this.Name = "AddPaymentForm";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "Payments";
            this.ThemeName = "Office2013Light";
            this.Load += new System.EventHandler(this.Payments_Load);
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer1)).EndInit();
            this.radSplitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel1)).EndInit();
            this.splitPanel1.ResumeLayout(false);
            this.splitPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtAssignTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFees.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFees)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDeleteFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnUpdateFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClearFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.amount)).EndInit();
            this.amount.ResumeLayout(false);
            this.amount.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameOfFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFeeAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFeeName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveFee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFeeId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel2)).EndInit();
            this.splitPanel2.ResumeLayout(false);
            this.splitPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer2)).EndInit();
            this.radSplitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel3)).EndInit();
            this.splitPanel3.ResumeLayout(false);
            this.splitPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuantityToAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).EndInit();
            this.radLabel12.ResumeLayout(false);
            this.radLabel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemCode2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemName2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuantity2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            this.radLabel5.ResumeLayout(false);
            this.radLabel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDeleteItem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveItem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnUpdateItem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            this.radLabel3.ResumeLayout(false);
            this.radLabel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClearItem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.department)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadSplitContainer radSplitContainer1;
        private Telerik.WinControls.UI.SplitPanel splitPanel1;
        private Telerik.WinControls.UI.SplitPanel splitPanel2;
        private Telerik.WinControls.UI.RadButton btnDeleteFee;
        private Telerik.WinControls.UI.RadButton btnUpdateFee;
        private Telerik.WinControls.UI.RadButton btnClearFee;
        private Telerik.WinControls.UI.RadLabel amount;
        public Telerik.WinControls.UI.RadTextBox txtID;
        private Telerik.WinControls.UI.RadLabel nameOfFee;
        private Telerik.WinControls.UI.RadTextBox txtFeeAmount;
        private Telerik.WinControls.UI.RadTextBox txtFeeName;
        private Telerik.WinControls.UI.RadButton btnSaveFee;
        private Telerik.WinControls.UI.RadButton btnDeleteItem;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadButton btnSaveItem;
        private Telerik.WinControls.UI.RadButton btnUpdateItem;
        private Telerik.WinControls.UI.RadTextBox txtItemName;
        private Telerik.WinControls.UI.RadTextBox txtItemAmount;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        public Telerik.WinControls.UI.RadTextBox radTextBox1;
        private Telerik.WinControls.UI.RadButton btnClearItem;
        private Telerik.WinControls.UI.RadLabel department;
        private Telerik.WinControls.UI.RadTextBox txtQuantity;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadTextBox txtItemCode;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadTextBox txtColor;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadDropDownList txtSize;
        private Telerik.WinControls.Themes.Office2013LightTheme office2013LightTheme1;
        private Telerik.WinControls.Themes.TelerikMetroBlueTheme telerikMetroBlueTheme1;
        private Telerik.WinControls.UI.RadGridView dgvItems;
        private Telerik.WinControls.UI.RadGridView dgvFees;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        private Telerik.WinControls.UI.RadTextBox txtAssignTo;
        private Telerik.WinControls.UI.RadTextBox txtFeeId;
        private Telerik.WinControls.UI.RadTextBox txtItemId;
        private Telerik.WinControls.UI.RadSplitContainer radSplitContainer2;
        private Telerik.WinControls.UI.RadTextBox txtItemCode2;
        private Telerik.WinControls.UI.SplitPanel splitPanel3;
        private Telerik.WinControls.UI.RadLabel radLabel9;
        private Telerik.WinControls.UI.RadTextBox txtItemName2;
        private Telerik.WinControls.UI.RadTextBox txtQuantity2;
        private Telerik.WinControls.UI.RadLabel radLabel11;
        private Telerik.WinControls.UI.RadLabel radLabel10;
        private Telerik.WinControls.UI.RadTextBox radTextBox2;
        private Telerik.WinControls.UI.RadButton btnAddQuantity;
        private Telerik.WinControls.UI.RadTextBox txtQuantityToAdd;
        private Telerik.WinControls.UI.RadLabel radLabel13;
        private Telerik.WinControls.UI.RadLabel radLabel12;
    }
}
