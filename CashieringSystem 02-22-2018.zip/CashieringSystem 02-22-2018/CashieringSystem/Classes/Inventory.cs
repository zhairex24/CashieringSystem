﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using CashieringSystem.Properties;
using System.Data;
using System.Windows.Forms;
using Telerik.WinControls.UI;

namespace CashieringSystem.Classes
{
    class Inventory
    {
        public const string saveFee = "Successfully Added!";
        public const string updatedFee = "Successfully Updated!";
        public const string deletedFee = "Successfully Deleted!";
        public const string authenticator = "Saving Fee!";
        public const string confirmation = "Transactions cannot be reverted. Do you want to proceed?";
        private string conString = Settings.Default.constring;
        
        private MySqlConnection conn;
     
        public void AddItems(string code, string name, decimal amount, int quantity, string color, string size)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("AddItems", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_ItemCode", code);
            cmd.Parameters.AddWithValue("_ItemName", name);
            cmd.Parameters.AddWithValue("_ItemAmount", amount);
            cmd.Parameters.AddWithValue("_Quantity", quantity);
            cmd.Parameters.AddWithValue("_Color", color);
            cmd.Parameters.AddWithValue("_Size", size);

            cmd.ExecuteNonQuery();
            MessageBox.Show(saveFee, authenticator, MessageBoxButtons.OK, MessageBoxIcon.Information);
            conn.Dispose();
        }

        public void UpdateItem(string code, string name, decimal amount, string color, string size, int id)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("UpdateItem", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_ItemId", id);
            cmd.Parameters.AddWithValue("_ItemCode", code);
            cmd.Parameters.AddWithValue("_ItemName", name);
            cmd.Parameters.AddWithValue("_ItemAmount", amount);
            cmd.Parameters.AddWithValue("_Color", color);
            cmd.Parameters.AddWithValue("_Size", size);

            cmd.ExecuteNonQuery();
            MessageBox.Show(updatedFee, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            conn.Dispose();
        }

        public void DeleteItem(int id)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("DeleteItemByID", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_ItemId", id);
            cmd.ExecuteNonQuery();
            MessageBox.Show(deletedFee, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void AddQuantity(string code, int item_id, int quantity, int quantity2)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("AddQuantity", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_ItemCode", code);
            cmd.Parameters.AddWithValue("_ItemId", item_id);
            cmd.Parameters.AddWithValue("_Quantity", quantity);
            cmd.Parameters.AddWithValue("_Quantity2", quantity2);

            cmd.ExecuteNonQuery();
            MessageBox.Show(saveFee, authenticator, MessageBoxButtons.OK, MessageBoxIcon.Information);
            conn.Dispose();
        }

        public DataTable ViewAllItems()
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlDataAdapter mysqlDa = new MySqlDataAdapter("GetAllItems", conn);
            mysqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataTable dtblFee = new DataTable();
            mysqlDa.Fill(dtblFee);
            conn.Dispose();
            return dtblFee;
        }

        public DataTable GetAllItems()
        {

            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetAllItems", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            conn.Dispose();
            return dt;
        }  

        public DataTable GetAllItemHistory()
        {

            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetItemHistory", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            conn.Dispose();
            return dt;
        }


        public DataTable GetAllItemHistoryByItemCode(string item_code)
        {
            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetAllItemHistoryByItemCode", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("_ItemCode", item_code);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            conn.Dispose();
            return dt;
        }

        public DataTable GetItemCode()
        {

            conn = new MySqlConnection(conString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("GetItemCode", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            conn.Dispose();
            return dt;
        }

    }
}
