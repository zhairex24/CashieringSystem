﻿namespace CashieringSystem
{
    partial class InventoryWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.RadListDataItem radListDataItem1 = new Telerik.WinControls.UI.RadListDataItem();
            this.office2013LightTheme1 = new Telerik.WinControls.Themes.Office2013LightTheme();
            this.telerikMetroBlueTheme1 = new Telerik.WinControls.Themes.TelerikMetroBlueTheme();
            this.radPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.txtItemCodeList = new Telerik.WinControls.UI.RadDropDownList();
            this.dgvInventoryHistory = new Telerik.WinControls.UI.RadGridView();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.txtItemId = new Telerik.WinControls.UI.RadTextBox();
            this.eadd = new Telerik.WinControls.UI.RadLabel();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).BeginInit();
            this.radPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemCodeList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventoryHistory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventoryHistory.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            this.radLabel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eadd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radPanel1
            // 
            this.radPanel1.Controls.Add(this.eadd);
            this.radPanel1.Controls.Add(this.txtItemCodeList);
            this.radPanel1.Controls.Add(this.dgvInventoryHistory);
            this.radPanel1.Controls.Add(this.radLabel5);
            this.radPanel1.Location = new System.Drawing.Point(132, 5);
            this.radPanel1.Name = "radPanel1";
            this.radPanel1.Size = new System.Drawing.Size(1078, 691);
            this.radPanel1.TabIndex = 0;
            this.radPanel1.ThemeName = "Office2013Light";
            // 
            // txtItemCodeList
            // 
            radListDataItem1.Text = "-----";
            radListDataItem1.TextWrap = true;
            this.txtItemCodeList.Items.Add(radListDataItem1);
            this.txtItemCodeList.Location = new System.Drawing.Point(809, 20);
            this.txtItemCodeList.Name = "txtItemCodeList";
            this.txtItemCodeList.Size = new System.Drawing.Size(155, 21);
            this.txtItemCodeList.TabIndex = 74;
            this.txtItemCodeList.ThemeName = "Office2013Light";
            this.txtItemCodeList.SelectedValueChanged += new System.EventHandler(this.txtItemCodeList_SelectedValueChanged);
            // 
            // dgvInventoryHistory
            // 
            this.dgvInventoryHistory.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvInventoryHistory.Location = new System.Drawing.Point(0, 54);
            // 
            // dgvInventoryHistory
            // 
            this.dgvInventoryHistory.MasterTemplate.AllowAddNewRow = false;
            this.dgvInventoryHistory.MasterTemplate.AllowColumnChooser = false;
            this.dgvInventoryHistory.MasterTemplate.AllowColumnResize = false;
            this.dgvInventoryHistory.MasterTemplate.AllowDeleteRow = false;
            this.dgvInventoryHistory.MasterTemplate.AllowDragToGroup = false;
            this.dgvInventoryHistory.MasterTemplate.AllowEditRow = false;
            this.dgvInventoryHistory.MasterTemplate.AllowRowResize = false;
            this.dgvInventoryHistory.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            this.dgvInventoryHistory.MasterTemplate.EnableGrouping = false;
            this.dgvInventoryHistory.Name = "dgvInventoryHistory";
            this.dgvInventoryHistory.Size = new System.Drawing.Size(1078, 637);
            this.dgvInventoryHistory.TabIndex = 73;
            this.dgvInventoryHistory.Text = "radGridView1";
            this.dgvInventoryHistory.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel5
            // 
            this.radLabel5.Controls.Add(this.txtItemId);
            this.radLabel5.Font = new System.Drawing.Font("Segoe UI", 20F);
            this.radLabel5.Location = new System.Drawing.Point(11, 17);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(179, 31);
            this.radLabel5.TabIndex = 72;
            this.radLabel5.Text = "Inventory History";
            this.radLabel5.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadLabelElement)(this.radLabel5.GetChildAt(0))).Text = "Inventory History";
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel5.GetChildAt(0).GetChildAt(2).GetChildAt(1))).TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            ((Telerik.WinControls.Primitives.TextPrimitive)(this.radLabel5.GetChildAt(0).GetChildAt(2).GetChildAt(1))).Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            // 
            // txtItemId
            // 
            this.txtItemId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemId.Location = new System.Drawing.Point(115, 43);
            this.txtItemId.Name = "txtItemId";
            this.txtItemId.Size = new System.Drawing.Size(30, 23);
            this.txtItemId.TabIndex = 72;
            this.txtItemId.ThemeName = "Office2013Light";
            // 
            // eadd
            // 
            this.eadd.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eadd.Location = new System.Drawing.Point(721, 20);
            this.eadd.Name = "eadd";
            this.eadd.Size = new System.Drawing.Size(82, 24);
            this.eadd.TabIndex = 75;
            this.eadd.Text = "Item Code:";
            this.eadd.ThemeName = "Office2013Light";
            // 
            // Inventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 697);
            this.Controls.Add(this.radPanel1);
            this.Name = "Inventory";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "Inventory";
            this.ThemeName = "Office2013Light";
            this.Load += new System.EventHandler(this.Inventory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).EndInit();
            this.radPanel1.ResumeLayout(false);
            this.radPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemCodeList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventoryHistory.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventoryHistory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            this.radLabel5.ResumeLayout(false);
            this.radLabel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtItemId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eadd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.Themes.Office2013LightTheme office2013LightTheme1;
        private Telerik.WinControls.Themes.TelerikMetroBlueTheme telerikMetroBlueTheme1;
        private Telerik.WinControls.UI.RadPanel radPanel1;
        private Telerik.WinControls.UI.RadGridView dgvInventoryHistory;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadTextBox txtItemId;
        private Telerik.WinControls.UI.RadDropDownList txtItemCodeList;
        private Telerik.WinControls.UI.RadLabel eadd;
    }
}
