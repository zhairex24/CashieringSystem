﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class CashieringDashboard : Telerik.WinControls.UI.RadForm
    {
        public CashieringDashboard()
        {
            InitializeComponent();
        }

        private EmployeeForm ef;
        private StudentForm sf;
        private Search s;
        private AssignFeeForm aff;
        private AddPaymentForm apf;
        private InventoryWindow i;

        private void subMenuEmployee_Click(object sender, EventArgs e)
        {
            if (ef != null)
            {
                ef.WindowState = FormWindowState.Normal;
                ef.Focus();
            }
            else
            {
                ef = new EmployeeForm();
                ef.MdiParent = this;
                ef.FormClosed += (o, ea) => ef = null;
                ef.Show();
            }
        }

        private void subMenuStudent_Click(object sender, EventArgs e)
        {
            if (sf != null)
            {
                sf.WindowState = FormWindowState.Normal;
                sf.Focus();
            }
            else
            {
                sf = new StudentForm();
                sf.MdiParent = this;
                sf.FormClosed += (o, ea) => sf = null;
                sf.Show();
            }
        }

        private void CashieringDashboard_Load(object sender, EventArgs e)
        {

            nameL.Text = ServerConnection.fname + " " + ServerConnection.lname;
            positionL.Text = ServerConnection.userType;
            userIdTxt.Text = ServerConnection.user_id;
            
        }


        private void subMenuAssignFees_Click(object sender, EventArgs e)
        {
            if (aff != null)
            {
                aff.WindowState = FormWindowState.Normal;
                aff.Focus();
            }
            else
            {
                aff = new AssignFeeForm();
                aff.MdiParent = this;
                aff.FormClosed += (o, ea) => aff = null;
                aff.Show();
            }
        }

        private void subMenuAddFeesItems_Click(object sender, EventArgs e)
        {
            if (apf != null)
            {
                apf.WindowState = FormWindowState.Normal;
                apf.Focus();
            }
            else
            {
                apf = new AddPaymentForm();
                apf.MdiParent = this;
                apf.FormClosed += (o, ea) => apf = null;
                apf.Show();
            }
        }

        private void search_Click(object sender, EventArgs e)
        {
            if (s != null)
            {
                s.WindowState = FormWindowState.Normal;
                s.Focus();
            }
            else
            {
                s = new Search();
                s.MdiParent = this;
                s.FormClosed += (o, ea) => s = null;
                s.Show();
            }
        }

        private void subMenuInventory_Click(object sender, EventArgs e)
        {
            if (i != null)
            {
                i.WindowState = FormWindowState.Normal;
                i.Focus();
            }
            else
            {
                i = new InventoryWindow();
                i.MdiParent = this;
                i.FormClosed += (o, ea) => i = null;
                i.Show();
            }
        }

    }

}
