﻿namespace CashieringSystem
{
    partial class CashieringDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.register = new Telerik.WinControls.UI.RadMenuItem();
            this.subMenuStudent = new Telerik.WinControls.UI.RadMenuItem();
            this.subMenuEmployee = new Telerik.WinControls.UI.RadMenuItem();
            this.search = new Telerik.WinControls.UI.RadMenuItem();
            this.fees = new Telerik.WinControls.UI.RadMenuItem();
            this.subMenuAddFeesItems = new Telerik.WinControls.UI.RadMenuItem();
            this.subMenuAssignFees = new Telerik.WinControls.UI.RadMenuItem();
            this.office2013LightTheme1 = new Telerik.WinControls.Themes.Office2013LightTheme();
            this.radStatusStrip1 = new Telerik.WinControls.UI.RadStatusStrip();
            this.userIdTxt = new Telerik.WinControls.UI.RadTextBox();
            this.userTxt = new System.Windows.Forms.Label();
            this.radLabelElement1 = new Telerik.WinControls.UI.RadLabelElement();
            this.nameL = new Telerik.WinControls.UI.RadLabelElement();
            this.radLabelElement3 = new Telerik.WinControls.UI.RadLabelElement();
            this.positionL = new Telerik.WinControls.UI.RadLabelElement();
            this.radDock1 = new Telerik.WinControls.UI.Docking.RadDock();
            this.documentContainer1 = new Telerik.WinControls.UI.Docking.DocumentContainer();
            this.radMenu1 = new Telerik.WinControls.UI.RadMenu();
            this.report = new Telerik.WinControls.UI.RadMenuItem();
            this.subMenuInventory = new Telerik.WinControls.UI.RadMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.radStatusStrip1)).BeginInit();
            this.radStatusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userIdTxt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDock1)).BeginInit();
            this.radDock1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.documentContainer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // register
            // 
            this.register.AccessibleDescription = "Register";
            this.register.AccessibleName = "Register";
            this.register.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register.Items.AddRange(new Telerik.WinControls.RadItem[] {
            this.subMenuStudent,
            this.subMenuEmployee});
            this.register.Name = "register";
            this.register.Text = "Register";
            this.register.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // subMenuStudent
            // 
            this.subMenuStudent.AccessibleDescription = "subMenuStudent";
            this.subMenuStudent.AccessibleName = "subMenuStudent";
            this.subMenuStudent.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.subMenuStudent.Name = "subMenuStudent";
            this.subMenuStudent.Text = "Student";
            this.subMenuStudent.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            this.subMenuStudent.Click += new System.EventHandler(this.subMenuStudent_Click);
            // 
            // subMenuEmployee
            // 
            this.subMenuEmployee.AccessibleDescription = "subMenuEmployee";
            this.subMenuEmployee.AccessibleName = "subMenuEmployee";
            this.subMenuEmployee.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.subMenuEmployee.Name = "subMenuEmployee";
            this.subMenuEmployee.Text = "Employee";
            this.subMenuEmployee.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            this.subMenuEmployee.Click += new System.EventHandler(this.subMenuEmployee_Click);
            // 
            // search
            // 
            this.search.AccessibleDescription = "Search";
            this.search.AccessibleName = "Search";
            this.search.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search.Name = "search";
            this.search.Text = "Search";
            this.search.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // fees
            // 
            this.fees.AccessibleDescription = "Fees";
            this.fees.AccessibleName = "Fees";
            this.fees.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fees.Items.AddRange(new Telerik.WinControls.RadItem[] {
            this.subMenuAddFeesItems,
            this.subMenuAssignFees});
            this.fees.Name = "fees";
            this.fees.Text = "Payments";
            this.fees.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // subMenuAddFeesItems
            // 
            this.subMenuAddFeesItems.AccessibleDescription = "Add Fees";
            this.subMenuAddFeesItems.AccessibleName = "Add Fees";
            this.subMenuAddFeesItems.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.subMenuAddFeesItems.Name = "subMenuAddFeesItems";
            this.subMenuAddFeesItems.Text = "Add Fees/Items";
            this.subMenuAddFeesItems.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            this.subMenuAddFeesItems.Click += new System.EventHandler(this.subMenuAddFeesItems_Click);
            // 
            // subMenuAssignFees
            // 
            this.subMenuAssignFees.AccessibleDescription = "Assign Mis";
            this.subMenuAssignFees.AccessibleName = "Assign Mis";
            this.subMenuAssignFees.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.subMenuAssignFees.Name = "subMenuAssignFees";
            this.subMenuAssignFees.Text = "Assign Fees";
            this.subMenuAssignFees.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            this.subMenuAssignFees.Click += new System.EventHandler(this.subMenuAssignFees_Click);
            // 
            // radStatusStrip1
            // 
            this.radStatusStrip1.Controls.Add(this.userIdTxt);
            this.radStatusStrip1.Controls.Add(this.userTxt);
            this.radStatusStrip1.Items.AddRange(new Telerik.WinControls.RadItem[] {
            this.radLabelElement1,
            this.nameL,
            this.radLabelElement3,
            this.positionL});
            this.radStatusStrip1.Location = new System.Drawing.Point(0, 665);
            this.radStatusStrip1.Name = "radStatusStrip1";
            this.radStatusStrip1.Size = new System.Drawing.Size(1358, 32);
            this.radStatusStrip1.TabIndex = 2;
            this.radStatusStrip1.Text = "radStatusStrip1";
            this.radStatusStrip1.ThemeName = "Office2013Light";
            // 
            // userIdTxt
            // 
            this.userIdTxt.Location = new System.Drawing.Point(458, 7);
            this.userIdTxt.Name = "userIdTxt";
            this.userIdTxt.Size = new System.Drawing.Size(100, 20);
            this.userIdTxt.TabIndex = 1;
            this.userIdTxt.Visible = false;
            // 
            // userTxt
            // 
            this.userTxt.AutoSize = true;
            this.userTxt.Location = new System.Drawing.Point(74, 3);
            this.userTxt.Name = "userTxt";
            this.userTxt.Size = new System.Drawing.Size(0, 15);
            this.userTxt.TabIndex = 0;
            // 
            // radLabelElement1
            // 
            this.radLabelElement1.AccessibleDescription = "Name:";
            this.radLabelElement1.AccessibleName = "Name:";
            this.radLabelElement1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabelElement1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(198)))), ((int)(((byte)(72)))));
            this.radLabelElement1.Name = "radLabelElement1";
            this.radStatusStrip1.SetSpring(this.radLabelElement1, false);
            this.radLabelElement1.Text = "Name:";
            this.radLabelElement1.TextWrap = true;
            this.radLabelElement1.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // nameL
            // 
            this.nameL.AccessibleDescription = "radLabelElement2";
            this.nameL.AccessibleName = "radLabelElement2";
            this.nameL.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameL.Name = "nameL";
            this.radStatusStrip1.SetSpring(this.nameL, false);
            this.nameL.Text = "radLabelElement2";
            this.nameL.TextWrap = true;
            this.nameL.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // radLabelElement3
            // 
            this.radLabelElement3.AccessibleDescription = "Position:";
            this.radLabelElement3.AccessibleName = "Position:";
            this.radLabelElement3.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabelElement3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(198)))), ((int)(((byte)(72)))));
            this.radLabelElement3.Name = "radLabelElement3";
            this.radStatusStrip1.SetSpring(this.radLabelElement3, false);
            this.radLabelElement3.Text = "Position:";
            this.radLabelElement3.TextWrap = true;
            this.radLabelElement3.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // positionL
            // 
            this.positionL.AccessibleDescription = "radLabelElement4";
            this.positionL.AccessibleName = "radLabelElement4";
            this.positionL.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.positionL.Name = "positionL";
            this.radStatusStrip1.SetSpring(this.positionL, false);
            this.positionL.Text = "radLabelElement4";
            this.positionL.TextWrap = true;
            this.positionL.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // radDock1
            // 
            this.radDock1.AutoDetectMdiChildren = true;
            this.radDock1.Controls.Add(this.documentContainer1);
            this.radDock1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radDock1.IsCleanUpTarget = true;
            this.radDock1.Location = new System.Drawing.Point(0, 27);
            this.radDock1.MainDocumentContainer = this.documentContainer1;
            this.radDock1.Name = "radDock1";
            this.radDock1.Padding = new System.Windows.Forms.Padding(0);
            // 
            // 
            // 
            this.radDock1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.radDock1.Size = new System.Drawing.Size(1358, 638);
            this.radDock1.SplitterWidth = 3;
            this.radDock1.TabIndex = 3;
            this.radDock1.TabStop = false;
            this.radDock1.Text = "radDock1";
            this.radDock1.ThemeName = "Office2013Light";
            // 
            // documentContainer1
            // 
            this.documentContainer1.Name = "documentContainer1";
            // 
            // 
            // 
            this.documentContainer1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.documentContainer1.SizeInfo.SizeMode = Telerik.WinControls.UI.Docking.SplitPanelSizeMode.Fill;
            this.documentContainer1.SplitterWidth = 3;
            this.documentContainer1.ThemeName = "Office2013Light";
            // 
            // radMenu1
            // 
            this.radMenu1.Items.AddRange(new Telerik.WinControls.RadItem[] {
            this.register,
            this.fees,
            this.search,
            this.report});
            this.radMenu1.Location = new System.Drawing.Point(0, 0);
            this.radMenu1.Name = "radMenu1";
            this.radMenu1.Padding = new System.Windows.Forms.Padding(2, 2, 0, 0);
            this.radMenu1.Size = new System.Drawing.Size(1358, 27);
            this.radMenu1.TabIndex = 0;
            this.radMenu1.Text = "radMenu1";
            this.radMenu1.ThemeName = "ControlDefault";
            // 
            // report
            // 
            this.report.AccessibleDescription = "Report";
            this.report.AccessibleName = "Report";
            this.report.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.report.Items.AddRange(new Telerik.WinControls.RadItem[] {
            this.subMenuInventory});
            this.report.Name = "report";
            this.report.Text = "Report";
            this.report.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            // 
            // subMenuInventory
            // 
            this.subMenuInventory.AccessibleDescription = "Inventory";
            this.subMenuInventory.AccessibleName = "Inventory";
            this.subMenuInventory.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.subMenuInventory.Name = "subMenuInventory";
            this.subMenuInventory.Text = "Inventory";
            this.subMenuInventory.Visibility = Telerik.WinControls.ElementVisibility.Visible;
            this.subMenuInventory.Click += new System.EventHandler(this.subMenuInventory_Click);
            // 
            // CashieringDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 697);
            this.Controls.Add(this.radDock1);
            this.Controls.Add(this.radStatusStrip1);
            this.Controls.Add(this.radMenu1);
            this.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.IsMdiContainer = true;
            this.Name = "CashieringDashboard";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cashiering Dashboard";
            this.ThemeName = "Office2013Light";
            this.TransparencyKey = System.Drawing.Color.White;
            this.Load += new System.EventHandler(this.CashieringDashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.radStatusStrip1)).EndInit();
            this.radStatusStrip1.ResumeLayout(false);
            this.radStatusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userIdTxt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDock1)).EndInit();
            this.radDock1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.documentContainer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadMenuItem register;
        private Telerik.WinControls.UI.RadMenuItem subMenuStudent;
        private Telerik.WinControls.UI.RadMenuItem subMenuEmployee;
        private Telerik.WinControls.UI.RadMenuItem fees;
        private Telerik.WinControls.UI.RadMenuItem search;
        private Telerik.WinControls.Themes.Office2013LightTheme office2013LightTheme1;
        private Telerik.WinControls.UI.RadStatusStrip radStatusStrip1;
        private Telerik.WinControls.UI.Docking.RadDock radDock1;
        private Telerik.WinControls.UI.Docking.DocumentContainer documentContainer1;
        private System.Windows.Forms.Label userTxt;
        private Telerik.WinControls.UI.RadLabelElement radLabelElement1;
        private Telerik.WinControls.UI.RadLabelElement nameL;
        private Telerik.WinControls.UI.RadLabelElement radLabelElement3;
        private Telerik.WinControls.UI.RadLabelElement positionL;
        private Telerik.WinControls.UI.RadMenu radMenu1;
        public Telerik.WinControls.UI.RadTextBox userIdTxt;
        private Telerik.WinControls.UI.RadMenuItem subMenuAddFeesItems;
        private Telerik.WinControls.UI.RadMenuItem subMenuAssignFees;
        private Telerik.WinControls.UI.RadMenuItem report;
        private Telerik.WinControls.UI.RadMenuItem subMenuInventory;
    }
}
