﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class ConnectToServer : Telerik.WinControls.UI.RadForm
    {
        
        public ConnectToServer()
        {
            InitializeComponent();
        }
        ServerConnection serCon = new ServerConnection();


        private void btnSave_Click(object sender, EventArgs e)
        {
            serCon.SaveConnectionString(server_nameTxt.Text, database_nameTxt.Text, user_idTxt.Text, passwordTxt.Text);
            serCon.ClearFields(server_nameTxt, database_nameTxt, user_idTxt, passwordTxt);
            Hide();
            Login loginForm = new Login();
            loginForm.Show();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            serCon.TestConnectionString(server_nameTxt.Text, database_nameTxt.Text, user_idTxt.Text, passwordTxt.Text);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            serCon.ClearFields(server_nameTxt, database_nameTxt, user_idTxt, passwordTxt);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnShowCurrent_Click(object sender, EventArgs e)
        {
            serCon.ShowCurrentConnectionString(server_nameTxt, database_nameTxt, user_idTxt, passwordTxt);
        }
       
        

    }
}
