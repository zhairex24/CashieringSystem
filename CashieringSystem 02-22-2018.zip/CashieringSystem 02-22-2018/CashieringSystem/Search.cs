﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using CashieringSystem.Classes;

namespace CashieringSystem
{
    public partial class Search : Telerik.WinControls.UI.RadForm
    {
        public Search()
        {
            InitializeComponent();
        }

        Register reg = new Register();

        private void btnSearch_Click(object sender, EventArgs e)
        {
           string searchValue = txtSearch.Text;
           dgvStudInfo.DataSource = reg.SearchStudentByValue(searchValue);

           
        }

        private void Search_Load(object sender, EventArgs e)
        {
            dgvStudInfo.DataSource = reg.ViewAllStudents();
            dgvStudInfo.Columns[0].IsVisible = false;
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            string searchValue = txtSearch.Text;
            dgvStudInfo.DataSource = reg.SearchStudentByValue(searchValue);
        }

        private void dgvStudInfo_CellDoubleClick(object sender, Telerik.WinControls.UI.GridViewCellEventArgs e)
        {
            Transaction transac = new Transaction();
            string fname = this.dgvStudInfo.CurrentRow.Cells[2].Value.ToString();
            string mname = this.dgvStudInfo.CurrentRow.Cells[3].Value.ToString();
            string lname = this.dgvStudInfo.CurrentRow.Cells[4].Value.ToString();
            string status = this.dgvStudInfo.CurrentRow.Cells[5].Value.ToString();
            transac.txtPayorId.Text = this.dgvStudInfo.CurrentRow.Cells[1].Value.ToString();
            transac.txtName.Text = lname + ", " + fname + " " + lname;
            transac.txtCourse.Text = this.dgvStudInfo.CurrentRow.Cells[7].Value.ToString();
            transac.txtHome.Text = this.dgvStudInfo.CurrentRow.Cells[11].Value.ToString();
            transac.txtLevel.Text = this.dgvStudInfo.CurrentRow.Cells[14].Value.ToString();
            transac.labelStatus.Text = status + " Scholar";
            
            transac.Show();
        }

    }
}

