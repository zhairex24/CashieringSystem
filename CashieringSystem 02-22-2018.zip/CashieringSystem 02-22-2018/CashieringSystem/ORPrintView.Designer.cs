﻿namespace CashieringSystem
{
    partial class ORPrintView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource3 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.cashierdbDataSet1 = new CashieringSystem.cashierdbDataSet1();
            this.cashierdbDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cashierdbDataSet2 = new CashieringSystem.cashierdbDataSet2();
            this.getTransactionDetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.getTransactionDetailTableAdapter = new CashieringSystem.cashierdbDataSet2TableAdapters.GetTransactionDetailTableAdapter();
            this.cashierdbDataSet3 = new CashieringSystem.cashierdbDataSet3();
            this.getLatestORNumberBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.getLatestORNumberTableAdapter = new CashieringSystem.cashierdbDataSet3TableAdapters.GetLatestORNumberTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.cashierdbDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashierdbDataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashierdbDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.getTransactionDetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashierdbDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.getLatestORNumberBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "GetTransaction";
            reportDataSource1.Value = this.cashierdbDataSet1BindingSource;
            reportDataSource2.Name = "GetTransactionDetail";
            reportDataSource2.Value = this.getTransactionDetailBindingSource;
            reportDataSource3.Name = "GetLatestORNumber";
            reportDataSource3.Value = this.getLatestORNumberBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource3);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "CashieringSystem.ReportViewer.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(892, 570);
            this.reportViewer1.TabIndex = 0;
            // 
            // cashierdbDataSet1
            // 
            this.cashierdbDataSet1.DataSetName = "cashierdbDataSet1";
            this.cashierdbDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cashierdbDataSet1BindingSource
            // 
            this.cashierdbDataSet1BindingSource.DataSource = this.cashierdbDataSet1;
            this.cashierdbDataSet1BindingSource.Position = 0;
            // 
            // cashierdbDataSet2
            // 
            this.cashierdbDataSet2.DataSetName = "cashierdbDataSet2";
            this.cashierdbDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // getTransactionDetailBindingSource
            // 
            this.getTransactionDetailBindingSource.DataMember = "GetTransactionDetail";
            this.getTransactionDetailBindingSource.DataSource = this.cashierdbDataSet2;
            // 
            // getTransactionDetailTableAdapter
            // 
            this.getTransactionDetailTableAdapter.ClearBeforeFill = true;
            // 
            // cashierdbDataSet3
            // 
            this.cashierdbDataSet3.DataSetName = "cashierdbDataSet3";
            this.cashierdbDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // getLatestORNumberBindingSource
            // 
            this.getLatestORNumberBindingSource.DataMember = "GetLatestORNumber";
            this.getLatestORNumberBindingSource.DataSource = this.cashierdbDataSet3;
            // 
            // getLatestORNumberTableAdapter
            // 
            this.getLatestORNumberTableAdapter.ClearBeforeFill = true;
            // 
            // ORPrintView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 570);
            this.Controls.Add(this.reportViewer1);
            this.Name = "ORPrintView";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ORPrintView";
            this.ThemeName = "ControlDefault";
            this.Load += new System.EventHandler(this.ORPrintView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cashierdbDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashierdbDataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashierdbDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.getTransactionDetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashierdbDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.getLatestORNumberBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private cashierdbDataSet1 cashierdbDataSet1;
        private System.Windows.Forms.BindingSource cashierdbDataSet1BindingSource;
        private cashierdbDataSet2 cashierdbDataSet2;
        private System.Windows.Forms.BindingSource getTransactionDetailBindingSource;
        private cashierdbDataSet2TableAdapters.GetTransactionDetailTableAdapter getTransactionDetailTableAdapter;
        private cashierdbDataSet3 cashierdbDataSet3;
        private System.Windows.Forms.BindingSource getLatestORNumberBindingSource;
        private cashierdbDataSet3TableAdapters.GetLatestORNumberTableAdapter getLatestORNumberTableAdapter;
    }
}
